namespace GHEG.Internal.Network;

internal enum GHEG_ControlEventType
{
    Connected,
    Message,
    Error,
    Disconnected,
}

internal sealed class GHEG_ControlEvent
{
    internal GHEG_ControlEventType Type { get; }
    internal string Payload { get; }

    internal GHEG_ControlEvent(
        GHEG_ControlEventType type,
        string payload = "")
    {
        Type = type;
        Payload = payload;
    }
}
