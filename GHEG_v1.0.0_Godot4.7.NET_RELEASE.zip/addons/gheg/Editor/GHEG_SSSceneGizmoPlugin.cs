#if TOOLS
#nullable enable annotations
using Godot;

/// <summary>
/// Editor-only Smart Swizzle scene diagnostic gizmo.
/// Draws the selected bone marker and local axes without modifying the scene.
/// </summary>
[Tool]
public partial class GHEG_SSSceneGizmoPlugin : EditorNode3DGizmoPlugin
{
    private static readonly Color MarkerGreen = new(0.10f, 0.88f, 0.62f, 1.0f);
    private static readonly Color AxisX = new(1.0f, 0.28f, 0.28f, 1.0f);
    private static readonly Color AxisY = new(0.35f, 1.0f, 0.35f, 1.0f);
    private static readonly Color AxisZ = new(0.30f, 0.58f, 1.0f, 1.0f);
    private static readonly Color ParentLine = new(1.0f, 1.0f, 1.0f, 0.45f);

    private Skeleton3D? _targetSkeleton;
    private Transform3D _bonePose = Transform3D.Identity;
    private bool _hasParent;
    private Transform3D _parentPose = Transform3D.Identity;
    private bool _showMarker = true;
    private bool _showAxes = true;
    private bool _showParent;

    private readonly SphereMesh _markerMesh;
    private readonly BoxMesh _axisXMesh;
    private readonly BoxMesh _axisYMesh;
    private readonly BoxMesh _axisZMesh;

    public GHEG_SSSceneGizmoPlugin()
    {
        CreateMaterial("ss_marker", MarkerGreen, false, true);
        CreateMaterial("ss_x", AxisX, false, true);
        CreateMaterial("ss_y", AxisY, false, true);
        CreateMaterial("ss_z", AxisZ, false, true);
        CreateMaterial("ss_parent", ParentLine, false, true);

        _markerMesh = new SphereMesh
        {
            Radius = 0.018f,
            Height = 0.036f,
            RadialSegments = 12,
            Rings = 6,
        };
        _axisXMesh = new BoxMesh { Size = new Vector3(0.11f, 0.008f, 0.008f) };
        _axisYMesh = new BoxMesh { Size = new Vector3(0.008f, 0.11f, 0.008f) };
        _axisZMesh = new BoxMesh { Size = new Vector3(0.008f, 0.008f, 0.11f) };
    }

    public override string _GetGizmoName() => "GHEG Smart Swizzle";

    public override bool _HasGizmo(Node3D forNode3D) => forNode3D is Skeleton3D;

    public void SetTarget(
        Skeleton3D skeleton,
        Transform3D bonePose,
        bool hasParent,
        Transform3D parentPose,
        bool showMarker,
        bool showAxes,
        bool showParent)
    {
        Skeleton3D? previous = _targetSkeleton;
        bool sameTarget = previous == skeleton;
        bool unchanged =
            sameTarget &&
            PoseNearlyEqual(_bonePose, bonePose) &&
            _hasParent == hasParent &&
            (!hasParent || PoseNearlyEqual(_parentPose, parentPose)) &&
            _showMarker == showMarker &&
            _showAxes == showAxes &&
            _showParent == showParent;

        if (unchanged)
            return;

        _targetSkeleton = skeleton;
        _bonePose = bonePose;
        _hasParent = hasParent;
        _parentPose = parentPose;
        _showMarker = showMarker;
        _showAxes = showAxes;
        _showParent = showParent;

        if (previous is not null && GodotObject.IsInstanceValid(previous) && previous != skeleton)
            previous.UpdateGizmos();
        if (GodotObject.IsInstanceValid(skeleton))
            skeleton.UpdateGizmos();
    }

    public void ClearTarget()
    {
        Skeleton3D? previous = _targetSkeleton;
        _targetSkeleton = null;
        if (previous is not null && GodotObject.IsInstanceValid(previous))
            previous.UpdateGizmos();
    }

    public override void _Redraw(EditorNode3DGizmo gizmo)
    {
        gizmo.Clear();

        if (_targetSkeleton is null || !GodotObject.IsInstanceValid(_targetSkeleton))
            return;
        if (gizmo.GetNode3D() != _targetSkeleton)
            return;

        Vector3 origin = _bonePose.Origin;
        Basis basis = _bonePose.Basis.Orthonormalized();
        const float axisLength = 0.11f;

        if (_showMarker)
        {
            gizmo.AddMesh(
                _markerMesh,
                GetMaterial("ss_marker", gizmo),
                new Transform3D(Basis.Identity, origin));
        }

        if (_showAxes)
        {
            gizmo.AddMesh(
                _axisXMesh,
                GetMaterial("ss_x", gizmo),
                new Transform3D(basis, origin + basis.X.Normalized() * (axisLength * 0.5f)));
            gizmo.AddMesh(
                _axisYMesh,
                GetMaterial("ss_y", gizmo),
                new Transform3D(basis, origin + basis.Y.Normalized() * (axisLength * 0.5f)));
            gizmo.AddMesh(
                _axisZMesh,
                GetMaterial("ss_z", gizmo),
                new Transform3D(basis, origin + basis.Z.Normalized() * (axisLength * 0.5f)));
        }

        if (_showParent && _hasParent)
        {
            gizmo.AddLines(
                new[] { _parentPose.Origin, origin },
                GetMaterial("ss_parent", gizmo), false);
        }
    }

    private static bool PoseNearlyEqual(Transform3D a, Transform3D b)
    {
        if (a.Origin.DistanceSquaredTo(b.Origin) > 0.00000001f)
            return false;

        Quaternion qa = a.Basis.GetRotationQuaternion().Normalized();
        Quaternion qb = b.Basis.GetRotationQuaternion().Normalized();
        return Mathf.Abs(qa.Dot(qb)) > 0.999999f;
    }
}
#endif
