#if TOOLS
#nullable enable annotations
using Godot;

/// <summary>
/// Adds a lightweight live Timeline monitor to the GHEG_System inspector.
/// It is intentionally read-only and refreshes at 5 Hz to avoid editor overhead.
/// </summary>
[Tool]
public partial class GHEG_SystemInspectorPlugin : EditorInspectorPlugin
{
    public override bool _CanHandle(GodotObject @object)
    {
        return @object is GHEG_System;
    }

    public override void _ParseEnd(GodotObject @object)
    {
        if (@object is not GHEG_System system)
            return;

        var monitor = new GHEG_TimelineMonitorControl();
        monitor.BindSystem(system);
        AddCustomControl(monitor);
    }
}

[Tool]
public partial class GHEG_TimelineMonitorControl : VBoxContainer
{
    private const double RefreshIntervalSeconds = 0.20;

    private GHEG_System? _system;
    private Label? _body;
    private double _refreshRemaining;

    public void BindSystem(GHEG_System system)
    {
        _system = system;
    }

    public override void _Ready()
    {
        AddThemeConstantOverride("separation", 4);

        AddChild(new HSeparator());

        var title = new Label
        {
            Text = "Timeline Monitor",
        };
        title.AddThemeFontSizeOverride("font_size", 13);
        AddChild(title);

        _body = new Label
        {
            Text = "Waiting for Timeline state...",
        };
        _body.AddThemeFontSizeOverride("font_size", 12);
        AddChild(_body);

        var note = new Label
        {
            Text = "Debug monitor only. Values refresh at 5 Hz.",
            Modulate = new Color(1.0f, 1.0f, 1.0f, 0.55f),
        };
        note.AddThemeFontSizeOverride("font_size", 10);
        AddChild(note);

        ProcessMode = ProcessModeEnum.Always;
        SetProcess(true);
        RefreshNow();
    }

    public override void _Process(double delta)
    {
        _refreshRemaining -= delta;
        if (_refreshRemaining > 0.0)
            return;

        _refreshRemaining = RefreshIntervalSeconds;
        RefreshNow();
    }

    private void RefreshNow()
    {
        if (_body is null)
            return;

        if (_system is null ||
            !GodotObject.IsInstanceValid(_system))
        {
            _body.Text = "GHEG_System unavailable.";
            SetProcess(false);
            return;
        }

        _body.Text = _system.GetTimelineMonitorText();
    }
}
#endif
