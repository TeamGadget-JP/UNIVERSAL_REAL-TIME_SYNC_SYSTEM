#nullable enable annotations
using System;
using System.Collections.Generic;
using System.IO;
using Godot;

/// <summary>
/// Dedicated per-character ShapeMixer Entangle (SE) offline facial bake player.
///
/// Add one GHEG_FacePlayer under the same wrapper as GHEG_Avatar and
/// GHEG_ShapeKeys, then use GHEG Control > AUTO ASSIGN to populate Avatar.
/// This node is intentionally an AnimationPlayer itself:
/// during URSS authoring the script controls bake capture, while the baked
/// Animation resource remains a standard Godot asset that can be used by an
/// ordinary AnimationPlayer after all GHEG scripts are detached.
/// </summary>
[Tool]
[GlobalClass]
public partial class GHEG_FacePlayer : AnimationPlayer
{
	private static readonly StringName RootLibraryName = new("");

	private sealed class CaptureTrack
	{
		internal int TrackIndex;
		internal string PacketShapeName = "";
	}

	[ExportGroup("Facial Bake")]
	[Export]
	public GHEG_Avatar? Avatar { get; set; }

	[Export(PropertyHint.Range, "0,100000,1,or_greater")]
	public int StartFrame { get; set; } = 0;

	[Export(PropertyHint.Range, "0,100000,1,or_greater")]
	public int EndFrame { get; set; } = 100;

	[Export(PropertyHint.Range, "1,240,1")]
	public int Fps { get; set; } = 30;

	[ExportGroup("Output")]
	[Export(PropertyHint.Dir)]
	public string OutputFolder { get; set; } = "";

	[Export]
	public string AssetName { get; set; } = "";

	private GHEG_ShapeKeys? _captureReceiver;
	private Animation? _captureAnimation;
	private readonly List<CaptureTrack> _captureTracks = new();
	private int _captureStartFrame;
	private int _captureEndFrame;
	private int _captureFps;
	private bool _captureBindingsLocked;
	private bool _captureActive;
	private string _bakeStatus = "Ready";
	private string _lastBakeResourcePath = "";

	internal bool IsCaptureActive => _captureActive;
	internal string BakeStatus => _bakeStatus;
	internal string LastBakeResourcePath => _lastBakeResourcePath;

	internal GHEG_Avatar? ResolveAvatar()
	{
		return Avatar is not null && GodotObject.IsInstanceValid(Avatar)
			? Avatar
			: null;
	}

	internal GHEG_ShapeKeys? ResolveShapeKeys()
	{
		Node? parent = GetParent();
		if (parent is null)
			return null;

		// In the standard layout ShapeKeys is a sibling of FacePlayer. Require
		// a unique active receiver instead of silently choosing the first one.
		GHEG_ShapeKeys? found = null;
		int count = 0;

		foreach (Node child in parent.GetChildren())
		{
			if (child is not GHEG_ShapeKeys receiver || !receiver.Active)
				continue;

			found = receiver;
			count++;
			if (count > 1)
				return null;
		}

		if (count == 1)
			return found;

		FindShapeKeysRecursiveUnique(parent, ref found, ref count);
		return count == 1 ? found : null;
	}

	internal string EffectiveOutputFolder
	{
		get
		{
			if (!string.IsNullOrWhiteSpace(OutputFolder))
				return OutputFolder.Trim();

			return "res://";
		}
	}

	internal string EffectiveAssetName
	{
		get
		{
			if (!string.IsNullOrWhiteSpace(AssetName))
				return AssetName.Trim();

			int slot = ResolveAvatar() is GHEG_Avatar avatar
				? (int)avatar.Slot + 1
				: 1;

			return $"Character{slot}_Face";
		}
	}

	internal bool BeginBakeCapture(
		GHEG_ShapeKeys receiver,
		int startFrame,
		int endFrame,
		int fps,
		out string reason)
	{
		reason = "";

		if (!Active)
		{
			reason = "GHEG_FacePlayer is disabled.";
			return false;
		}

		if (receiver is null || !GodotObject.IsInstanceValid(receiver))
		{
			reason = "GHEG_ShapeKeys receiver is unavailable.";
			return false;
		}

		if (fps <= 0 || endFrame < startFrame)
		{
			reason = "Invalid Facial Bake range or FPS.";
			return false;
		}

		Node? targetRoot = receiver.ResolveTargetRoot();
		if (targetRoot is null || !GodotObject.IsInstanceValid(targetRoot))
		{
			reason = "Facial Bake target root could not be resolved.";
			return false;
		}

		NodePath rootPath = GetPathTo(targetRoot);
		if (string.IsNullOrEmpty(rootPath.ToString()))
		{
			reason = "Facial Bake could not resolve an AnimationPlayer Root Node.";
			return false;
		}

		RootNode = rootPath;
		_captureReceiver = receiver;
		_captureStartFrame = startFrame;
		_captureEndFrame = endFrame;
		_captureFps = fps;
		_captureBindingsLocked = false;
		_captureTracks.Clear();

		double lastKeyTime =
			Math.Max(0, endFrame - startFrame) / (double)fps;
		double minimumLength = 1.0 / fps;

		_captureAnimation = new Animation
		{
			Length = Math.Max(lastKeyTime, minimumLength),
			Step = (float)minimumLength,
			LoopMode = Animation.LoopModeEnum.None,
		};

		_captureActive = true;
		_bakeStatus = "Waiting for ShapeMixer";
		return true;
	}

	internal bool CaptureBakeSample(
		int destinationFrame,
		IReadOnlyDictionary<string, float> packetWeights,
		out string reason)
	{
		reason = "";

		if (!_captureActive || _captureAnimation is null || _captureReceiver is null)
		{
			reason = "Facial Bake capture is not active.";
			return false;
		}

		if (!_captureBindingsLocked)
		{
			Node? targetRoot = _captureReceiver.ResolveTargetRoot();
			if (targetRoot is null)
			{
				reason = "Facial Bake target root was lost.";
				return false;
			}

			List<GHEG_ShapeKeys.BakeBinding> bindings =
				_captureReceiver.GetBakeBindingsForPacketNames(
					packetWeights.Keys,
					targetRoot);

			if (bindings.Count == 0)
			{
				reason =
					"ShapeMixer returned Timeline Shape Keys, but none matched Godot BlendShapes.";
				return false;
			}

			foreach (GHEG_ShapeKeys.BakeBinding binding in bindings)
			{
				int trackIndex =
					_captureAnimation.AddTrack(Animation.TrackType.BlendShape);

				_captureAnimation.TrackSetPath(trackIndex, binding.TrackPath);
				_captureAnimation.TrackSetInterpolationType(
					trackIndex,
					Animation.InterpolationType.Linear);

				_captureTracks.Add(new CaptureTrack
				{
					TrackIndex = trackIndex,
					PacketShapeName = binding.PacketShapeName,
				});
			}

			_captureBindingsLocked = true;
			_bakeStatus = $"Baking {_captureTracks.Count} BlendShape track(s)";
		}

		double timeSeconds =
			(destinationFrame - _captureStartFrame) / (double)_captureFps;
		timeSeconds = Math.Max(0.0, timeSeconds);

		foreach (CaptureTrack track in _captureTracks)
		{
			float percent =
				packetWeights.TryGetValue(track.PacketShapeName, out float value)
					? value
					: 0.0f;

			float normalized = Mathf.Clamp(percent / 100.0f, 0.0f, 1.0f);
			_captureAnimation.BlendShapeTrackInsertKey(
				track.TrackIndex,
				timeSeconds,
				normalized);
		}

		return true;
	}

	internal bool CompleteBake(
		out string resourcePath,
		out string reason)
	{
		resourcePath = "";
		reason = "";

		if (!_captureActive || _captureAnimation is null)
		{
			reason = "Facial Bake capture is not active.";
			return false;
		}

		if (!_captureBindingsLocked || _captureTracks.Count == 0)
		{
			reason = "No Facial Bake BlendShape tracks were captured.";
			AbortBakeCapture("Failed");
			return false;
		}

		if (!TryResolveOutputPath(out resourcePath, out reason))
		{
			AbortBakeCapture("Failed");
			return false;
		}

		Error saveError = ResourceSaver.Save(_captureAnimation, resourcePath);
		if (saveError != Error.Ok)
		{
			reason = $"ResourceSaver failed with {saveError}.";
			AbortBakeCapture("Failed");
			return false;
		}

		AnimationLibrary library;
		if (HasAnimationLibrary(RootLibraryName))
		{
			library = GetAnimationLibrary(RootLibraryName);
		}
		else
		{
			library = new AnimationLibrary();
			Error libraryError = AddAnimationLibrary(RootLibraryName, library);
			if (libraryError != Error.Ok)
			{
				reason = $"Could not create the FacePlayer AnimationLibrary: {libraryError}.";
				AbortBakeCapture("Failed");
				return false;
			}
		}

		string animationNameText = Path.GetFileNameWithoutExtension(resourcePath);
		StringName animationName = new(animationNameText);
		if (library.HasAnimation(animationName))
			library.RemoveAnimation(animationName);

		Error addError = library.AddAnimation(animationName, _captureAnimation);
		if (addError != Error.Ok)
		{
			reason = $"Could not attach the baked Animation to GHEG_FacePlayer: {addError}.";
			AbortBakeCapture("Failed");
			return false;
		}

		// Attach the freshly baked standard Animation to this dedicated
		// FacePlayer and evaluate frame 0 immediately. Godot's editor-side
		// Animation panel has its own selection state, so it may not visually
		// switch to the new clip, but the player itself must already own and
		// evaluate the baked asset.
		AssignedAnimation = animationName;

		if (!HasAnimation(animationName) || AssignedAnimation != animationName)
		{
			reason = "Baked Animation was saved, but could not be attached to GHEG_FacePlayer.";
			AbortBakeCapture("Failed");
			return false;
		}

		Seek(0.0, update: true, updateOnly: true);
		Advance(0.0);

		// Notify editor-side observers that the generated library/resource
		// changed. This does not depend on private Animation editor APIs.
		_captureAnimation.EmitChanged();
		library.EmitChanged();
		NotifyPropertyListChanged();

		_lastBakeResourcePath = resourcePath;
		_bakeStatus = "Complete / Attached";
		_captureActive = false;
		_captureReceiver = null;
		_captureAnimation = null;
		_captureTracks.Clear();
		_captureBindingsLocked = false;

#if TOOLS
		if (Engine.IsEditorHint())
		{
			EditorFileSystem fileSystem =
				EditorInterface.Singleton.GetResourceFilesystem();
			fileSystem.UpdateFile(resourcePath);

			// The baked .tres is already a standalone canonical result.
			// Mark the scene dirty as well so the preview AnimationLibrary
			// reference can be preserved if the user saves this authoring scene.
			EditorInterface.Singleton.MarkSceneAsUnsaved();
		}
#endif

		return true;
	}

	internal void AbortBakeCapture(string status)
	{
		_captureActive = false;
		_captureReceiver = null;
		_captureAnimation = null;
		_captureTracks.Clear();
		_captureBindingsLocked = false;
		_bakeStatus = string.IsNullOrWhiteSpace(status) ? "Aborted" : status;
	}

	internal void SetBakeStatus(string status)
	{
		_bakeStatus = status;
	}

	private bool TryResolveOutputPath(
		out string resourcePath,
		out string reason)
	{
		resourcePath = "";
		reason = "";

		string folder = EffectiveOutputFolder.Replace('\\', '/').Trim();
		if (!folder.StartsWith("res://", StringComparison.OrdinalIgnoreCase))
		{
			reason = "Facial Bake Output Folder must be inside res://.";
			return false;
		}

		if (!string.Equals(folder, "res://", StringComparison.OrdinalIgnoreCase))
			folder = folder.TrimEnd('/');

		if (folder.Contains("/../", StringComparison.Ordinal) ||
			folder.EndsWith("/..", StringComparison.Ordinal))
		{
			reason = "Facial Bake Output Folder cannot contain '..'.";
			return false;
		}

		string baseName = SanitizeAssetName(EffectiveAssetName);
		string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
		string folderPrefix = folder.EndsWith("/", StringComparison.Ordinal)
			? folder
			: folder + "/";
		string candidate = $"{folderPrefix}{baseName}_{timestamp}.tres";
		string absolute = ProjectSettings.GlobalizePath(candidate);

		int suffix = 2;
		while (File.Exists(absolute))
		{
			candidate = $"{folderPrefix}{baseName}_{timestamp}_{suffix}.tres";
			absolute = ProjectSettings.GlobalizePath(candidate);
			suffix++;
		}

		try
		{
			string? directory = Path.GetDirectoryName(absolute);
			if (string.IsNullOrWhiteSpace(directory))
			{
				reason = "Facial Bake destination directory is invalid.";
				return false;
			}

			Directory.CreateDirectory(directory);
		}
		catch (Exception ex)
		{
			reason = "Could not create Facial Bake output folder: " + ex.Message;
			return false;
		}

		resourcePath = candidate;
		return true;
	}

	private static string SanitizeAssetName(string value)
	{
		string source = string.IsNullOrWhiteSpace(value)
			? "FacialBake"
			: value.Trim();

		var invalid = new HashSet<char>(Path.GetInvalidFileNameChars())
		{
			'/',
			'\\',
		};

		var builder = new System.Text.StringBuilder(source.Length);
		foreach (char c in source)
			builder.Append(invalid.Contains(c) ? '_' : c);

		string result = builder.ToString().Trim().Trim('.');
		return string.IsNullOrWhiteSpace(result) ? "FacialBake" : result;
	}

	private static void FindShapeKeysRecursiveUnique(
		Node node,
		ref GHEG_ShapeKeys? found,
		ref int count)
	{
		foreach (Node child in node.GetChildren())
		{
			if (child is GHEG_ShapeKeys receiver && receiver.Active)
			{
				found = receiver;
				count++;
				if (count > 1)
					return;
			}

			FindShapeKeysRecursiveUnique(child, ref found, ref count);
			if (count > 1)
				return;
		}
	}
}
