#if TOOLS
#nullable enable annotations
using System;
using System.Runtime.Loader;
using GHEG.Internal.Network;

namespace GHEG.Internal.Core;

/// <summary>
/// Last-chance cleanup for Godot .NET hot reload.
/// Keeps the collectible AssemblyLoadContext from being held by GHEG workers
/// or managed editor state after a C# rebuild.
/// </summary>
internal static class GHEG_AssemblyReloadGuard
{
    private static readonly object _registrationLock = new();
    private static AssemblyLoadContext? _loadContext;
    private static bool _registered;
    private static int _cleanupStarted;

    internal static void EnsureRegistered()
    {
        lock (_registrationLock)
        {
            if (_registered)
                return;

            AssemblyLoadContext? context =
                AssemblyLoadContext.GetLoadContext(
                    typeof(GHEG_AssemblyReloadGuard).Assembly);

            if (context is null)
                return;

            _loadContext = context;
            context.Unloading += OnAssemblyLoadContextUnloading;
            _registered = true;
        }
    }

    private static void OnAssemblyLoadContextUnloading(
        AssemblyLoadContext context)
    {
        if (System.Threading.Interlocked.Exchange(
            ref _cleanupStarted,
            1) != 0)
        {
            return;
        }

        // Do not call into Godot objects here. At this point the editor can
        // already be detaching scripts. Restrict the last-chance pass to
        // pure managed cleanup only.
        try
        {
            GHEG_GHubClient.ShutdownAllForAssemblyReload(
                releaseRegistry: true);
        }
        catch
        {
        }

        try
        {
            GHEG_EditorState.ResetForAssemblyReload();
        }
        catch
        {
        }

        try
        {
            GHEG_System.ReleaseStaticReferencesForAssemblyReload();
        }
        catch
        {
        }

        lock (_registrationLock)
        {
            if (_loadContext is not null)
            {
                try
                {
                    _loadContext.Unloading -=
                        OnAssemblyLoadContextUnloading;
                }
                catch
                {
                }
            }

            _loadContext = null;
            _registered = false;
        }
    }
}
#endif
