#if TOOLS
#nullable enable annotations
using System;
using Godot;

/// <summary>
/// Primary editor control surface for GHEG.
/// Rig setup and advanced configuration remain in the Inspector.
/// </summary>
[Tool]
public partial class GHEG_ControlDock : VBoxContainer
{
    public event Action<int>? SsVisualizerRequested;
    private const double RefreshIntervalSeconds = 0.20;
    private const int RegularFontSize = 14;
    private const int TitleFontSize = 15;

    private static readonly Color ActiveBlue = new(0.08f, 0.52f, 0.96f, 1.0f);
    private static readonly Color ActiveBlueHover = new(0.12f, 0.60f, 1.00f, 1.0f);
    private static readonly Color ActiveBluePressed = new(0.06f, 0.42f, 0.82f, 1.0f);
    private static readonly Color ActiveGreen = new(0.10f, 0.88f, 0.62f, 1.0f);

    private readonly Label _hubStatus = new();
    private readonly Label _hubEndpoint = new();
    private readonly Label _hubSession = new();
    private readonly SpinBox _controlPort = new();
    private readonly Button _connectButton = new();
    private readonly Button _timelineButton = new();
    private readonly Label _timelineStatus = new();
    private readonly OptionButton _targetSlot = new();
    private readonly Button _selectButton = new();
    private readonly Button _autoAssignButton = new();
    private readonly Button _autoAssignAllButton = new();
    private readonly Label _autoAssignStatus = new();
    private readonly LineEdit _fbxOutput = new();
    private readonly Button _fbxOutputBrowse = new() { Text = "...", TooltipText = "Choose FBX output folder" };
    private readonly LineEdit _fbxName = new();
    private readonly Button _fbxBridgeButton = new();
    private readonly Button _fbxImportButton = new();
    private readonly Label _fbxStatus = new();
    private readonly SpinBox _faceStart = new();
    private readonly SpinBox _faceEnd = new();
    private readonly SpinBox _faceFps = new();
    private readonly LineEdit _faceOutput = new();
    private readonly Button _faceOutputBrowse = new() { Text = "...", TooltipText = "Choose Facial Bake output folder" };
    private readonly LineEdit _faceName = new();
    private readonly FileDialog _outputFolderDialog = new();
    private bool _outputDialogForFace;
    private readonly Button _faceBakeButton = new();
    private readonly Button _faceCancelButton = new();
    private readonly Label _faceStatus = new();
    private readonly Button _ssButton = new();
    private readonly Label[] _slotBody = new Label[5];
    private readonly Label[] _slotFace = new Label[5];

    private GHEG_System? _system;
    private readonly GHEG_Avatar?[] _avatars = new GHEG_Avatar?[5];
    private readonly GHEG_FacePlayer?[] _facePlayers = new GHEG_FacePlayer?[5];
    private bool _refreshing;
    private double _refreshRemaining;

    // Remember the user's most recently chosen output folders while the editor
    // session is alive. Empty per-character fields inherit these values in the
    // Control UI, so switching C1-C5 does not reset the picker to a deep path.
    private static string _lastFbxOutputFolder = "res://";
    private static string _lastFaceOutputFolder = "res://";

    public GHEG_ControlDock()
    {
        Name = "GHEG";
        SizeFlagsHorizontal = SizeFlags.ExpandFill;
        SizeFlagsVertical = SizeFlags.ExpandFill;
        AddThemeConstantOverride("separation", 3);

        var title = new Label { Text = "G-HUB", ThemeTypeVariation = "HeaderSmall" };
        title.AddThemeFontSizeOverride("font_size", TitleFontSize);
        AddChild(title);

        var subtitle = new Label { Text = "Godot Endpoint" };
        subtitle.Modulate = new Color(1, 1, 1, 0.72f);
        subtitle.AddThemeFontSizeOverride("font_size", RegularFontSize);
        AddChild(subtitle);

        var note = new Label
        {
            Text = "Daily operation panel. Rig setup and advanced settings remain in Inspector.",
            AutowrapMode = TextServer.AutowrapMode.WordSmart,
            Modulate = new Color(1, 1, 1, 0.62f),
        };
        note.AddThemeFontSizeOverride("font_size", RegularFontSize);
        AddChild(note);

        AddSection("HUB");
        var hubStateBlock = CompactColumn(0);
        _hubStatus.Text = "OFFLINE";
        hubStateBlock.AddChild(_hubStatus);
        _hubEndpoint.Text = "Endpoint: --";
        _hubEndpoint.Modulate = new Color(1, 1, 1, 0.72f);
        hubStateBlock.AddChild(_hubEndpoint);
        _hubSession.Text = "Session: --";
        _hubSession.AutowrapMode = TextServer.AutowrapMode.WordSmart;
        _hubSession.Modulate = new Color(1, 1, 1, 0.72f);
        hubStateBlock.AddChild(_hubSession);
        AddChild(hubStateBlock);

        var portRow = Row();
        portRow.AddChild(new Label { Text = "Control Port", SizeFlagsHorizontal = SizeFlags.ExpandFill });
        _controlPort.MinValue = 1;
        _controlPort.MaxValue = 65535;
        _controlPort.Step = 1;
        _controlPort.AllowGreater = false;
        _controlPort.AllowLesser = false;
        _controlPort.CustomMinimumSize = new Vector2(100, 0);
        portRow.AddChild(_controlPort);
        AddChild(portRow);

        _connectButton.Text = "CONNECT";
        _connectButton.SizeFlagsHorizontal = SizeFlags.ExpandFill;
        _connectButton.TooltipText = "Connect / disconnect G-HUB";
        AddChild(_connectButton);

        _timelineButton.Text = "TIMELINE ON";
        _timelineButton.SizeFlagsHorizontal = SizeFlags.ExpandFill;
        AddChild(_timelineButton);

        _timelineStatus.Text = "Timeline: --";
        _timelineStatus.AutowrapMode = TextServer.AutowrapMode.WordSmart;
        _timelineStatus.Modulate = new Color(1, 1, 1, 0.72f);
        _timelineStatus.AddThemeConstantOverride("line_spacing", -2);
        AddChild(_timelineStatus);

        AddSection("CHARACTERS");
        var charactersBlock = CompactColumn(0);
        for (int i = 0; i < 5; i++)
        {
            var row = Row(3);
            var slot = new Label { Text = $"C{i + 1}", CustomMinimumSize = new Vector2(30, 0) };
            row.AddChild(slot);
            _slotBody[i] = new Label { Text = "BODY --", SizeFlagsHorizontal = SizeFlags.ExpandFill };
            _slotFace[i] = new Label { Text = "FACE --", SizeFlagsHorizontal = SizeFlags.ExpandFill };
            row.AddChild(_slotBody[i]);
            row.AddChild(_slotFace[i]);
            charactersBlock.AddChild(row);
        }
        AddChild(charactersBlock);

        AddSection("TARGET");
        var targetRow = Row();
        _targetSlot.SizeFlagsHorizontal = SizeFlags.ExpandFill;
        for (int i = 0; i < 5; i++)
            _targetSlot.AddItem($"C{i + 1}", i);
        targetRow.AddChild(_targetSlot);
        _selectButton.Text = "Select";
        targetRow.AddChild(_selectButton);
        AddChild(targetRow);

        var assignRow = Row();
        _autoAssignButton.Text = "AUTO ASSIGN";
        _autoAssignButton.SizeFlagsHorizontal = SizeFlags.ExpandFill;
        _autoAssignButton.TooltipText =
            "Assign only safe, known references for the selected Character Slot. " +
            "Set TimelineAgent.Avatar manually first.";
        assignRow.AddChild(_autoAssignButton);

        _autoAssignAllButton.Text = "ASSIGN ALL";
        _autoAssignAllButton.SizeFlagsHorizontal = SizeFlags.ExpandFill;
        _autoAssignAllButton.TooltipText =
            "Run the same safe assignment for every configured Character Slot. " +
            "Empty slots are skipped.";
        assignRow.AddChild(_autoAssignAllButton);
        AddChild(assignRow);

        _autoAssignStatus.Text = "Assign: Ready";
        _autoAssignStatus.AutowrapMode = TextServer.AutowrapMode.WordSmart;
        AddChild(_autoAssignStatus);

        AddSection("FBX BRIDGE");
        _fbxOutput.PlaceholderText = "res://...";
        _fbxName.PlaceholderText = "Character1";
        AddPathControl("Output", _fbxOutput, _fbxOutputBrowse);
        AddStackedControl("Asset", _fbxName);
        var fbxButtons = Row();
        _fbxBridgeButton.Text = "FBX BRIDGE";
        _fbxBridgeButton.SizeFlagsHorizontal = SizeFlags.ExpandFill;
        _fbxImportButton.Text = "IMPORT FBX";
        _fbxImportButton.SizeFlagsHorizontal = SizeFlags.ExpandFill;
        fbxButtons.AddChild(_fbxBridgeButton);
        fbxButtons.AddChild(_fbxImportButton);
        AddChild(fbxButtons);
        _fbxStatus.Text = "Status: Idle";
        _fbxStatus.AutowrapMode = TextServer.AutowrapMode.WordSmart;
        AddChild(_fbxStatus);

        AddSection("FACIAL BAKE");
        _faceStart.MinValue = 0; _faceStart.MaxValue = 100000; _faceStart.Step = 1;
        _faceEnd.MinValue = 0; _faceEnd.MaxValue = 100000; _faceEnd.Step = 1;
        _faceFps.MinValue = 1; _faceFps.MaxValue = 240; _faceFps.Step = 1;
        AddChild(new Label { Text = "Range" });
        var rangeRow = Row();
        _faceStart.SizeFlagsHorizontal = SizeFlags.ExpandFill;
        _faceEnd.SizeFlagsHorizontal = SizeFlags.ExpandFill;
        rangeRow.AddChild(_faceStart);
        rangeRow.AddChild(new Label { Text = "→" });
        rangeRow.AddChild(_faceEnd);
        AddChild(rangeRow);

        var fpsRow = Row();
        fpsRow.AddChild(new Label { Text = "FPS", CustomMinimumSize = new Vector2(42, 0) });
        _faceFps.SizeFlagsHorizontal = SizeFlags.ExpandFill;
        fpsRow.AddChild(_faceFps);
        AddChild(fpsRow);

        _faceOutput.PlaceholderText = "res://...";
        _faceName.PlaceholderText = "Character1_Face";
        AddPathControl("Output", _faceOutput, _faceOutputBrowse);
        AddStackedControl("Asset", _faceName);
        var faceButtons = Row();
        _faceBakeButton.Text = "FACIAL BAKE";
        _faceBakeButton.SizeFlagsHorizontal = SizeFlags.ExpandFill;
        _faceCancelButton.Text = "CANCEL";
        faceButtons.AddChild(_faceBakeButton);
        faceButtons.AddChild(_faceCancelButton);
        AddChild(faceButtons);
        _faceStatus.Text = "Status: Ready";
        _faceStatus.AutowrapMode = TextServer.AutowrapMode.WordSmart;
        AddChild(_faceStatus);

        AddSection("DIAGNOSTICS");
        _ssButton.Text = "SS VISUALIZER";
        _ssButton.Disabled = false;
        _ssButton.TooltipText = "Open the floating Smart Swizzle diagnostic window.";
        AddChild(_ssButton);

        _outputFolderDialog.Title = "Select Output Folder";
        _outputFolderDialog.FileMode = FileDialog.FileModeEnum.OpenDir;
        _outputFolderDialog.Access = FileDialog.AccessEnum.Resources;
        _outputFolderDialog.UseNativeDialog = false;
        AddChild(_outputFolderDialog);

        ApplyCompactUi(this);

        _connectButton.Pressed += OnConnectPressed;
        _timelineButton.Pressed += OnTimelinePressed;
        _controlPort.ValueChanged += OnControlPortChanged;
        _targetSlot.ItemSelected += OnTargetChanged;
        _selectButton.Pressed += OnSelectPressed;
        _autoAssignButton.Pressed += OnAutoAssignPressed;
        _autoAssignAllButton.Pressed += OnAutoAssignAllPressed;
        _fbxOutput.TextChanged += OnFbxOutputChanged;
        _fbxOutputBrowse.Pressed += OnFbxOutputBrowsePressed;
        _fbxName.TextChanged += OnFbxNameChanged;
        _fbxBridgeButton.Pressed += OnFbxBridgePressed;
        _fbxImportButton.Pressed += OnFbxImportPressed;
        _faceStart.ValueChanged += OnFaceStartChanged;
        _faceEnd.ValueChanged += OnFaceEndChanged;
        _faceFps.ValueChanged += OnFaceFpsChanged;
        _faceOutput.TextChanged += OnFaceOutputChanged;
        _faceOutputBrowse.Pressed += OnFaceOutputBrowsePressed;
        _faceName.TextChanged += OnFaceNameChanged;
        _faceBakeButton.Pressed += OnFaceBakePressed;
        _faceCancelButton.Pressed += OnFaceCancelPressed;
        _ssButton.Pressed += OnSsVisualizerPressed;
        _outputFolderDialog.DirSelected += OnOutputFolderSelected;

        ProcessMode = ProcessModeEnum.Always;
        SetProcess(true);
    }

    public override void _Process(double delta)
    {
        _refreshRemaining -= delta;
        if (_refreshRemaining > 0)
            return;
        _refreshRemaining = RefreshIntervalSeconds;
        RefreshUi();
    }

    private void RefreshUi()
    {
        ScanEditedScene();
        _refreshing = true;

        if (_system is null || !GodotObject.IsInstanceValid(_system))
        {
            _hubStatus.Text = "SYSTEM NOT FOUND";
            _hubEndpoint.Text = "Endpoint: --";
            _hubSession.Text = "Session: --";
            _connectButton.Disabled = true;
            _timelineButton.Disabled = true;
            SetActiveButtonStyle(_connectButton, false);
            SetActiveButtonStyle(_timelineButton, false);
            SetStatusColor(_hubStatus, false);
            SetStatusColor(_hubEndpoint, false);
            SetStatusColor(_hubSession, false);
            SetStatusColor(_timelineStatus, false);
            _autoAssignStatus.Text = "Assign: --";
            SetStatusColor(_autoAssignStatus, false);
            for (int i = 0; i < 5; i++)
            {
                SetStatusColor(_slotBody[i], false);
                SetStatusColor(_slotFace[i], false);
            }
            SetStatusColor(_fbxStatus, false);
            SetStatusColor(_faceStatus, false);
            SetOperationEnabled(false);
            _refreshing = false;
            return;
        }

        _connectButton.Disabled = false;
        _timelineButton.Disabled = false;
        _controlPort.Value = _system.ControlPort;

        GHEG_System.ControlUiState hub = GHEG_System.GetControlUiState();
        _hubStatus.Text = hub.SessionActive
            ? "SESSION ACTIVE"
            : hub.EndpointRunning
                ? "CONNECTING"
                : hub.Requested ? "CONNECTION REQUESTED" : "OFFLINE";
        _hubEndpoint.Text = hub.SessionActive ? $"Endpoint: {hub.EndpointId}" : "Endpoint: --";
        _hubSession.Text = hub.SessionActive ? $"Session: {hub.SessionId}" : "Session: --";
        _hubSession.TooltipText = hub.SessionActive ? hub.SessionId.ToString() : string.Empty;
        _connectButton.Text = _system.ConnectToGHub ? "DISCONNECT" : "CONNECT";
        _timelineButton.Text = _system.TimelineSyncEnabled ? "TIMELINE ON" : "TIMELINE OFF";
        _timelineStatus.Text = _system.GetTimelineMonitorText();

        SetActiveButtonStyle(_connectButton, _system.ConnectToGHub);
        SetActiveButtonStyle(_timelineButton, _system.TimelineSyncEnabled);
        SetStatusColor(_hubStatus, hub.SessionActive || hub.EndpointRunning || hub.Requested);
        SetStatusColor(_hubEndpoint, hub.SessionActive);
        SetStatusColor(_hubSession, hub.SessionActive);
        SetStatusColor(_timelineStatus, _system.TimelineSyncEnabled);

        for (int i = 0; i < 5; i++)
        {
            GHEG_System.SlotUiState state = GHEG_System.GetSlotUiState(i);
            _slotBody[i].Text = state.BodyRouteReady
                ? (state.BodyUdpObserved ? "BODY LIVE" : "BODY ROUTED")
                : state.BodyConfigured ? "BODY WAIT" : "BODY --";
            _slotFace[i].Text = state.FaceRouteReady
                ? (state.FaceUdpObserved ? "FACE LIVE" : "FACE ROUTED")
                : state.FaceConfigured ? "FACE WAIT" : "FACE --";

            SetStatusColor(_slotBody[i], state.BodyRouteReady || state.BodyConfigured);
            SetStatusColor(_slotFace[i], state.FaceRouteReady || state.FaceConfigured);
        }

        int target = TargetIndex;
        GHEG_Avatar? avatar = _avatars[target];
        GHEG_FacePlayer? player = _facePlayers[target];
        _selectButton.Disabled = avatar is null;
        _autoAssignButton.Disabled = avatar is null;
        _autoAssignAllButton.Disabled = !HasAnyValidAvatar();

        if (avatar is not null && GodotObject.IsInstanceValid(avatar))
        {
            if (!_fbxOutput.HasFocus())
            {
                string configuredFolder = (avatar.FbxBridgeOutputFolder ?? string.Empty).Trim();
                _fbxOutput.Text = string.IsNullOrWhiteSpace(configuredFolder)
                    ? _lastFbxOutputFolder
                    : avatar.EffectiveFbxBridgeOutputFolder;
            }
            if (!_fbxName.HasFocus()) _fbxName.Text = avatar.EffectiveFbxBridgeAssetName;
            GHEG_System.FbxBridgeUiState fbx = GHEG_System.GetFbxBridgeUiState(avatar);
            _fbxBridgeButton.Disabled = !GHEG_System.HasActiveCharacterRouteFor(avatar) || fbx.Busy || fbx.Importing;
            _fbxImportButton.Disabled = !fbx.HasLastResult || !fbx.LastSucceeded || string.IsNullOrWhiteSpace(fbx.LastResourcePath) || fbx.Busy || fbx.Importing;
            _fbxStatus.Text = "Status: " + (fbx.Busy || fbx.Importing ? fbx.PhaseLabel : fbx.LastSummary);
            SetStatusColor(_fbxStatus, fbx.Busy || fbx.Importing || fbx.LastSucceeded || !fbx.HasLastResult);
        }
        else
        {
            _fbxBridgeButton.Disabled = true;
            _fbxImportButton.Disabled = true;
            _fbxStatus.Text = "Status: No Avatar for selected slot.";
            SetStatusColor(_fbxStatus, false);
        }

        if (player is not null && GodotObject.IsInstanceValid(player))
        {
            if (!_faceStart.HasFocus()) _faceStart.Value = player.StartFrame;
            if (!_faceEnd.HasFocus()) _faceEnd.Value = player.EndFrame;
            if (!_faceFps.HasFocus()) _faceFps.Value = player.Fps;
            if (!_faceOutput.HasFocus())
            {
                string configuredFolder = (player.OutputFolder ?? string.Empty).Trim();
                _faceOutput.Text = string.IsNullOrWhiteSpace(configuredFolder)
                    ? _lastFaceOutputFolder
                    : player.EffectiveOutputFolder;
            }
            if (!_faceName.HasFocus()) _faceName.Text = player.EffectiveAssetName;
            GHEG_System.FacialBakeUiState face = GHEG_System.GetFacialBakeUiState(player);
            _faceBakeButton.Disabled = !face.RouteReady || face.Busy || !player.Active;
            _faceCancelButton.Disabled = !face.BusyForThisPlayer;
            _faceStatus.Text = "Status: " + face.Status;
            SetStatusColor(_faceStatus, face.RouteReady || face.Busy || face.BusyForThisPlayer);
        }
        else
        {
            _faceBakeButton.Disabled = true;
            _faceCancelButton.Disabled = true;
            _faceStatus.Text = "Status: No GHEG_FacePlayer for selected slot.";
            SetStatusColor(_faceStatus, false);
        }

        SetOperationEnabled(true);
        _refreshing = false;
    }

    private void ScanEditedScene()
    {
        _system = null;
        Array.Clear(_avatars, 0, _avatars.Length);
        Array.Clear(_facePlayers, 0, _facePlayers.Length);
        Node? root = EditorInterface.Singleton.GetEditedSceneRoot();
        if (root is null)
            return;
        ScanNode(root);
    }

    private void ScanNode(Node node)
    {
        if (_system is null && node is GHEG_System system)
            _system = system;
        if (node is GHEG_Avatar avatar)
        {
            int slot = (int)avatar.Slot;
            if (slot >= 0 && slot < 5 && _avatars[slot] is null)
                _avatars[slot] = avatar;
        }
        if (node is GHEG_FacePlayer player)
        {
            GHEG_Avatar? ownerAvatar = player.ResolveAvatar();
            if (ownerAvatar is not null)
            {
                int slot = (int)ownerAvatar.Slot;
                if (slot >= 0 && slot < 5 && _facePlayers[slot] is null)
                    _facePlayers[slot] = player;
            }
        }
        foreach (Node child in node.GetChildren())
            ScanNode(child);
    }

    private int TargetIndex => Mathf.Clamp(_targetSlot.Selected, 0, 4);

    private void OnConnectPressed()
    {
        if (_system is null) return;
        _system.ConnectToGHub = !_system.ConnectToGHub;
        RefreshUi();
    }

    private void OnTimelinePressed()
    {
        if (_system is null) return;
        _system.TimelineSyncEnabled = !_system.TimelineSyncEnabled;
        RefreshUi();
    }

    private void OnControlPortChanged(double value)
    {
        if (_refreshing || _system is null || _system.ConnectToGHub) return;
        _system.ControlPort = Mathf.Clamp((int)value, 1, 65535);
    }

    private void OnTargetChanged(long index)
    {
        _autoAssignStatus.Text = "Assign: Ready";
        SetStatusColor(_autoAssignStatus, false);
        RefreshUi();
    }

    private void OnSelectPressed()
    {
        GHEG_Avatar? avatar = _avatars[TargetIndex];
        if (avatar is null) return;
        EditorSelection selection = EditorInterface.Singleton.GetSelection();
        selection.Clear();
        selection.AddNode(avatar);
        EditorInterface.Singleton.EditNode(avatar);
    }

    private void OnAutoAssignPressed()
    {
        ScanEditedScene();

        int target = TargetIndex;
        var result = AutoAssignSlot(target);

        if (!result.HadAvatar)
        {
            SetAutoAssignResult(false, "Assign: FAILED\nAvatar not found.");
            return;
        }

        if (result.Changed)
            EditorInterface.Singleton.MarkSceneAsUnsaved();

        if (result.Complete)
        {
            SetAutoAssignResult(
                true,
                $"Assign: COMPLETE\nC{target + 1} references assigned.");
        }
        else
        {
            SetAutoAssignResult(false, "Assign: PARTIAL\n" + result.Detail);
        }

        RefreshUi();
    }

    private void OnAutoAssignAllPressed()
    {
        ScanEditedScene();

        bool anyAvatar = false;
        bool allComplete = true;
        bool anyChanged = false;
        var lines = new System.Collections.Generic.List<string>();

        for (int target = 0; target < 5; target++)
        {
            var result = AutoAssignSlot(target);
            if (!result.HadAvatar)
                continue;

            anyAvatar = true;
            anyChanged |= result.Changed;
            allComplete &= result.Complete;
            lines.Add(result.Complete
                ? $"C{target + 1} OK"
                : $"C{target + 1} PARTIAL");
        }

        if (!anyAvatar)
        {
            SetAutoAssignResult(false, "Assign ALL: FAILED\nNo Avatar found.");
            return;
        }

        if (anyChanged)
            EditorInterface.Singleton.MarkSceneAsUnsaved();

        string resultLines = string.Join("\n", lines);
        SetAutoAssignResult(
            allComplete,
            (allComplete ? "Assign ALL: COMPLETE" : "Assign ALL: PARTIAL") +
            "\n" + resultLines);

        RefreshUi();
    }

    private (bool HadAvatar, bool Complete, bool Changed, string Detail) AutoAssignSlot(int target)
    {
        GHEG_Avatar? avatar = target >= 0 && target < _avatars.Length
            ? _avatars[target]
            : null;

        if (avatar is null || !GodotObject.IsInstanceValid(avatar))
            return (false, false, false, "Avatar not found.");

        GHEG_TimelineAgent? timelineAgent =
            FindTimelineAgentAnchoredToAvatar(avatar, out bool timelineAmbiguous);
        AnimationPlayer? transport =
            FindUniqueDirectTransport(avatar, out bool transportAmbiguous);
        GHEG_ShapeKeys? shapeKeys =
            FindUniqueDirectChild<GHEG_ShapeKeys>(avatar, out bool shapeAmbiguous);
        GHEG_FacePlayer? facePlayer =
            FindUniqueDirectChild<GHEG_FacePlayer>(avatar, out bool faceAmbiguous);

        bool changed = false;
        var missing = new System.Collections.Generic.List<string>();

        if (timelineAmbiguous)
            missing.Add("Timeline Agent ambiguous");
        else if (timelineAgent is null)
            missing.Add("Set TimelineAgent.Avatar first");

        if (transportAmbiguous)
            missing.Add("Transport ambiguous");
        else if (transport is null)
            missing.Add("GHEG_Transport missing");

        if (shapeAmbiguous)
            missing.Add("ShapeKeys ambiguous");
        else if (shapeKeys is null)
            missing.Add("GHEG_ShapeKeys missing");

        if (faceAmbiguous)
            missing.Add("FacePlayer ambiguous");
        else if (facePlayer is null)
            missing.Add("GHEG_FacePlayer missing");

        if (timelineAgent is not null && transport is not null &&
            timelineAgent.TransportPlayer != transport)
        {
            timelineAgent.TransportPlayer = transport;
            timelineAgent.NotifyPropertyListChanged();
            changed = true;
        }

        if (shapeKeys is not null)
        {
            if (shapeKeys.Avatar != avatar)
            {
                shapeKeys.Avatar = avatar;
                changed = true;
            }

            if (shapeKeys.TargetRoot != avatar)
            {
                shapeKeys.TargetRoot = avatar;
                changed = true;
            }

            shapeKeys.NotifyPropertyListChanged();
        }

        if (facePlayer is not null && facePlayer.Avatar != avatar)
        {
            facePlayer.Avatar = avatar;
            facePlayer.NotifyPropertyListChanged();
            changed = true;
        }

        bool complete =
            timelineAgent is not null &&
            transport is not null &&
            shapeKeys is not null &&
            facePlayer is not null &&
            !timelineAmbiguous &&
            !transportAmbiguous &&
            !shapeAmbiguous &&
            !faceAmbiguous;

        string detail = missing.Count > 0
            ? string.Join("\n", missing)
            : "No changes required.";

        return (true, complete, changed, detail);
    }

    private void SetAutoAssignResult(bool complete, string text)
    {
        _autoAssignStatus.Text = text;
        SetStatusColor(_autoAssignStatus, complete);
    }

    private GHEG_TimelineAgent? FindTimelineAgentAnchoredToAvatar(
        GHEG_Avatar avatar,
        out bool ambiguous)
    {
        ambiguous = false;
        Node? root = EditorInterface.Singleton.GetEditedSceneRoot();
        if (root is null)
            return null;

        GHEG_TimelineAgent? found = null;
        int count = 0;
        FindTimelineAgentsRecursive(root, avatar, ref found, ref count);

        ambiguous = count > 1;
        return count == 1 ? found : null;
    }

    private static void FindTimelineAgentsRecursive(
        Node node,
        GHEG_Avatar avatar,
        ref GHEG_TimelineAgent? found,
        ref int count)
    {
        if (node is GHEG_TimelineAgent agent &&
            agent.Avatar is not null &&
            GodotObject.IsInstanceValid(agent.Avatar) &&
            agent.Avatar == avatar)
        {
            found = agent;
            count++;
            if (count > 1)
                return;
        }

        foreach (Node child in node.GetChildren())
        {
            FindTimelineAgentsRecursive(child, avatar, ref found, ref count);
            if (count > 1)
                return;
        }
    }

    private static AnimationPlayer? FindUniqueDirectTransport(
        GHEG_Avatar avatar,
        out bool ambiguous)
    {
        ambiguous = false;
        AnimationPlayer? found = null;
        int count = 0;

        foreach (Node child in avatar.GetChildren())
        {
            if (child is not AnimationPlayer player)
                continue;

            bool isTransport =
                player is GHEG_Transport ||
                string.Equals(
                    player.Name.ToString(),
                    "GHEG_Transport",
                    StringComparison.OrdinalIgnoreCase);

            if (!isTransport)
                continue;

            found = player;
            count++;
            if (count > 1)
            {
                ambiguous = true;
                return null;
            }
        }

        return count == 1 ? found : null;
    }

    private static T? FindUniqueDirectChild<T>(
        GHEG_Avatar avatar,
        out bool ambiguous)
        where T : Node
    {
        ambiguous = false;
        T? found = null;
        int count = 0;

        foreach (Node child in avatar.GetChildren())
        {
            if (child is not T candidate)
                continue;

            found = candidate;
            count++;
            if (count > 1)
            {
                ambiguous = true;
                return null;
            }
        }

        return count == 1 ? found : null;
    }

    private void OnFbxOutputChanged(string value)
    {
        if (_refreshing) return;
        string normalized = NormalizeResourceFolder(value);
        _lastFbxOutputFolder = normalized;
        _avatars[TargetIndex]?.SetFbxBridgeOutputFolderFromEditor(value);
    }
    private void OnFbxOutputBrowsePressed()
    {
        _outputDialogForFace = false;
        OpenOutputFolderDialog(_fbxOutput.Text);
    }

    private void OnFbxNameChanged(string value)
    {
        if (_refreshing) return;
        _avatars[TargetIndex]?.SetFbxBridgeAssetNameFromEditor(value);
    }
    private void OnFbxBridgePressed()
    {
        GHEG_Avatar? avatar = _avatars[TargetIndex];
        if (avatar is null)
            return;

        if (string.IsNullOrWhiteSpace(avatar.FbxBridgeOutputFolder))
            avatar.SetFbxBridgeOutputFolderFromEditor(_lastFbxOutputFolder);

        if (!GHEG_System.TryStartFbxBridge(avatar, out string reason))
            GD.PushWarning("[GHEG Control] FBX Bridge rejected / " + reason);
    }
    private void OnFbxImportPressed()
    {
        GHEG_Avatar? avatar = _avatars[TargetIndex];
        if (avatar is not null && !GHEG_System.TryImportLastFbxFor(avatar, out string reason))
            GD.PushWarning("[GHEG Control] FBX Import rejected / " + reason);
    }

    private void OnFaceStartChanged(double value) { if (!_refreshing && _facePlayers[TargetIndex] is { } p) p.StartFrame = (int)value; }
    private void OnFaceEndChanged(double value) { if (!_refreshing && _facePlayers[TargetIndex] is { } p) p.EndFrame = (int)value; }
    private void OnFaceFpsChanged(double value) { if (!_refreshing && _facePlayers[TargetIndex] is { } p) p.Fps = (int)value; }
    private void OnFaceOutputChanged(string value)
    {
        if (_refreshing) return;
        _lastFaceOutputFolder = NormalizeResourceFolder(value);
        if (_facePlayers[TargetIndex] is { } p)
            p.OutputFolder = value.Trim();
    }
    private void OnFaceOutputBrowsePressed()
    {
        _outputDialogForFace = true;
        OpenOutputFolderDialog(_faceOutput.Text);
    }
    private void OnFaceNameChanged(string value) { if (!_refreshing && _facePlayers[TargetIndex] is { } p) p.AssetName = value.Trim(); }
    private void OnFaceBakePressed()
    {
        GHEG_FacePlayer? player = _facePlayers[TargetIndex];
        if (player is null)
            return;

        if (string.IsNullOrWhiteSpace(player.OutputFolder))
        {
            player.OutputFolder = _lastFaceOutputFolder;
            EditorInterface.Singleton.MarkSceneAsUnsaved();
        }

        if (!GHEG_System.TryStartFacialBake(player, out string reason))
            GD.PushWarning("[GHEG Control] Facial Bake rejected / " + reason);
    }
    private void OnFaceCancelPressed()
    {
        GHEG_FacePlayer? player = _facePlayers[TargetIndex];
        if (player is not null && !GHEG_System.TryCancelFacialBake(player, out string reason))
            GD.PushWarning("[GHEG Control] Facial Bake cancel rejected / " + reason);
    }

    private static string NormalizeResourceFolder(string value)
    {
        string normalized = (value ?? string.Empty).Trim().Replace('\\', '/');
        if (string.IsNullOrWhiteSpace(normalized))
            return "res://";
        if (string.Equals(normalized, "res://", StringComparison.OrdinalIgnoreCase))
            return "res://";
        return normalized.TrimEnd('/');
    }

    private bool HasAnyValidAvatar()
    {
        foreach (GHEG_Avatar? avatar in _avatars)
        {
            if (avatar is not null && GodotObject.IsInstanceValid(avatar))
                return true;
        }
        return false;
    }

    private void OpenOutputFolderDialog(string currentPath)
    {
        string path = currentPath.Trim();
        if (!string.IsNullOrWhiteSpace(path) && path.StartsWith("res://", StringComparison.OrdinalIgnoreCase))
            _outputFolderDialog.CurrentDir = path;
        _outputFolderDialog.PopupCenteredRatio(0.72f);
    }

    private void OnOutputFolderSelected(string path)
    {
        string normalized = NormalizeResourceFolder(path);
        if (_outputDialogForFace)
        {
            _faceOutput.Text = normalized;
            OnFaceOutputChanged(normalized);
        }
        else
        {
            _fbxOutput.Text = normalized;
            OnFbxOutputChanged(normalized);
        }
    }

    private void OnSsVisualizerPressed()
    {
        SsVisualizerRequested?.Invoke(TargetIndex);
    }

    private void SetOperationEnabled(bool enabled)
    {
        _targetSlot.Disabled = !enabled;
        _selectButton.Disabled = !enabled || _avatars[TargetIndex] is null;
        _autoAssignButton.Disabled = !enabled || _avatars[TargetIndex] is null;
        _autoAssignAllButton.Disabled = !enabled || !HasAnyValidAvatar();
    }


    private static void ApplyCompactUi(Node node)
    {
        foreach (Node child in node.GetChildren())
        {
            if (child is Label label)
            {
                if (!label.HasThemeFontSizeOverride("font_size"))
                    label.AddThemeFontSizeOverride("font_size", RegularFontSize);
            }
            else if (child is Button button)
            {
                button.AddThemeFontSizeOverride("font_size", RegularFontSize);
                button.CustomMinimumSize = new Vector2(button.CustomMinimumSize.X, 28);
            }
            else if (child is LineEdit lineEdit)
            {
                lineEdit.AddThemeFontSizeOverride("font_size", RegularFontSize);
                lineEdit.CustomMinimumSize = new Vector2(lineEdit.CustomMinimumSize.X, 26);
            }
            else if (child is OptionButton option)
            {
                option.AddThemeFontSizeOverride("font_size", RegularFontSize);
                option.CustomMinimumSize = new Vector2(option.CustomMinimumSize.X, 28);
            }
            else if (child is SpinBox spin)
            {
                spin.CustomMinimumSize = new Vector2(spin.CustomMinimumSize.X, 26);
                spin.GetLineEdit().AddThemeFontSizeOverride("font_size", RegularFontSize);
            }

            ApplyCompactUi(child);
        }
    }


    private static void SetStatusColor(Label label, bool active)
    {
        if (active)
            label.AddThemeColorOverride("font_color", ActiveGreen);
        else
            label.RemoveThemeColorOverride("font_color");
    }

    private static void SetActiveButtonStyle(Button button, bool active)
    {
        if (!active)
        {
            button.RemoveThemeStyleboxOverride("normal");
            button.RemoveThemeStyleboxOverride("hover");
            button.RemoveThemeStyleboxOverride("pressed");
            button.RemoveThemeColorOverride("font_color");
            button.RemoveThemeColorOverride("font_hover_color");
            button.RemoveThemeColorOverride("font_pressed_color");
            return;
        }

        button.AddThemeStyleboxOverride("normal", MakeActiveButtonBox(ActiveBlue));
        button.AddThemeStyleboxOverride("hover", MakeActiveButtonBox(ActiveBlueHover));
        button.AddThemeStyleboxOverride("pressed", MakeActiveButtonBox(ActiveBluePressed));
        button.AddThemeColorOverride("font_color", Colors.White);
        button.AddThemeColorOverride("font_hover_color", Colors.White);
        button.AddThemeColorOverride("font_pressed_color", Colors.White);
    }

    private static StyleBoxFlat MakeActiveButtonBox(Color color)
    {
        return new StyleBoxFlat
        {
            BgColor = color,
            CornerRadiusTopLeft = 4,
            CornerRadiusTopRight = 4,
            CornerRadiusBottomLeft = 4,
            CornerRadiusBottomRight = 4,
            ContentMarginLeft = 8,
            ContentMarginRight = 8,
            ContentMarginTop = 3,
            ContentMarginBottom = 3,
        };
    }

    private HBoxContainer Row(int separation = 5)
    {
        var row = new HBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        row.AddThemeConstantOverride("separation", separation);
        return row;
    }

    private static VBoxContainer CompactColumn(int separation)
    {
        var column = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        column.AddThemeConstantOverride("separation", separation);
        return column;
    }

    private void AddSection(string text)
    {
        AddChild(new HSeparator());
        var label = new Label { Text = text, ThemeTypeVariation = "HeaderSmall" };
        label.AddThemeFontSizeOverride("font_size", TitleFontSize);
        AddChild(label);
    }
    private void AddLabeledControl(string label, Control control)
    {
        var row = Row();
        row.AddChild(new Label { Text = label, CustomMinimumSize = new Vector2(52, 0) });
        control.SizeFlagsHorizontal = SizeFlags.ExpandFill;
        row.AddChild(control);
        AddChild(row);
    }

    private void AddPathControl(string label, LineEdit edit, Button browse)
    {
        AddChild(new Label { Text = label });
        var row = Row(5);
        edit.SizeFlagsHorizontal = SizeFlags.ExpandFill;
        edit.CustomMinimumSize = new Vector2(0, edit.CustomMinimumSize.Y);
        browse.CustomMinimumSize = new Vector2(42, 0);
        row.AddChild(edit);
        row.AddChild(browse);
        AddChild(row);
    }

    private void AddStackedControl(string label, Control control)
    {
        AddChild(new Label { Text = label });
        control.SizeFlagsHorizontal = SizeFlags.ExpandFill;
        control.CustomMinimumSize = new Vector2(0, control.CustomMinimumSize.Y);
        AddChild(control);
    }
}
#endif
