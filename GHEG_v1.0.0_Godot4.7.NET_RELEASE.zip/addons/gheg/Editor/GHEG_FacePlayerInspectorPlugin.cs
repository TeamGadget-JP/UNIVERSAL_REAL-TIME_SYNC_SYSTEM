#if TOOLS
#nullable enable annotations
using Godot;

[Tool]
public partial class GHEG_FacePlayerInspectorPlugin : EditorInspectorPlugin
{
    public override bool _CanHandle(GodotObject @object)
    {
        return @object is GHEG_FacePlayer;
    }

    public override void _ParseEnd(GodotObject @object)
    {
        if (@object is not GHEG_FacePlayer player)
            return;

        var actions = new GHEG_FacePlayerInspectorActions();
        actions.Bind(player);
        AddCustomControl(actions);
    }
}
#endif
