#nullable enable annotations
using System;
using Godot;

/// <summary>
/// Per-character Timeline transport adapter for GHEG.
///
/// Add one Agent node per character and set Avatar as the explicit setup anchor.
/// After the character child nodes are in place, use GHEG Control > AUTO ASSIGN
/// to populate TransportPlayer safely.
///
/// The dedicated transport player is the only AnimationPlayer this Agent reads
/// or writes. Imported / baked character AnimationPlayers are intentionally not
/// used for Canonical Timeline transport, preventing Body streaming and local
/// animation tracks from fighting over the same Skeleton pose.
/// </summary>
[Tool]
[GlobalClass]
public partial class GHEG_TimelineAgent : Node3D
{
    private const double TimelineTimeEpsilon = 0.0001;
    private const double TimelineEndEpsilon = 0.001;
    private const double DefaultEditorFocusGuardSeconds = 0.25;
    private static readonly StringName RootLibraryName = new("");
    private static readonly StringName TransportAnimationName = new("GHEG_Transport");

    [ExportGroup("Timeline")]
    [Export]
    public bool Active { get; set; } = true;

    [Export]
    public GHEG_Avatar? Avatar { get; set; }

    [ExportGroup("Transport")]
    [Export]
    public AnimationPlayer? TransportPlayer { get; set; }

    [Export(PropertyHint.Range, "1.0,3600.0,1.0,or_greater")]
    public double TransportLengthSeconds { get; set; } = 60.0;

    private bool _editorFocusGuardActive;
    private bool _transportPrimed;
    private ulong _primedTransportPlayerId;
    private double _editorFocusGuardUntil;
    private double _editorFocusAnchorTime;
    private bool _editorFocusAnchorPlaying;

    internal GHEG_Avatar? ResolveAvatar()
    {
        return Avatar is not null && GodotObject.IsInstanceValid(Avatar)
            ? Avatar
            : null;
    }

    internal AnimationPlayer? ResolvePlayer()
    {
        if (TransportPlayer is null ||
            !GodotObject.IsInstanceValid(TransportPlayer))
        {
            return null;
        }

        EnsureTransportAnimation(TransportPlayer);
        return TransportPlayer;
    }

    internal bool TryReadState(
        out double timeSeconds,
        out bool isPlaying)
    {
        timeSeconds = 0.0;
        isPlaying = false;

        AnimationPlayer? player = ResolvePlayer();
        if (player is null || !TryGetAssignedAnimationName(player, out _))
            return false;

        timeSeconds = Math.Max(0.0, player.CurrentAnimationPosition);
        isPlaying = player.IsPlaying();
        return true;
    }

    internal void ApplyState(double timeSeconds, bool isPlaying)
    {
        AnimationPlayer? player = ResolvePlayer();
        if (player is null || !TryGetAssignedAnimationName(player, out _))
            return;

        EnsureTransportCapacity(player, timeSeconds);

        double length = Math.Max(0.0, player.CurrentAnimationLength);
        double clampedTime = Math.Max(0.0, timeSeconds);

        if (length > 0.0)
            clampedTime = Math.Min(clampedTime, length);

        if (Math.Abs(player.CurrentAnimationPosition - clampedTime) >
            TimelineTimeEpsilon)
        {
            // The transport animation has no tracks. Seeking it changes only
            // transport time; it cannot write Character/Skeleton transforms.
            player.Seek(clampedTime, true, true);
        }

        bool canContinuePlaying =
            isPlaying &&
            (length <= 0.0 || clampedTime < length - TimelineEndEpsilon);

        if (canContinuePlaying)
        {
            if (!player.IsPlaying())
                player.Play(TransportAnimationName);
        }
        else if (player.IsPlaying())
        {
            player.Pause();
        }
    }

    internal bool IsAtNaturalEnd(double timeSeconds)
    {
        AnimationPlayer? player = ResolvePlayer();
        if (player is null || !TryGetAssignedAnimationName(player, out _))
            return false;

        double length = Math.Max(0.0, player.CurrentAnimationLength);
        return length > 0.0 && timeSeconds >= length - TimelineEndEpsilon;
    }

    internal ulong RuntimeId => GetInstanceId();

    internal bool IsEditorFocused()
    {
#if TOOLS
        if (!Engine.IsEditorHint())
            return false;

        AnimationPlayer? player = ResolvePlayer();
        if (player is null)
            return false;

        EditorSelection selection = EditorInterface.Singleton.GetSelection();
        foreach (Node selected in selection.GetSelectedNodes())
        {
            if (selected.GetInstanceId() == player.GetInstanceId())
                return true;
        }
#endif
        return false;
    }

    internal void BeginEditorFocusGuard(
        double now,
        double anchorTime,
        bool anchorPlaying)
    {
        _editorFocusAnchorTime = Math.Max(0.0, anchorTime);
        _editorFocusAnchorPlaying = anchorPlaying;
        _editorFocusGuardUntil = now + DefaultEditorFocusGuardSeconds;
        _editorFocusGuardActive = true;
        ApplyState(_editorFocusAnchorTime, _editorFocusAnchorPlaying);
    }

    internal bool ProcessEditorFocusGuard(double now)
    {
        if (!_editorFocusGuardActive)
            return false;

        if (now > _editorFocusGuardUntil || !IsEditorFocused())
        {
            _editorFocusGuardActive = false;
            return false;
        }

        // Godot's Animation editor can seek a newly focused AnimationPlayer
        // (commonly to 0s). Keep that editor-side seek from becoming a URSS
        // Timeline command during the short settle window.
        ApplyState(_editorFocusAnchorTime, _editorFocusAnchorPlaying);
        return true;
    }

    internal bool IsEditorFocusGuardActive(double now)
    {
        return _editorFocusGuardActive && now <= _editorFocusGuardUntil;
    }

    internal void ResetEditorFocusGuard()
    {
        _editorFocusGuardActive = false;
        _editorFocusGuardUntil = 0.0;
        _editorFocusAnchorTime = 0.0;
        _editorFocusAnchorPlaying = false;
    }

    private void EnsureTransportAnimation(AnimationPlayer player)
    {
        AnimationLibrary? library = null;

        if (player.HasAnimationLibrary(RootLibraryName))
        {
            library = player.GetAnimationLibrary(RootLibraryName);
        }
        else
        {
            library = new AnimationLibrary();
            Error error = player.AddAnimationLibrary(RootLibraryName, library);
            if (error != Error.Ok)
                return;
        }

        if (!library.HasAnimation(TransportAnimationName))
        {
            Animation transport = new()
            {
                Length = (float)Math.Max(1.0, TransportLengthSeconds),
                LoopMode = Animation.LoopModeEnum.None,
            };

            if (library.AddAnimation(TransportAnimationName, transport) != Error.Ok)
                return;
        }

        Animation animation = library.GetAnimation(TransportAnimationName);
        double desiredLength = Math.Max(1.0, TransportLengthSeconds);
        if (animation.Length < desiredLength)
            animation.Length = (float)desiredLength;

        // A scene can deserialize assigned_animation without recreating
        // AnimationPlayer's internal playback.current state. In that case the
        // first Position/Length read prints "AnimationPlayer has no current
        // animation" even though AssignedAnimation already has our clip.
        //
        // Force the public AssignedAnimation setter exactly once per resolved
        // transport player. Godot's setter rebuilds playback.current. Do not do
        // this every poll: assigning while paused resets the transport time to
        // zero and would destroy local scrub input.
        ulong playerId = player.GetInstanceId();
        if (_primedTransportPlayerId != playerId)
        {
            _primedTransportPlayerId = playerId;
            _transportPrimed = false;
        }

        if (!_transportPrimed || player.AssignedAnimation != TransportAnimationName)
        {
            player.AssignedAnimation = TransportAnimationName;
            _transportPrimed = true;
        }
    }

    private void EnsureTransportCapacity(
        AnimationPlayer player,
        double requestedTimeSeconds)
    {
        if (requestedTimeSeconds <= Math.Max(0.0, player.CurrentAnimationLength))
            return;

        if (!player.HasAnimationLibrary(RootLibraryName))
            return;

        AnimationLibrary library = player.GetAnimationLibrary(RootLibraryName);
        if (!library.HasAnimation(TransportAnimationName))
            return;

        Animation animation = library.GetAnimation(TransportAnimationName);

        // Empty transport clips are cheap, so grow rather than clamp Canonical
        // Time. Round up with a small margin to avoid repeated resize churn.
        double expanded = Math.Ceiling(Math.Max(
            requestedTimeSeconds + 1.0,
            Math.Max(1.0, TransportLengthSeconds)));

        animation.Length = (float)expanded;
    }

    private static bool TryGetAssignedAnimationName(
        AnimationPlayer player,
        out string animationName)
    {
        animationName = player.AssignedAnimation.ToString();
        return !string.IsNullOrWhiteSpace(animationName);
    }

}
