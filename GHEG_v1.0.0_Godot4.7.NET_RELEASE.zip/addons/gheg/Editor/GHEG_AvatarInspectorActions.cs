#if TOOLS
#nullable enable annotations
using Godot;

/// <summary>
/// Compact GHEG_Avatar action surface shown between Body and Advanced.
/// Keeps setup actions discoverable without exposing serialized cache payloads.
/// </summary>
[Tool]
public partial class GHEG_AvatarInspectorActions : VBoxContainer
{
    private const double RefreshIntervalSeconds = 0.25;

    private readonly Label _statusLamp = new();
    private readonly Label _statusText = new();
    private readonly Button _resetPoseButton = new();
    private readonly Button _applySmartSwizzleButton = new();
    private readonly Button _deleteCacheButton = new();
    private readonly LineEdit _fbxOutputFolder = new();
    private readonly Button _fbxOutputFolderBrowseButton = new();
    private readonly FileDialog _fbxOutputFolderDialog = new();
    private readonly LineEdit _fbxAssetName = new();
    private readonly Button _fbxBridgeButton = new();
    private readonly Button _fbxImportButton = new();
    private readonly Label _fbxStatus = new();

    private GHEG_Avatar? _avatar;
    private bool _refreshingFields;
    private double _refreshRemaining;
    private bool _signalsConnected;

    public GHEG_AvatarInspectorActions()
    {
        SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;

        AddChild(new HSeparator());

        var poseHeader = new Label
        {
            Text = "Pose",
        };
        poseHeader.AddThemeFontSizeOverride("font_size", 14);
        AddChild(poseHeader);

        _resetPoseButton.Text = "Reset Pose";
        _resetPoseButton.TooltipText =
            "Restore this Skeleton3D to its imported rest pose. " +
            "An active live Body stream can overwrite it again on the next packet.";
        _resetPoseButton.SizeFlagsHorizontal =
            Control.SizeFlags.ExpandFill;
        AddChild(_resetPoseButton);

        var smartSwizzleHeader = new Label
        {
            Text = "Smart Swizzle",
        };
        smartSwizzleHeader.AddThemeFontSizeOverride("font_size", 14);
        AddChild(smartSwizzleHeader);

        var statusRow = new HBoxContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
        };

        _statusLamp.Text = "●";
        _statusLamp.TooltipText =
            "Smart Swizzle cache status: Missing / Ready / Stale.";
        _statusLamp.AddThemeFontSizeOverride("font_size", 16);
        statusRow.AddChild(_statusLamp);

        var statusCaption = new Label
        {
            Text = "SS Cache",
        };
        statusRow.AddChild(statusCaption);

        _statusText.SizeFlagsHorizontal =
            Control.SizeFlags.ExpandFill;
        _statusText.HorizontalAlignment =
            HorizontalAlignment.Right;
        statusRow.AddChild(_statusText);

        AddChild(statusRow);

        var buttonRow = new HBoxContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
        };

        _applySmartSwizzleButton.Text = "Apply Smart Swizzle";
        _applySmartSwizzleButton.TooltipText =
            "Request Smart Swizzle now. An active G-HUB Character route is required.";
        _applySmartSwizzleButton.SizeFlagsHorizontal =
            Control.SizeFlags.ExpandFill;
        buttonRow.AddChild(_applySmartSwizzleButton);

        _deleteCacheButton.Text = "Delete SS Cache";
        _deleteCacheButton.TooltipText =
            "Delete the serialized Smart Swizzle cache. " +
            "The current live session can continue; the next route will recapture it.";
        _deleteCacheButton.SizeFlagsHorizontal =
            Control.SizeFlags.ExpandFill;
        buttonRow.AddChild(_deleteCacheButton);

        AddChild(buttonRow);

        AddChild(new HSeparator());

        var fbxHeader = new Label
        {
            Text = "FBX Bridge",
        };
        fbxHeader.AddThemeFontSizeOverride("font_size", 14);
        AddChild(fbxHeader);

        AddChild(new Label { Text = "Output Folder" });

        var fbxOutputFolderRow = new HBoxContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
        };

        _fbxOutputFolder.PlaceholderText =
            "res://Gadget/G-HUB/Animations/Character1";
        _fbxOutputFolder.TooltipText =
            "Project-relative folder for exported FBX files. Must start with res://.";
        _fbxOutputFolder.SizeFlagsHorizontal =
            Control.SizeFlags.ExpandFill;
        fbxOutputFolderRow.AddChild(_fbxOutputFolder);

        _fbxOutputFolderBrowseButton.Text = "...";
        _fbxOutputFolderBrowseButton.TooltipText =
            "Choose an existing project folder.";
        _fbxOutputFolderBrowseButton.CustomMinimumSize = new Vector2(42.0f, 0.0f);
        fbxOutputFolderRow.AddChild(_fbxOutputFolderBrowseButton);

        AddChild(fbxOutputFolderRow);

        _fbxOutputFolderDialog.FileMode =
            FileDialog.FileModeEnum.OpenDir;
        _fbxOutputFolderDialog.Access =
            FileDialog.AccessEnum.Resources;
        _fbxOutputFolderDialog.Title = "Select FBX Output Folder";
        _fbxOutputFolderDialog.FolderCreationEnabled = true;
        AddChild(_fbxOutputFolderDialog);

        AddChild(new Label { Text = "Asset Name" });
        _fbxAssetName.PlaceholderText = "Character1";
        _fbxAssetName.TooltipText =
            "Base name for the FBX asset. A timestamp is added automatically.";
        AddChild(_fbxAssetName);

        _fbxBridgeButton.Text = "FBX Bridge";
        _fbxBridgeButton.TooltipText =
            "Export this routed Character from Cascadeur to a standard FBX file in the Godot project.";
        _fbxBridgeButton.SizeFlagsHorizontal =
            Control.SizeFlags.ExpandFill;
        AddChild(_fbxBridgeButton);

        _fbxImportButton.Text = "Import FBX";
        _fbxImportButton.TooltipText =
            "Explicitly import the most recently exported FBX into Godot. " +
            "Importer warnings/errors are reported separately from FBX Bridge export.";
        _fbxImportButton.SizeFlagsHorizontal =
            Control.SizeFlags.ExpandFill;
        AddChild(_fbxImportButton);

        _fbxStatus.Text = "Status: Ready";
        _fbxStatus.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
        _fbxStatus.ClipText = true;
        AddChild(_fbxStatus);

        SetProcess(true);
    }

    public override void _EnterTree()
    {
        ConnectSignals();
        SetProcess(true);
    }

    public override void _ExitTree()
    {
        DisconnectSignals();
        _avatar = null;
        SetProcess(false);
    }

    public void BindAvatar(GHEG_Avatar avatar)
    {
        _avatar = avatar;
        RefreshUi();
    }

    public override void _Process(double delta)
    {
        _refreshRemaining -= delta;
        if (_refreshRemaining > 0.0)
            return;

        _refreshRemaining = RefreshIntervalSeconds;
        RefreshUi();
    }

    private void RefreshUi()
    {
        GHEG_Avatar? avatar = _avatar;
        if (avatar is null ||
            !GodotObject.IsInstanceValid(avatar))
        {
            _statusText.Text = "Unavailable";
            _resetPoseButton.Disabled = true;
            _applySmartSwizzleButton.Disabled = true;
            _deleteCacheButton.Disabled = true;
            _fbxBridgeButton.Disabled = true;
            _fbxImportButton.Disabled = true;
            _fbxStatus.Text = "Status: Unavailable";
            SetLampColor(new Color(0.55f, 0.55f, 0.55f));
            return;
        }

        GHEG_Avatar.SmartSwizzleCacheState state =
            avatar.CurrentSmartSwizzleCacheState;

        _statusText.Text = avatar.SmartSwizzleCacheStatus;

        switch (state)
        {
            case GHEG_Avatar.SmartSwizzleCacheState.Ready:
                SetLampColor(new Color(0.35f, 0.85f, 0.45f));
                break;

            case GHEG_Avatar.SmartSwizzleCacheState.Stale:
                SetLampColor(new Color(0.95f, 0.70f, 0.20f));
                break;

            default:
                SetLampColor(new Color(0.55f, 0.55f, 0.55f));
                break;
        }

        _resetPoseButton.Disabled =
            avatar.ResolveSkeleton() is null;

        _applySmartSwizzleButton.Disabled =
            !GHEG_System.HasActiveCharacterRouteFor(avatar);

        _deleteCacheButton.Disabled =
            state == GHEG_Avatar.SmartSwizzleCacheState.Missing;

        _refreshingFields = true;
        if (!_fbxOutputFolder.HasFocus())
            _fbxOutputFolder.Text = avatar.EffectiveFbxBridgeOutputFolder;
        if (!_fbxAssetName.HasFocus())
            _fbxAssetName.Text = avatar.EffectiveFbxBridgeAssetName;
        _refreshingFields = false;

        GHEG_System.FbxBridgeUiState fbxState =
            GHEG_System.GetFbxBridgeUiState(avatar);

        bool routeActive = GHEG_System.HasActiveCharacterRouteFor(avatar);
        _fbxBridgeButton.Disabled =
            !routeActive || fbxState.Busy || fbxState.Importing;

        bool importReady =
            fbxState.HasLastResult &&
            fbxState.LastSucceeded &&
            !string.IsNullOrWhiteSpace(fbxState.LastResourcePath);
        _fbxImportButton.Disabled =
            !importReady || fbxState.Busy || fbxState.Importing;
        _fbxImportButton.Text =
            fbxState.ImportingForThisAvatar
                ? "Importing FBX..."
                : fbxState.LastImported
                    ? "Reimport FBX"
                    : "Import FBX";

        if (fbxState.ImportingForThisAvatar)
        {
            _fbxStatus.Text = "Status: Importing FBX into Godot...";
        }
        else if (fbxState.Importing)
        {
            _fbxStatus.Text = "Status: Another Character FBX is importing...";
        }
        else if (fbxState.BusyForThisAvatar)
        {
            _fbxStatus.Text = "Status: " + fbxState.PhaseLabel;
        }
        else if (fbxState.Busy)
        {
            _fbxStatus.Text = "Status: " + fbxState.PhaseLabel;
        }
        else if (fbxState.HasLastResult)
        {
            _fbxStatus.TooltipText = string.Empty;
            if (!fbxState.LastSucceeded)
            {
                _fbxStatus.Text = "Status: Failed - see Output";
            }
            else if (!fbxState.LastImported)
            {
                _fbxStatus.Text = "Status: Ready to import";
            }
            else
            {
                _fbxStatus.Text = "Status: Ready";
            }
        }
        else if (!routeActive)
        {
            _fbxStatus.Text = "Status: Connect this Character route first.";
        }
        else
        {
            _fbxStatus.Text = "Status: Ready";
        }
    }


    private void OnResetPosePressed()
    {
        GHEG_Avatar? avatar = _avatar;
        if (avatar is null ||
            !GodotObject.IsInstanceValid(avatar))
        {
            return;
        }

        if (!avatar.ResetPoseToSkeletonRest(out string error))
        {
            GD.PushWarning(
                $"[GHEG] Reset Pose skipped / {error}");
        }
    }

    private void OnApplySmartSwizzlePressed()
    {
        GHEG_Avatar? avatar = _avatar;
        if (avatar is null ||
            !GodotObject.IsInstanceValid(avatar))
        {
            return;
        }

        if (!GHEG_System.RequestSmartSwizzleFor(
            avatar,
            out string reason))
        {
            GD.PushWarning(
                $"[GHEG] Smart Swizzle was not requested / {reason}");
        }
    }

    private void OnDeleteCachePressed()
    {
        GHEG_Avatar? avatar = _avatar;
        if (avatar is null ||
            !GodotObject.IsInstanceValid(avatar))
        {
            return;
        }

        avatar.DeleteSmartSwizzleCache();
        RefreshUi();
    }

    private void OnFbxOutputFolderBrowsePressed()
    {
        GHEG_Avatar? avatar = _avatar;
        if (avatar is null || !GodotObject.IsInstanceValid(avatar))
            return;

        string current = avatar.EffectiveFbxBridgeOutputFolder;
        _fbxOutputFolderDialog.CurrentDir =
            current.StartsWith("res://") ? current : "res://";
        _fbxOutputFolderDialog.PopupCenteredRatio(0.75f);
    }

    private void OnFbxOutputFolderSelected(string directory)
    {
        GHEG_Avatar? avatar = _avatar;
        if (avatar is null || !GodotObject.IsInstanceValid(avatar))
            return;

        string normalized = directory.Replace('\\', '/').TrimEnd('/');
        if (!normalized.StartsWith("res://"))
        {
            GD.PushWarning(
                "[GHEG FBX Bridge] Output folder must be inside the Godot project (res://).");
            return;
        }

        _refreshingFields = true;
        _fbxOutputFolder.Text = normalized;
        _refreshingFields = false;

        avatar.SetFbxBridgeOutputFolderFromEditor(normalized);
        RefreshUi();
    }

    private void OnFbxOutputFolderChanged(string value)
    {
        if (_refreshingFields)
            return;

        GHEG_Avatar? avatar = _avatar;
        if (avatar is null || !GodotObject.IsInstanceValid(avatar))
            return;

        avatar.SetFbxBridgeOutputFolderFromEditor(value);
    }

    private void OnFbxAssetNameChanged(string value)
    {
        if (_refreshingFields)
            return;

        GHEG_Avatar? avatar = _avatar;
        if (avatar is null || !GodotObject.IsInstanceValid(avatar))
            return;

        avatar.SetFbxBridgeAssetNameFromEditor(value);
    }

    private void OnFbxBridgePressed()
    {
        GHEG_Avatar? avatar = _avatar;
        if (avatar is null || !GodotObject.IsInstanceValid(avatar))
            return;

        if (!GHEG_System.TryStartFbxBridge(avatar, out string reason))
        {
            GD.PushWarning(
                $"[GHEG FBX Bridge] Request rejected / {reason}");
        }

        RefreshUi();
    }

    private void OnFbxImportPressed()
    {
        GHEG_Avatar? avatar = _avatar;
        if (avatar is null || !GodotObject.IsInstanceValid(avatar))
            return;

        if (!GHEG_System.TryImportLastFbxFor(avatar, out string reason))
        {
            GD.PushWarning(
                $"[GHEG FBX Bridge] Import rejected / {reason}");
        }

        RefreshUi();
    }

    private void ConnectSignals()
    {
        if (_signalsConnected)
            return;

        _resetPoseButton.Pressed += OnResetPosePressed;
        _applySmartSwizzleButton.Pressed +=
            OnApplySmartSwizzlePressed;
        _deleteCacheButton.Pressed += OnDeleteCachePressed;
        _fbxOutputFolder.TextChanged += OnFbxOutputFolderChanged;
        _fbxOutputFolderBrowseButton.Pressed += OnFbxOutputFolderBrowsePressed;
        _fbxOutputFolderDialog.DirSelected += OnFbxOutputFolderSelected;
        _fbxAssetName.TextChanged += OnFbxAssetNameChanged;
        _fbxBridgeButton.Pressed += OnFbxBridgePressed;
        _fbxImportButton.Pressed += OnFbxImportPressed;
        _signalsConnected = true;
    }

    private void DisconnectSignals()
    {
        if (!_signalsConnected)
            return;

        _resetPoseButton.Pressed -= OnResetPosePressed;
        _applySmartSwizzleButton.Pressed -=
            OnApplySmartSwizzlePressed;
        _deleteCacheButton.Pressed -= OnDeleteCachePressed;
        _fbxOutputFolder.TextChanged -= OnFbxOutputFolderChanged;
        _fbxOutputFolderBrowseButton.Pressed -= OnFbxOutputFolderBrowsePressed;
        _fbxOutputFolderDialog.DirSelected -= OnFbxOutputFolderSelected;
        _fbxAssetName.TextChanged -= OnFbxAssetNameChanged;
        _fbxBridgeButton.Pressed -= OnFbxBridgePressed;
        _fbxImportButton.Pressed -= OnFbxImportPressed;
        _signalsConnected = false;
    }

    private void SetLampColor(Color color)
    {
        _statusLamp.AddThemeColorOverride(
            "font_color",
            color);
    }
}
#endif
