#if TOOLS
#nullable enable annotations
using Godot;
using GHEG.Internal.Core;
using GHEG.Internal.Network;

/// <summary>
/// Godot editor entry point for GHEG.
/// Coordinates the Editor -> Game -> Editor endpoint handoff.
/// </summary>
[Tool]
public partial class GHEG_EditorPlugin : EditorPlugin
{
    private const ulong BuildHandoffTimeoutMsec = 3000;
    private const ulong DockAttachDelayMsec = 150;

    private bool _wasPlaying;
    private bool _buildHandoffArmed;
    private ulong _buildHandoffStartedMsec;
    private GHEG_AvatarInspectorPlugin? _avatarInspectorPlugin;
    private GHEG_SystemInspectorPlugin? _systemInspectorPlugin;
    private GHEG_FacePlayerInspectorPlugin? _facePlayerInspectorPlugin;
    private EditorDock? _dockHost;
    private GHEG_ControlDock? _controlDock;
    private GHEG_SSVisualizerWindow? _ssVisualizer;
    private GHEG_SSSceneGizmoPlugin? _ssSceneGizmoPlugin;
    private bool _dockAttachPending;
    private ulong _dockAttachStartedMsec;
    private bool _dockFocusPending;
    private ulong _dockFocusStartedMsec;

    public override void _EnterTree()
    {
        GHEG_AssemblyReloadGuard.EnsureRegistered();

        _avatarInspectorPlugin =
            new GHEG_AvatarInspectorPlugin();
        AddInspectorPlugin(_avatarInspectorPlugin);

        _systemInspectorPlugin =
            new GHEG_SystemInspectorPlugin();
        AddInspectorPlugin(_systemInspectorPlugin);

        _facePlayerInspectorPlugin =
            new GHEG_FacePlayerInspectorPlugin();
        AddInspectorPlugin(_facePlayerInspectorPlugin);

        // SS scene gizmos are registered lazily when the user opens the
        // visualizer. Hot disabling/re-enabling an EditorNode3DGizmoPlugin
        // while Skeleton3D nodes are already loaded can make Godot 4.7.2
        // rebuild gizmos from a worker thread, which trips Node thread guards.
        // Keeping the gizmo plugin out of the normal plugin enable path also
        // avoids touching every Skeleton3D when diagnostics are not in use.

        // EditorDock can briefly disturb the editor layout when attached during
        // the same _EnterTree pass as plugin enable. Defer only the dock attach;
        // inspector plugins and diagnostics remain available immediately.
        _dockAttachPending = true;
        _dockAttachStartedMsec = Time.GetTicksMsec();

        GHEG_EditorState.SetPluginEnabled(true);

        _wasPlaying =
            EditorInterface.Singleton.IsPlayingScene();

        GHEG_EditorState.SetRuntimeHandoff(_wasPlaying);

        ProcessMode = ProcessModeEnum.Always;
        SetProcess(true);

        ; // routine editor lifecycle log suppressed
    }

    public override void _ExitTree()
    {
        _dockAttachPending = false;
        _dockFocusPending = false;

        if (_controlDock is not null)
            _controlDock.SsVisualizerRequested -= OnSsVisualizerRequested;

        if (_ssVisualizer is not null)
        {
            _ssVisualizer.QueueFree();
            _ssVisualizer = null;
        }

        if (_ssSceneGizmoPlugin is not null)
        {
            _ssSceneGizmoPlugin.ClearTarget();
            RemoveNode3DGizmoPlugin(_ssSceneGizmoPlugin);
            _ssSceneGizmoPlugin = null;
        }

        if (_dockHost is not null)
        {
            RemoveDock(_dockHost);
            _dockHost.QueueFree();
            _dockHost = null;
            _controlDock = null;
        }

        if (_facePlayerInspectorPlugin is not null)
        {
            RemoveInspectorPlugin(_facePlayerInspectorPlugin);
            _facePlayerInspectorPlugin = null;
        }

        if (_systemInspectorPlugin is not null)
        {
            RemoveInspectorPlugin(_systemInspectorPlugin);
            _systemInspectorPlugin = null;
        }

        if (_avatarInspectorPlugin is not null)
        {
            RemoveInspectorPlugin(_avatarInspectorPlugin);
            _avatarInspectorPlugin = null;
        }

        GHEG_GHubClient.ShutdownAllForAssemblyReload();

        GHEG_EditorState.SetRuntimeHandoff(false);
        GHEG_EditorState.SetPluginEnabled(false);

        ; // routine editor lifecycle log suppressed
    }

    private void TryAttachControlDock()
    {
        if (!_dockAttachPending)
            return;

        if (Time.GetTicksMsec() - _dockAttachStartedMsec < DockAttachDelayMsec)
            return;

        _dockAttachPending = false;

        _controlDock = new GHEG_ControlDock();
        _dockHost = new EditorDock
        {
            Title = "GHEG",
            DefaultSlot = EditorDock.DockSlot.RightUl,
            AvailableLayouts = EditorDock.DockLayout.Vertical | EditorDock.DockLayout.Floating,
        };
        _dockHost.AddChild(_controlDock);
        AddDock(_dockHost);
        _controlDock.SsVisualizerRequested += OnSsVisualizerRequested;

        // Godot 4.7 can leave the shared right dock column in an incomplete
        // layout state immediately after a plugin adds a new EditorDock.
        // Manually selecting the GHEG tab resolves it; reproduce that action
        // once, after the editor has had time to finish attaching the dock.
        _dockFocusPending = true;
        _dockFocusStartedMsec = Time.GetTicksMsec();
    }

    private void TryStabilizeControlDockLayout()
    {
        if (!_dockFocusPending)
            return;

        if (Time.GetTicksMsec() - _dockFocusStartedMsec < 120)
            return;

        _dockFocusPending = false;

        if (_dockHost is null || !GodotObject.IsInstanceValid(_dockHost))
            return;

        _dockHost.MakeVisible();
    }

    private void OnSsVisualizerRequested(int slotIndex)
    {
        EnsureSsVisualizer();

        if (_ssVisualizer is null || !GodotObject.IsInstanceValid(_ssVisualizer))
            return;

        _ssVisualizer.OpenForSlot(slotIndex);
    }

    private void EnsureSsVisualizer()
    {
        if (_ssSceneGizmoPlugin is null)
        {
            _ssSceneGizmoPlugin = new GHEG_SSSceneGizmoPlugin();
            AddNode3DGizmoPlugin(_ssSceneGizmoPlugin);
        }

        if (_ssVisualizer is null || !GodotObject.IsInstanceValid(_ssVisualizer))
        {
            _ssVisualizer = new GHEG_SSVisualizerWindow(_ssSceneGizmoPlugin);
            EditorInterface.Singleton.GetBaseControl().AddChild(_ssVisualizer);
        }
    }

    public override void _EnablePlugin()
    {
        GHEG_EditorState.SetPluginEnabled(true);
        ; // routine editor lifecycle log suppressed
    }

    public override void _DisablePlugin()
    {
        GHEG_GHubClient.ShutdownAllForAssemblyReload();

        GHEG_EditorState.SetRuntimeHandoff(false);
        GHEG_EditorState.SetPluginEnabled(false);

        ; // routine editor lifecycle log suppressed
    }

    public override bool _Build()
    {
        // Godot calls _Build() immediately before launching the project.
        // Suspend the Editor endpoint synchronously so the Game process can
        // take ownership without creating two GHEG endpoints at once.
        GHEG_EditorState.SetRuntimeHandoff(true);

        _buildHandoffArmed = true;
        _buildHandoffStartedMsec = Time.GetTicksMsec();

        ; // routine editor lifecycle log suppressed

        return true;
    }

    public override void _Process(double delta)
    {
        TryAttachControlDock();
        TryStabilizeControlDockLayout();

        bool playing =
            EditorInterface.Singleton.IsPlayingScene();

        if (playing)
        {
            _buildHandoffArmed = false;

            if (!_wasPlaying)
            {
                GHEG_EditorState.SetRuntimeHandoff(true);
                ; // routine editor lifecycle log suppressed
            }
        }
        else
        {
            if (_wasPlaying)
            {
                GHEG_EditorState.SetRuntimeHandoff(false);
                ; // routine editor lifecycle log suppressed
            }
            else if (_buildHandoffArmed)
            {
                ulong elapsed =
                    Time.GetTicksMsec() -
                    _buildHandoffStartedMsec;

                if (elapsed >= BuildHandoffTimeoutMsec)
                {
                    _buildHandoffArmed = false;
                    GHEG_EditorState.SetRuntimeHandoff(false);

                    ; // routine editor lifecycle log suppressed
                }
            }
        }

        _wasPlaying = playing;
    }
}
#endif
