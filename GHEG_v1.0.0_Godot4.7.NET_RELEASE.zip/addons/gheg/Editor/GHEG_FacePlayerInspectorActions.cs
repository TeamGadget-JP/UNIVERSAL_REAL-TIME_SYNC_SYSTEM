#if TOOLS
#nullable enable annotations
using Godot;

/// <summary>
/// Inspector action surface for per-character Facial Bake configuration.
/// Frequent bake controls are also available from the GHEG Control dock.
/// </summary>
[Tool]
public partial class GHEG_FacePlayerInspectorActions : VBoxContainer
{
    private const double RefreshIntervalSeconds = 0.2;

    private readonly Button _bakeButton = new();
    private readonly Button _cancelButton = new();
    private readonly Label _status = new();
    private readonly Label _lastAsset = new();

    private GHEG_FacePlayer? _player;
    private bool _signalsConnected;
    private double _refreshRemaining;

    public GHEG_FacePlayerInspectorActions()
    {
        SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
        AddChild(new HSeparator());

        var header = new Label { Text = "SE Offline Facial Bake" };
        header.AddThemeFontSizeOverride("font_size", 14);
        AddChild(header);

        _bakeButton.Text = "FACIAL BAKE";
        _bakeButton.TooltipText =
            "Bake the selected Character Slot from ShapeMixer into a standard Godot Animation resource.";
        _bakeButton.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
        AddChild(_bakeButton);

        _cancelButton.Text = "CANCEL BAKE";
        _cancelButton.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
        AddChild(_cancelButton);

        _status.Text = "Status: Ready";
        _status.ClipText = true;
        _status.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
        AddChild(_status);

        _lastAsset.ClipText = true;
        _lastAsset.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
        AddChild(_lastAsset);

        SetProcess(true);
    }

    public override void _EnterTree()
    {
        ConnectSignals();
        SetProcess(true);
    }

    public override void _ExitTree()
    {
        DisconnectSignals();
        _player = null;
        SetProcess(false);
    }

    public void Bind(GHEG_FacePlayer player)
    {
        _player = player;
        RefreshUi();
    }

    public override void _Process(double delta)
    {
        _refreshRemaining -= delta;
        if (_refreshRemaining > 0.0)
            return;

        _refreshRemaining = RefreshIntervalSeconds;
        RefreshUi();
    }

    private void RefreshUi()
    {
        GHEG_FacePlayer? player = _player;
        if (player is null || !GodotObject.IsInstanceValid(player))
        {
            _bakeButton.Disabled = true;
            _cancelButton.Disabled = true;
            _status.Text = "Status: Unavailable";
            _lastAsset.Text = "";
            return;
        }

        GHEG_System.FacialBakeUiState state =
            GHEG_System.GetFacialBakeUiState(player);

        _bakeButton.Disabled =
            !state.RouteReady || state.Busy || !player.Active;
        _cancelButton.Disabled = !state.BusyForThisPlayer;

        if (state.BusyForThisPlayer)
        {
            int total = state.EndFrame - state.StartFrame + 1;
            int safeTotal = System.Math.Max(1, total);
            int completed = System.Math.Clamp(
                state.CurrentFrame - state.StartFrame + 1,
                0,
                safeTotal);
            _status.Text =
                $"Status: {state.Status}  [{completed}/{safeTotal}]";
        }
        else if (state.Busy)
        {
            _status.Text = "Status: Another Character is baking...";
        }
        else if (!state.RouteReady)
        {
            _status.Text = "Status: Connect this Face route first.";
        }
        else
        {
            _status.Text = "Status: " + state.Status;
        }

        if (string.IsNullOrWhiteSpace(state.LastResourcePath))
        {
            _lastAsset.Text = "";
            _lastAsset.TooltipText = "";
        }
        else
        {
            _lastAsset.Text =
                "Last: " + System.IO.Path.GetFileName(state.LastResourcePath);
            _lastAsset.TooltipText = state.LastResourcePath;
        }
    }

    private void OnBakePressed()
    {
        GHEG_FacePlayer? player = _player;
        if (player is null || !GodotObject.IsInstanceValid(player))
            return;

        if (!GHEG_System.TryStartFacialBake(player, out string reason))
            GD.PushWarning("[GHEG Facial Bake] Start rejected / " + reason);

        RefreshUi();
    }

    private void OnCancelPressed()
    {
        GHEG_FacePlayer? player = _player;
        if (player is null || !GodotObject.IsInstanceValid(player))
            return;

        if (!GHEG_System.TryCancelFacialBake(player, out string reason))
            GD.PushWarning("[GHEG Facial Bake] Cancel rejected / " + reason);

        RefreshUi();
    }

    private void ConnectSignals()
    {
        if (_signalsConnected)
            return;

        _bakeButton.Pressed += OnBakePressed;
        _cancelButton.Pressed += OnCancelPressed;
        _signalsConnected = true;
    }

    private void DisconnectSignals()
    {
        if (!_signalsConnected)
            return;

        _bakeButton.Pressed -= OnBakePressed;
        _cancelButton.Pressed -= OnCancelPressed;
        _signalsConnected = false;
    }
}
#endif
