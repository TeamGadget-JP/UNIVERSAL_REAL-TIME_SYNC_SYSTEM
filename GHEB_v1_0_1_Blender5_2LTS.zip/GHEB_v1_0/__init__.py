bl_info = {
    "name": "G-HUB Entangle for Blender (GHEB)",
    "author": "TeamGadget",
    "version": (1, 0, 1),
    "blender": (5, 2, 0),
    "location": "View3D > Sidebar > GHEB",
    "description": (
        "G-HUB endpoint for real-time body, facial, timeline, "
        "and offline bake synchronization"
    ),
    "category": "Animation",
}

import bpy

from . import GHEB_Timeline
from . import GHEB_ShapeKeys
from . import GHEB_Avatar


_SUPPORTED_BLENDER = (5, 2)


def _require_supported_blender():
    current = tuple(bpy.app.version[:2])
    if current != _SUPPORTED_BLENDER:
        current_text = ".".join(str(v) for v in bpy.app.version)
        raise RuntimeError(
            "GHEB v1.0.1 supports Blender 5.2 LTS only. "
            f"Current Blender version: {current_text}"
        )


def register():
    _require_supported_blender()
    GHEB_Timeline.register()
    GHEB_ShapeKeys.register()
    GHEB_Avatar.register()


def unregister():
    GHEB_Avatar.unregister()
    GHEB_ShapeKeys.unregister()
    GHEB_Timeline.unregister()
