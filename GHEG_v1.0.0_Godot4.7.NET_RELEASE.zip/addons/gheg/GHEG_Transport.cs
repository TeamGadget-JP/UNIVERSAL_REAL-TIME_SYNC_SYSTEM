#nullable enable annotations
using Godot;

/// <summary>
/// Dedicated empty AnimationPlayer for URSS Canonical Timeline transport.
/// Add this directly under a GHEG_Avatar wrapper. Body animation playback
/// belongs on a separate normal AnimationPlayer.
/// </summary>
[Tool]
[GlobalClass]
public partial class GHEG_Transport : AnimationPlayer
{
}
