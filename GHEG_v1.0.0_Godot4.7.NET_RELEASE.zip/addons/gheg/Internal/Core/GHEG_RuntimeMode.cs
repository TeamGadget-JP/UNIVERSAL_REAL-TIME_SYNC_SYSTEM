internal enum GHEG_RuntimeMode
{
    Editor,
    Game,
}
