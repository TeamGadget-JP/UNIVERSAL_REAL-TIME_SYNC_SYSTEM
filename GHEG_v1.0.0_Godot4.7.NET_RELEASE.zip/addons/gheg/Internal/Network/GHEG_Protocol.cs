using System;
using System.Collections.Generic;

namespace GHEG.Internal.Network;

internal static class GHEG_Protocol
{
    internal const int ProtocolVersion = 1;
    internal const string HubHost = "127.0.0.1";
    internal const int DefaultHubPort = 8000;

    internal const int CharacterSlotCount = 5;
    internal const string CharacterReceiveCapability =
        "character_transform_receive";
    internal const int ShapeKeyLocalIdBase = 1001;
    internal const string ShapeKeyReceiveCapability =
        "shape_key_receive";
    internal const string TimelineSendCapability =
        "timeline_send";
    internal const string TimelineReceiveCapability =
        "timeline_receive";

    internal static int CharacterLocalId(int slotIndex)
    {
        ValidateCharacterSlotIndex(slotIndex);
        return slotIndex + 1;
    }

    internal static string CharacterMatchId(int slotIndex)
    {
        ValidateCharacterSlotIndex(slotIndex);
        return $"char_{slotIndex + 1:00}";
    }

    internal static string CharacterSlotLabel(int slotIndex)
    {
        ValidateCharacterSlotIndex(slotIndex);
        return $"C{slotIndex + 1}";
    }

    internal static Dictionary<string, object> HelloMessage()
    {
        return new Dictionary<string, object>
        {
            ["type"] = "HELLO",
            ["protocol_version"] = ProtocolVersion,
            ["endpoint_type"] = "godot",
            ["capabilities"] = new[]
            {
                CharacterReceiveCapability,
                ShapeKeyReceiveCapability,
                TimelineSendCapability,
                TimelineReceiveCapability,
            },
        };
    }

    internal static Dictionary<string, object> CharacterChannelAddMessage(
        int slotIndex)
    {
        return new Dictionary<string, object>
        {
            ["type"] = "CHANNEL_ADD",
            ["channel_type"] = CharacterReceiveCapability,
            ["local_id"] = CharacterLocalId(slotIndex),
            ["match_id"] = CharacterMatchId(slotIndex),
        };
    }


    internal static int ShapeKeyLocalId(int slotIndex)
    {
        ValidateCharacterSlotIndex(slotIndex);
        return ShapeKeyLocalIdBase + slotIndex;
    }

    internal static string ShapeKeyMatchId(int slotIndex)
    {
        ValidateCharacterSlotIndex(slotIndex);
        return $"face_{slotIndex + 1:00}";
    }

    internal static Dictionary<string, object> ShapeKeyChannelAddMessage(
        int slotIndex)
    {
        return new Dictionary<string, object>
        {
            ["type"] = "CHANNEL_ADD",
            ["channel_type"] = ShapeKeyReceiveCapability,
            ["local_id"] = ShapeKeyLocalId(slotIndex),
            ["match_id"] = ShapeKeyMatchId(slotIndex),
        };
    }

    internal static Dictionary<string, object> ReadyMessage(
        int channelId,
        int port)
    {
        return new Dictionary<string, object>
        {
            ["type"] = "READY",
            ["channel_id"] = channelId,
            ["port"] = port,
        };
    }

    internal static Dictionary<string, object> RelayMessage(
        int routeId,
        IReadOnlyDictionary<string, object> payload)
    {
        return new Dictionary<string, object>
        {
            ["type"] = "RELAY",
            ["route_id"] = routeId,
            ["payload"] = payload,
        };
    }

    internal static Dictionary<string, object> PortFailMessage(
        int channelId,
        int port,
        string reason = "bind_failed")
    {
        return new Dictionary<string, object>
        {
            ["type"] = "PORT_FAIL",
            ["channel_id"] = channelId,
            ["port"] = port,
            ["reason"] = reason,
        };
    }


    internal static Dictionary<string, object> TimelinePublishMessage(
        double timeSeconds,
        bool isPlaying,
        bool claimOwner)
    {
        return new Dictionary<string, object>
        {
            ["type"] = "TIMELINE_PUBLISH",
            ["time_seconds"] = timeSeconds,
            ["is_playing"] = isPlaying,
            ["claim_owner"] = claimOwner,
        };
    }

    internal static Dictionary<string, object> TimelineSyncRequestMessage()
    {
        return new Dictionary<string, object>
        {
            ["type"] = "TIMELINE_SYNC_REQUEST",
        };
    }

    internal static Dictionary<string, object> TimelineReleaseMessage()
    {
        return new Dictionary<string, object>
        {
            ["type"] = "TIMELINE_RELEASE",
        };
    }

    private static void ValidateCharacterSlotIndex(int slotIndex)
    {
        if (slotIndex < 0 || slotIndex >= CharacterSlotCount)
        {
            throw new ArgumentOutOfRangeException(
                nameof(slotIndex),
                slotIndex,
                $"Character Slot must be 0..{CharacterSlotCount - 1}.");
        }
    }
}
