﻿#nullable enable annotations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.Json;
using Godot;
using GHEG.Internal.Core;
using GHEG.Internal.Network;

/// <summary>
/// Public scene component for project-wide GHEG configuration.
///
/// Resolves C1..C5 Skeleton3D Bone names, manages independent Smart Swizzle
/// reference contracts, and applies the authoritative GHEC Body streams.
/// </summary>
[Tool]
[GlobalClass]
public partial class GHEG_System : Node
{
	private const double ReconnectDelaySeconds = 1.5;
	private const double SceneRegistrationScanIntervalSeconds = 0.75;
	private const double ChannelRegistrationRetrySeconds = 2.0;
	private const double TimelineTimeEpsilon = 0.0001;
	private const double TimelineTickIntervalSeconds = 0.05;
	private const double TimelineRemoteGuardSeconds = 0.20;
	private const int FbxBridgeTransactionVersion = 1;
	private const double FbxBridgeTimeoutSeconds = 120.0;
	private const double FbxImportTimeoutSeconds = 20.0;
	private const string FbxBridgeWireTempRootName = "GHEU_FBXBridge";
	private const string FbxBridgeExportScope = "joints_slot_b2_3";
	private const double FacialBakeReadyTimeoutSeconds = 5.0;
	private const double FacialBakeFrameTimeoutSeconds = 0.75;
	private const int FacialBakeMaxFrameRetries = 3;

	private sealed class CharacterSlotRuntime
	{
		internal CharacterSlotRuntime(int slotIndex)
		{
			SlotIndex = slotIndex;
		}

		internal int SlotIndex { get; }
		internal int LocalId => GHEG_Protocol.CharacterLocalId(SlotIndex);
		internal string MatchId => GHEG_Protocol.CharacterMatchId(SlotIndex);
		internal string Label => GHEG_Protocol.CharacterSlotLabel(SlotIndex);

		internal int ChannelId;
		internal int RouteId;
		internal Dictionary<string, string> RequestBones = new();
		internal readonly Dictionary<string, string> AliasCandidates = new();
		internal readonly Dictionary<string, string> AliasOriginalNames = new();
		internal readonly Dictionary<int, Quaternion> SourceRestRotations = new();
		internal readonly Dictionary<int, Vector3> SourceRestPositions = new();
		internal readonly Dictionary<int, Quaternion> PendingSourceRestRotations = new();
		internal readonly Dictionary<int, Vector3> PendingSourceRestPositions = new();
		internal readonly Dictionary<int, Quaternion> OriginalPoseRotations = new();
		internal readonly Dictionary<int, Vector3> OriginalPosePositions = new();
		internal readonly Dictionary<int, Quaternion> LastLiveRotations = new();
		internal readonly Dictionary<int, Vector3> LastLivePositions = new();
		internal readonly Dictionary<int, Quaternion> LastTargetRotations = new();
		internal readonly Dictionary<int, Vector3> LastTargetPositions = new();
		internal readonly Dictionary<int, Quaternion> LastAppliedRotations = new();
		internal readonly Dictionary<int, Vector3> LastAppliedPositions = new();
		internal readonly HashSet<int> FullRotationBoneIds = new();
		internal readonly HashSet<int> PositionBoneIds = new();

		internal bool AliasProbePending;
		internal bool FinalValidationPending;
		internal bool PoseContractReady;
		internal bool FullRotationLogPrinted;
		internal bool PositionLogPrinted;
		internal bool UdpObserved;
		internal bool SmartSwizzleObserved;
		internal bool ChannelRegistrationPending;
		internal double ChannelRegistrationRequestedAt;
		internal GHEG_Avatar? Avatar;
	}

	private sealed class ShapeKeySlotRuntime
	{
		internal ShapeKeySlotRuntime(int slotIndex)
		{
			SlotIndex = slotIndex;
		}

		internal int SlotIndex { get; }
		internal int LocalId => GHEG_Protocol.ShapeKeyLocalId(SlotIndex);
		internal string MatchId => GHEG_Protocol.ShapeKeyMatchId(SlotIndex);
		internal string Label => GHEG_Protocol.CharacterSlotLabel(SlotIndex);

		internal GHEG_ShapeKeys? Receiver;
		internal int ChannelId;
		internal int RouteId;
		internal bool UdpObserved;
		internal bool ChannelRegistrationPending;
		internal double ChannelRegistrationRequestedAt;
	}

	private sealed class FacialBakeSession
	{
		internal GHEG_FacePlayer Player = null!;
		internal GHEG_ShapeKeys Receiver = null!;
		internal ShapeKeySlotRuntime State = null!;
		internal int BakeId;
		internal int StartFrame;
		internal int EndFrame;
		internal int OutputFps;
		internal int CurrentFrame;
		internal int ExpectedSourceFrame;
		internal double SourceFps;
		internal double StartedAt;
		internal double FrameRequestedAt;
		internal int FrameRetryCount;
		internal bool Ready;
		internal bool WaitingForFrame;
	}

	private sealed class TimelineObservation
	{
		internal double TimeSeconds;
		internal bool IsPlaying;
	}

	private sealed class TimelineBinding
	{
		internal TimelineBinding(
			CharacterSlotRuntime slot,
			GHEG_TimelineAgent agent)
		{
			Slot = slot;
			Agent = agent;
		}

		internal CharacterSlotRuntime Slot { get; }
		internal GHEG_TimelineAgent Agent { get; }
	}

	private enum FbxBridgePhase
	{
		Exporting = 0,
		Copying = 1,
		Registering = 2,
		Complete = 3,
	}

	private sealed class FbxBridgePendingRequest
	{
		internal string RequestId = "";
		internal int RouteId;
		internal int SlotIndex;
		internal string TempDirectory = "";
		internal string TempFilePath = "";
		internal string ResourcePath = "";
		internal string DestinationPath = "";
		internal double StartedAt;
		internal FbxBridgePhase Phase;
	}

	private sealed class FbxBridgeLastResult
	{
		internal bool HasResult;
		internal bool Succeeded;
		internal bool Imported;
		internal string ResourcePath = "";
		internal string Summary = "Idle";
	}

	public readonly struct FbxBridgeUiState
	{
		public FbxBridgeUiState(
			bool busy,
			bool busyForThisAvatar,
			bool importing,
			bool importingForThisAvatar,
			string phaseLabel,
			bool hasLastResult,
			bool lastSucceeded,
			bool lastImported,
			string lastResourcePath,
			string lastSummary)
		{
			Busy = busy;
			BusyForThisAvatar = busyForThisAvatar;
			Importing = importing;
			ImportingForThisAvatar = importingForThisAvatar;
			PhaseLabel = phaseLabel;
			HasLastResult = hasLastResult;
			LastSucceeded = lastSucceeded;
			LastImported = lastImported;
			LastResourcePath = lastResourcePath;
			LastSummary = lastSummary;
		}

		public bool Busy { get; }
		public bool BusyForThisAvatar { get; }
		public bool Importing { get; }
		public bool ImportingForThisAvatar { get; }
		public string PhaseLabel { get; }
		public bool HasLastResult { get; }
		public bool LastSucceeded { get; }
		public bool LastImported { get; }
		public string LastResourcePath { get; }
		public string LastSummary { get; }
	}


	public readonly struct ControlUiState
	{
		public ControlUiState(
			bool requested,
			bool endpointRunning,
			bool sessionActive,
			int endpointId,
			long sessionId)
		{
			Requested = requested;
			EndpointRunning = endpointRunning;
			SessionActive = sessionActive;
			EndpointId = endpointId;
			SessionId = sessionId;
		}

		public bool Requested { get; }
		public bool EndpointRunning { get; }
		public bool SessionActive { get; }
		public int EndpointId { get; }
		public long SessionId { get; }
	}

	public readonly struct SlotUiState
	{
		public SlotUiState(
			bool bodyConfigured,
			bool bodyRouteReady,
			bool bodyUdpObserved,
			bool faceConfigured,
			bool faceRouteReady,
			bool faceUdpObserved)
		{
			BodyConfigured = bodyConfigured;
			BodyRouteReady = bodyRouteReady;
			BodyUdpObserved = bodyUdpObserved;
			FaceConfigured = faceConfigured;
			FaceRouteReady = faceRouteReady;
			FaceUdpObserved = faceUdpObserved;
		}

		public bool BodyConfigured { get; }
		public bool BodyRouteReady { get; }
		public bool BodyUdpObserved { get; }
		public bool FaceConfigured { get; }
		public bool FaceRouteReady { get; }
		public bool FaceUdpObserved { get; }
	}
	internal sealed class SsBoneDiagnostic
	{
		internal int BoneId { get; init; }
		internal string BoneName { get; init; } = "";
		internal string ParentName { get; init; } = "--";
		internal bool Mapped { get; init; }
		internal bool TranslationEnabled { get; init; }
		internal Transform3D GodotRest { get; init; } = Transform3D.Identity;
		internal bool HasSourceRestRotation { get; init; }
		internal Quaternion SourceRestRotation { get; init; } = Quaternion.Identity;
		internal bool HasSourceRestPosition { get; init; }
		internal Vector3 SourceRestPosition { get; init; } = Vector3.Zero;
		internal bool HasLiveRotation { get; init; }
		internal Quaternion LiveRotation { get; init; } = Quaternion.Identity;
		internal bool HasLivePosition { get; init; }
		internal Vector3 LivePosition { get; init; } = Vector3.Zero;
		internal bool HasTargetRotation { get; init; }
		internal Quaternion TargetRotation { get; init; } = Quaternion.Identity;
		internal bool HasTargetPosition { get; init; }
		internal Vector3 TargetPosition { get; init; } = Vector3.Zero;
		internal Quaternion AppliedRotation { get; init; } = Quaternion.Identity;
		internal Vector3 AppliedPosition { get; init; } = Vector3.Zero;
	}

	internal enum SsScenePoseKind
	{
		Applied = 0,
		ResolvedTarget = 1,
		GodotRest = 2,
	}

	internal sealed class SsDiagnosticSnapshot
	{
		internal int SlotIndex { get; init; }
		internal string SlotLabel { get; init; } = "";
		internal bool AvatarConfigured { get; init; }
		internal bool SkeletonReady { get; init; }
		internal bool RouteReady { get; init; }
		internal bool UdpObserved { get; init; }
		internal bool PoseContractReady { get; init; }
		internal string CacheStatus { get; init; } = "Missing";
		internal float PositionScale { get; init; }
		internal int BoneCount { get; init; }
		internal int MappedBoneCount { get; init; }
		internal int TranslationBoneCount { get; init; }
		internal List<SsBoneDiagnostic> Bones { get; init; } = new();
	}

	public readonly struct FacialBakeUiState
	{
		public FacialBakeUiState(
			bool routeReady,
			bool busy,
			bool busyForThisPlayer,
			string status,
			int currentFrame,
			int startFrame,
			int endFrame,
			string lastResourcePath)
		{
			RouteReady = routeReady;
			Busy = busy;
			BusyForThisPlayer = busyForThisPlayer;
			Status = status;
			CurrentFrame = currentFrame;
			StartFrame = startFrame;
			EndFrame = endFrame;
			LastResourcePath = lastResourcePath;
		}

		public bool RouteReady { get; }
		public bool Busy { get; }
		public bool BusyForThisPlayer { get; }
		public string Status { get; }
		public int CurrentFrame { get; }
		public int StartFrame { get; }
		public int EndFrame { get; }
		public string LastResourcePath { get; }
	}

	private static GHEG_System? _instance;

	[ExportGroup("G-HUB")]
	[Export]
	public bool ConnectToGHub { get; set; }

	[Export(PropertyHint.Range, "1,65535,1")]
	public int ControlPort { get; set; } =
		GHEG_Protocol.DefaultHubPort;

	[ExportGroup("Timeline")]
	[Export]
	public bool TimelineSyncEnabled { get; set; } = false;

	[ExportGroup("Execution Modes")]
	[Export]
	public bool EditorSyncEnabled { get; set; } = true;

	[Export]
	public bool GameSyncEnabled { get; set; } = true;

	[ExportGroup("Diagnostics")]
	[Export]
	public bool VerboseLogging { get; set; } = false;

	private readonly CharacterSlotRuntime[] _characterSlots =
		CreateCharacterSlotRuntimes();
	private readonly ShapeKeySlotRuntime[] _shapeKeySlots =
		CreateShapeKeySlotRuntimes();

	private GHEG_GHubClient? _client;
	private bool _isEditorContext;
	private int _endpointId;
	private long _sessionId;
	private int _activeControlPort;
	private double _reconnectRemaining;
	private double _sceneRegistrationScanRemaining;
	private bool _processObserved;

	private readonly Dictionary<ulong, TimelineObservation> _timelineObservations = new();
	private readonly List<TimelineBinding> _timelineBindings = new();
	private readonly HashSet<ulong> _timelineActiveIds = new();
	private readonly List<ulong> _timelineStaleIds = new();
	private bool _timelineSyncWasEnabled;
	private bool _timelineRemoteApplying;
	private bool _timelineCanonicalOwner;
	private bool _timelineHasCanonicalState;
	private bool _timelineCanonicalPlaying;
	private double _timelineCanonicalTime;
	private int _timelineCanonicalOwnerEndpointId;
	private long _timelineCanonicalOwnerSessionId;
	private long _timelineLastAppliedRevision = -1;
	private double _timelineNextTickAt;
	private double _timelineSuppressLocalUntil;
	private ulong _timelineLeaderAgentId;
	private ulong _timelineEditorSelectedAgentId;

	private FbxBridgePendingRequest? _pendingFbxBridgeRequest;
	private readonly FbxBridgeLastResult[] _fbxBridgeLastResults =
		CreateFbxBridgeLastResults();
	private bool _fbxImportInProgress;
	private int _fbxImportSlotIndex = -1;
	private string _fbxImportResourcePath = "";
	private double _fbxImportStartedAt;

	private FacialBakeSession? _activeFacialBake;
	private int _facialBakeSerial = 1000;

	private string ContextLabel =>
		_isEditorContext ? "EDITOR" : "GAME";

	private void LogVerbose(string message)
	{
		if (VerboseLogging)
			GD.Print(message);
	}

	public override void _EnterTree()
	{
		_instance = this;
		_isEditorContext = Engine.IsEditorHint();
		_client = new GHEG_GHubClient();
		_timelineSyncWasEnabled = TimelineSyncEnabled;
		ResetTimelineRuntime(clearObservations: true);

		if (_isEditorContext)
		{
			GHEG_EditorState.PluginEnabledChanged +=
				OnPluginEnabledChanged;
			GHEG_EditorState.RuntimeHandoffChanged +=
				OnRuntimeHandoffChanged;
		}

		ProcessMode = ProcessModeEnum.Always;
		SetProcess(true);

		LogVerbose(
			$"[GHEG][{ContextLabel}] System entered tree / " +
			$"ConnectToGHub={ConnectToGHub}");
	}

	public override void _ExitTree()
	{
		if (_isEditorContext)
		{
			GHEG_EditorState.PluginEnabledChanged -=
				OnPluginEnabledChanged;
			GHEG_EditorState.RuntimeHandoffChanged -=
				OnRuntimeHandoffChanged;
		}

		StopEndpoint(clearRequestedState: false);

		_client?.Dispose();
		_client = null;

		if (ReferenceEquals(_instance, this))
			_instance = null;
	}

	public override void _Process(double delta)
	{
		if (!_processObserved)
		{
			_processObserved = true;
			LogVerbose(
				$"[GHEG][{ContextLabel}] System process active / " +
				$"ConnectToGHub={ConnectToGHub}");
		}

		DrainControlEvents();

		foreach (CharacterSlotRuntime state in _characterSlots)
			DrainCharacterUdp(state);

		foreach (ShapeKeySlotRuntime state in _shapeKeySlots)
			DrainShapeKeyUdp(state);

		ProcessTimelineSyncToggle();
		ProcessTimelineSync();
		CheckFbxBridgeTimeout();
		UpdateFbxImport();
		UpdateFacialBake();

		GHEG_GHubClient? client = _client;
		if (client is null)
			return;

		bool shouldRun = ShouldEndpointRun();

		if (!shouldRun)
		{
			if (client.IsRunning ||
				_endpointId != 0 ||
				HasAnySessionState())
			{
				StopEndpoint(clearRequestedState: false);
			}

			return;
		}

		int desiredPort = Math.Clamp(
			ControlPort,
			1,
			65535);

		if (client.IsRunning &&
			_activeControlPort != desiredPort)
		{
			LogVerbose(
				"[GHEG] Control Port changed. Reconnecting...");
			StopEndpoint(clearRequestedState: false);
			_reconnectRemaining = 0.0;
			return;
		}

		if (client.IsRunning)
		{
			ProcessDynamicSceneRegistrations(delta);
			return;
		}

		_sceneRegistrationScanRemaining = 0.0;
		_reconnectRemaining -= delta;
		if (_reconnectRemaining > 0.0)
			return;

		StartEndpoint(desiredPort);
	}

	private void StartEndpoint(int port)
	{
		GHEG_GHubClient? client = _client;
		if (client is null || client.IsRunning)
			return;

		ClearSessionRuntime();

		_activeControlPort = port;
		_reconnectRemaining = ReconnectDelaySeconds;

		LogVerbose(
			$"[GHEG][{ContextLabel}] CONNECTING / " +
			$"{GHEG_Protocol.HubHost}:{port}");

		client.Connect(
			GHEG_Protocol.HubHost,
			port);
	}

	private void StopEndpoint(bool clearRequestedState)
	{
		AbortPendingFbxBridge("G-HUB connection closed.");
		AbortFacialBake("G-HUB connection closed.", sendCancel: false);
		_client?.Disconnect();
		ClearSessionRuntime();

		if (clearRequestedState)
			ConnectToGHub = false;
	}

	private void OnPluginEnabledChanged(bool enabled)
	{
		if (!enabled)
		{
			StopEndpoint(clearRequestedState: false);
		}
		else
		{
			_reconnectRemaining = 0.0;
		}
	}

	private void OnRuntimeHandoffChanged(bool active)
	{
		if (!_isEditorContext)
			return;

		if (active)
		{
			if (_client?.IsRunning == true ||
				_endpointId != 0 ||
				HasAnySessionState())
			{
				LogVerbose(
					"[GHEG][EDITOR] Suspended for Game handoff.");
				StopEndpoint(clearRequestedState: false);
			}

			return;
		}

		LogVerbose(
			"[GHEG][EDITOR] Game stopped / Editor resume armed.");
		_reconnectRemaining = 0.0;
	}

	private bool ShouldEndpointRun()
	{
		if (!ConnectToGHub)
			return false;

		if (_isEditorContext)
		{
			return EditorSyncEnabled &&
				   GHEG_EditorState.PluginEnabled &&
				   !GHEG_EditorState.RuntimeHandoffActive;
		}

		return GameSyncEnabled;
	}

	private void ProcessTimelineSyncToggle()
	{
		if (TimelineSyncEnabled == _timelineSyncWasEnabled)
			return;

		_timelineSyncWasEnabled = TimelineSyncEnabled;
		ResetTimelineRuntime(clearObservations: true);

		if (_client?.IsRunning != true || _endpointId <= 0)
			return;

		if (TimelineSyncEnabled)
		{
			if (_client.Send(GHEG_Protocol.TimelineSyncRequestMessage()))
			{
				LogVerbose("[GHEG] Timeline Sync ON / Canonical state requested.");
			}
		}
		else
		{
			_client.Send(GHEG_Protocol.TimelineReleaseMessage());
			LogVerbose("[GHEG] Timeline Sync OFF / ownership released.");
		}
	}

	private void ProcessTimelineSync()
	{
		// Offline Facial Bake owns the ShapeMixer route transaction and samples
		// canonical time explicitly frame-by-frame. Do not let a local Transport
		// reclaim Timeline ownership while that transaction is active.
		if (_activeFacialBake is not null)
			return;

		// Local AnimationPlayer synchronization is intentionally independent
		// from G-HUB connectivity. This keeps all active GHEG character slots
		// on one local virtual timeline even while the endpoint is disconnected.
		// Network publication remains opportunistic in PublishTimelineState().
		if (!TimelineSyncEnabled ||
			_timelineRemoteApplying)
		{
			return;
		}

		CollectTimelineBindings();
		if (_timelineBindings.Count == 0)
			return;

		double now = GetClockSeconds();

		if (ProcessEditorTimelineFocusGuard(now))
			return;

		TimelineBinding? transportSource = null;
		double transportTime = 0.0;
		bool transportPlaying = false;

		foreach (TimelineBinding binding in _timelineBindings)
		{
			if (!binding.Agent.TryReadState(
				out double currentTime,
				out bool currentPlaying))
			{
				continue;
			}

			ulong playerId = binding.Agent.RuntimeId;
			if (!_timelineObservations.TryGetValue(
				playerId,
				out TimelineObservation? observation))
			{
				if (_timelineHasCanonicalState &&
					!_timelineCanonicalOwner)
				{
					binding.Agent.ApplyState(
						_timelineCanonicalTime,
						_timelineCanonicalPlaying);

					binding.Agent.TryReadState(
						out currentTime,
						out currentPlaying);
				}

				_timelineObservations[playerId] =
					new TimelineObservation
					{
						TimeSeconds = currentTime,
						IsPlaying = currentPlaying,
					};

				continue;
			}

			if (currentPlaying == observation.IsPlaying)
				continue;

			bool naturalEnd =
				observation.IsPlaying &&
				!currentPlaying &&
				binding.Agent.IsAtNaturalEnd(currentTime);

			if (naturalEnd &&
				!_timelineCanonicalOwner &&
				_timelineHasCanonicalState)
			{
				observation.TimeSeconds = currentTime;
				observation.IsPlaying = currentPlaying;
				continue;
			}

			// A follower reaching the end of a shorter local animation must not
			// stop the global canonical timeline. Only the current local leader may
			// turn a natural completion into a canonical Pause.
			if (naturalEnd &&
				_timelineLeaderAgentId != 0 &&
				_timelineLeaderAgentId != playerId)
			{
				observation.TimeSeconds = currentTime;
				observation.IsPlaying = currentPlaying;
				continue;
			}

			transportSource = binding;
			transportTime = currentTime;
			transportPlaying = currentPlaying;
			break;
		}

		if (transportSource is not null)
		{
			if (!_timelineCanonicalOwner &&
				now <= _timelineSuppressLocalUntil &&
				_timelineHasCanonicalState)
			{
				ApplyTimelineStateToAll(
					_timelineCanonicalTime,
					_timelineCanonicalPlaying);
				return;
			}

			ulong sourceId =
				transportSource.Agent.RuntimeId;
			bool naturalEnd =
				!transportPlaying &&
				transportSource.Agent.IsAtNaturalEnd(transportTime);

			_timelineLeaderAgentId = sourceId;
			_timelineHasCanonicalState = false;
			_timelineSuppressLocalUntil = 0.0;

			ApplyLocalTimelineStateToFollowers(
				transportSource.Agent,
				transportTime,
				transportPlaying);

			PublishTimelineState(
				transportTime,
				transportPlaying,
				claimOwner: !naturalEnd);

			LogVerbose(
				$"[GHEG] TIMELINE {(naturalEnd ? "END" : "CLAIM")} / " +
				$"{transportSource.Slot.Label} / " +
				$"{transportTime:0.###}s / " +
				$"{(transportPlaying ? "PLAY" : "PAUSE")}");

			RefreshTimelineObservations();
			_timelineNextTickAt = now + TimelineTickIntervalSeconds;
			return;
		}

		TimelineBinding? playingLeader =
			FindTimelineLeaderBinding();

		if (playingLeader is not null &&
			playingLeader.Agent.TryReadState(
				out double leaderTime,
				out bool leaderPlaying) &&
			leaderPlaying)
		{
			if (_timelineCanonicalOwner &&
				now >= _timelineNextTickAt)
			{
				_timelineNextTickAt =
					now + TimelineTickIntervalSeconds;

				PublishTimelineState(
					leaderTime,
					isPlaying: true,
					claimOwner: false);
			}

			RefreshTimelineObservations();
			return;
		}

		// Paused position changes are local scrub/step/direct-entry operations.
		foreach (TimelineBinding binding in _timelineBindings)
		{
			if (!binding.Agent.TryReadState(
				out double currentTime,
				out bool currentPlaying) ||
				currentPlaying)
			{
				continue;
			}

			ulong playerId = binding.Agent.RuntimeId;
			if (!_timelineObservations.TryGetValue(
				playerId,
				out TimelineObservation? observation))
			{
				continue;
			}

			if (Math.Abs(currentTime - observation.TimeSeconds) <=
				TimelineTimeEpsilon)
			{
				continue;
			}

			if (!_timelineCanonicalOwner &&
				now <= _timelineSuppressLocalUntil &&
				_timelineHasCanonicalState)
			{
				ApplyTimelineStateToAll(
					_timelineCanonicalTime,
					_timelineCanonicalPlaying);
				return;
			}

			_timelineLeaderAgentId = playerId;
			_timelineHasCanonicalState = false;
			_timelineSuppressLocalUntil = 0.0;

			ApplyLocalTimelineStateToFollowers(
				binding.Agent,
				currentTime,
				isPlaying: false);

			PublishTimelineState(
				currentTime,
				isPlaying: false,
				claimOwner: true);

			RefreshTimelineObservations();
			_timelineNextTickAt = now + TimelineTickIntervalSeconds;
			return;
		}

		RefreshTimelineObservations();
	}


	private bool ProcessEditorTimelineFocusGuard(double now)
	{
#if TOOLS
		if (!_isEditorContext)
			return false;

		TimelineBinding? selected = null;
		foreach (TimelineBinding binding in _timelineBindings)
		{
			if (binding.Agent.IsEditorFocused())
			{
				selected = binding;
				break;
			}
		}

		ulong selectedAgentId = selected?.Agent.RuntimeId ?? 0;
		if (selectedAgentId != _timelineEditorSelectedAgentId)
		{
			foreach (TimelineBinding binding in _timelineBindings)
				binding.Agent.ResetEditorFocusGuard();

			_timelineEditorSelectedAgentId = selectedAgentId;

			if (selected is null ||
				!TryGetTimelineFocusAnchor(
					selectedAgentId,
					out double anchorTime,
					out bool anchorPlaying))
			{
				return false;
			}

			selected.Agent.BeginEditorFocusGuard(
				now,
				anchorTime,
				anchorPlaying);

			RefreshTimelineObservations();
			return true;
		}

		if (selected is null)
			return false;

		if (!selected.Agent.ProcessEditorFocusGuard(now))
			return false;

		RefreshTimelineObservations();
		return true;
#else
		return false;
#endif
	}

	private bool TryGetTimelineFocusAnchor(
		ulong selectedAgentId,
		out double timeSeconds,
		out bool isPlaying)
	{
		timeSeconds = 0.0;
		isPlaying = false;

		if (_timelineHasCanonicalState &&
			!_timelineCanonicalOwner)
		{
			timeSeconds = _timelineCanonicalTime;
			isPlaying = _timelineCanonicalPlaying;
			return true;
		}

		// Use the previous observation, not the newly focused player's live
		// value. The Godot Animation editor may already have moved that player
		// before this process tick.
		if (_timelineLeaderAgentId != 0 &&
			_timelineObservations.TryGetValue(
				_timelineLeaderAgentId,
				out TimelineObservation? leaderObservation))
		{
			timeSeconds = leaderObservation.TimeSeconds;
			isPlaying = leaderObservation.IsPlaying;
			return true;
		}

		foreach (TimelineBinding binding in _timelineBindings)
		{
			ulong agentId = binding.Agent.RuntimeId;
			if (agentId == selectedAgentId)
				continue;

			if (_timelineObservations.TryGetValue(
				agentId,
				out TimelineObservation? observation))
			{
				timeSeconds = observation.TimeSeconds;
				isPlaying = observation.IsPlaying;
				return true;
			}
		}

		if (_timelineObservations.TryGetValue(
			selectedAgentId,
			out TimelineObservation? selectedObservation))
		{
			timeSeconds = selectedObservation.TimeSeconds;
			isPlaying = selectedObservation.IsPlaying;
			return true;
		}

		return false;
	}

	private void HandleTimelineState(JsonElement root)
	{
		if (!TimelineSyncEnabled)
			return;

		double timeSeconds = ReadDouble(root, "time_seconds");
		bool isPlaying = ReadBool(root, "is_playing");
		long revision = ReadLong(root, "revision");

		if (!double.IsFinite(timeSeconds) ||
			revision <= _timelineLastAppliedRevision)
		{
			return;
		}

		int ownerEndpointId = ReadInt(root, "owner_endpoint_id");
		long ownerSessionId = ReadLong(root, "owner_session_id");

		bool isOwner =
			ownerEndpointId > 0 &&
			ownerSessionId > 0 &&
			ownerEndpointId == _endpointId &&
			ownerSessionId == _sessionId;

		_timelineLastAppliedRevision = revision;
		_timelineCanonicalOwner = isOwner;
		_timelineHasCanonicalState = true;
		_timelineCanonicalTime = Math.Max(0.0, timeSeconds);
		_timelineCanonicalPlaying = isPlaying;
		_timelineCanonicalOwnerEndpointId = ownerEndpointId;
		_timelineCanonicalOwnerSessionId = ownerSessionId;

		if (isOwner)
		{
			// Sender self-echo is the canonical ACK. Never seek backwards to
			// the slightly older echoed time while local playback is advancing.
			RefreshTimelineObservations();
			return;
		}

		_timelineLeaderAgentId = 0;
		_timelineSuppressLocalUntil =
			GetClockSeconds() + TimelineRemoteGuardSeconds;

		ApplyTimelineStateToAll(
			_timelineCanonicalTime,
			isPlaying);
	}

	private void CollectTimelineBindings()
	{
		_timelineBindings.Clear();
		_timelineActiveIds.Clear();

		foreach (CharacterSlotRuntime state in _characterSlots)
		{
			GHEG_Avatar? avatar = state.Avatar;

			// Body/network setup normally resolves Avatar references during ASSIGN,
			// but Timeline must also work before any G-HUB connection exists.
			if (avatar is null || !GodotObject.IsInstanceValid(avatar))
			{
				avatar = FindCharacterAvatar(state);
				state.Avatar = avatar;
			}

			if (avatar is null || !avatar.Active)
				continue;

			GHEG_TimelineAgent? agent = FindTimelineAgentForAvatar(avatar);
			if (agent is null ||
				!agent.Active ||
				!GodotObject.IsInstanceValid(agent) ||
				agent.ResolvePlayer() is null)
			{
				continue;
			}

			ulong agentId = agent.RuntimeId;
			if (!_timelineActiveIds.Add(agentId))
				continue;

			_timelineBindings.Add(new TimelineBinding(state, agent));
		}

		if (_timelineObservations.Count == 0)
			return;

		_timelineStaleIds.Clear();
		foreach (ulong observedId in _timelineObservations.Keys)
		{
			if (!_timelineActiveIds.Contains(observedId))
				_timelineStaleIds.Add(observedId);
		}

		foreach (ulong staleId in _timelineStaleIds)
			_timelineObservations.Remove(staleId);
	}

	private GHEG_TimelineAgent? FindTimelineAgentForAvatar(GHEG_Avatar avatar)
	{
		if (avatar.GetParent() is GHEG_TimelineAgent parentAgent &&
			(parentAgent.ResolveAvatar()?.GetInstanceId() ?? 0) == avatar.GetInstanceId())
		{
			return parentAgent;
		}

		Node? root = Owner ?? GetTree().CurrentScene ?? GetParent();
		if (root is null)
			return null;

		return FindTimelineAgentRecursive(root, avatar);
	}

	private static GHEG_TimelineAgent? FindTimelineAgentRecursive(
		Node node,
		GHEG_Avatar avatar)
	{
		if (node is GHEG_TimelineAgent agent &&
			(agent.ResolveAvatar()?.GetInstanceId() ?? 0) == avatar.GetInstanceId())
		{
			return agent;
		}

		foreach (Node child in node.GetChildren())
		{
			GHEG_TimelineAgent? found =
				FindTimelineAgentRecursive(child, avatar);

			if (found is not null)
				return found;
		}

		return null;
	}

	private TimelineBinding? FindTimelineLeaderBinding()
	{
		if (_timelineLeaderAgentId != 0)
		{
			foreach (TimelineBinding binding in _timelineBindings)
			{
				if (binding.Agent.RuntimeId == _timelineLeaderAgentId)
					return binding;
			}
		}

		foreach (TimelineBinding binding in _timelineBindings)
		{
			if (binding.Agent.TryReadState(out _, out bool isPlaying) &&
				isPlaying)
			{
				_timelineLeaderAgentId = binding.Agent.RuntimeId;
				return binding;
			}
		}

		return null;
	}

	private void ApplyLocalTimelineStateToFollowers(
		GHEG_TimelineAgent source,
		double timeSeconds,
		bool isPlaying)
	{
		_timelineRemoteApplying = true;

		try
		{
			foreach (TimelineBinding binding in _timelineBindings)
			{
				if (ReferenceEquals(binding.Agent, source))
					continue;

				binding.Agent.ApplyState(timeSeconds, isPlaying);
			}
		}
		finally
		{
			_timelineRemoteApplying = false;
		}
	}

	private void ApplyTimelineStateToAll(
		double timeSeconds,
		bool isPlaying)
	{
		CollectTimelineBindings();
		if (_timelineBindings.Count == 0)
			return;

		_timelineRemoteApplying = true;

		try
		{
			foreach (TimelineBinding binding in _timelineBindings)
				binding.Agent.ApplyState(timeSeconds, isPlaying);
		}
		finally
		{
			_timelineRemoteApplying = false;
		}

		RefreshTimelineObservations();
	}

	private void RefreshTimelineObservations()
	{
		CollectTimelineBindings();

		foreach (TimelineBinding binding in _timelineBindings)
		{
			if (!binding.Agent.TryReadState(
				out double timeSeconds,
				out bool isPlaying))
			{
				continue;
			}

			ulong agentId = binding.Agent.RuntimeId;
			if (!_timelineObservations.TryGetValue(
				agentId,
				out TimelineObservation? observation))
			{
				observation = new TimelineObservation();
				_timelineObservations[agentId] = observation;
			}

			observation.TimeSeconds = timeSeconds;
			observation.IsPlaying = isPlaying;
		}
	}

	private void PublishTimelineState(
		double timeSeconds,
		bool isPlaying,
		bool claimOwner)
	{
		if (!TimelineSyncEnabled ||
			_endpointId <= 0 ||
			_client?.IsRunning != true)
		{
			return;
		}

		_client.Send(
			GHEG_Protocol.TimelinePublishMessage(
				Math.Max(0.0, timeSeconds),
				isPlaying,
				claimOwner));
	}

	private void ResetTimelineRuntime(bool clearObservations)
	{
		_timelineRemoteApplying = false;
		_timelineCanonicalOwner = false;
		_timelineHasCanonicalState = false;
		_timelineCanonicalPlaying = false;
		_timelineCanonicalTime = 0.0;
		_timelineCanonicalOwnerEndpointId = 0;
		_timelineCanonicalOwnerSessionId = 0;
		_timelineLastAppliedRevision = -1;
		_timelineNextTickAt =
			GetClockSeconds() + TimelineTickIntervalSeconds;
		_timelineSuppressLocalUntil = 0.0;
		_timelineLeaderAgentId = 0;
		_timelineEditorSelectedAgentId = 0;

		foreach (TimelineBinding binding in _timelineBindings)
			binding.Agent.ResetEditorFocusGuard();

		if (clearObservations)
		{
			_timelineObservations.Clear();
			_timelineBindings.Clear();
			_timelineActiveIds.Clear();
			_timelineStaleIds.Clear();
		}
	}


	/// <summary>
	/// Lightweight editor-facing snapshot for Timeline validation.
	/// This method is read-only and does not rescan the scene or mutate Timeline state.
	/// </summary>
	public string GetTimelineMonitorText()
	{
		if (!TimelineSyncEnabled)
			return "Status    OFF";

		string mode =
			_client?.IsRunning == true && _endpointId > 0
				? "G-HUB"
				: "LOCAL";

		if (_timelineBindings.Count == 0)
		{
			return
				$"Mode      {mode}\n" +
				"Owner     --\n" +
				"Agents    No active GHEG_TimelineAgent";
		}

		TimelineBinding? leader = null;
		if (_timelineLeaderAgentId != 0)
		{
			foreach (TimelineBinding binding in _timelineBindings)
			{
				if (binding.Agent.RuntimeId ==
					_timelineLeaderAgentId)
				{
					leader = binding;
					break;
				}
			}
		}

		string focusLabel = "--";
		foreach (TimelineBinding binding in _timelineBindings)
		{
			if (binding.Agent.RuntimeId ==
				_timelineEditorSelectedAgentId)
			{
				focusLabel = binding.Slot.Label;
				break;
			}
		}

		bool focusGuard = false;
		double monitorNow = GetClockSeconds();
		foreach (TimelineBinding binding in _timelineBindings)
		{
			if (binding.Agent.RuntimeId == _timelineEditorSelectedAgentId)
			{
				focusGuard = binding.Agent.IsEditorFocusGuardActive(monitorNow);
				break;
			}
		}

		bool hubActive = _client?.IsRunning == true && _endpointId > 0;
		bool remoteCanonical = hubActive &&
			_timelineHasCanonicalState &&
			!_timelineCanonicalOwner;

		string ownerLabel;
		if (remoteCanonical)
		{
			ownerLabel = _timelineCanonicalOwnerEndpointId > 0
				? $"REMOTE EP{_timelineCanonicalOwnerEndpointId}"
				: "REMOTE";
		}
		else if (leader is not null)
		{
			ownerLabel = hubActive
				? $"LOCAL {leader.Slot.Label}"
				: leader.Slot.Label;
		}
		else if (hubActive && _timelineHasCanonicalState && _timelineCanonicalOwner)
		{
			ownerLabel = "LOCAL";
		}
		else
		{
			ownerLabel = "--";
		}

		var lines = new List<string>
		{
			$"Mode      {mode}",
			$"Owner     {ownerLabel}",
			$"Focus     {focusLabel}" +
				(focusGuard ? "  GUARD" : string.Empty),
		};

		if (remoteCanonical)
		{
			lines.Add(
				$"Virtual   {_timelineCanonicalTime,7:0.000}s  " +
				$"{(_timelineCanonicalPlaying ? "PLAY" : "PAUSE")}");
		}
		else if (leader is not null &&
			leader.Agent.TryReadState(
				out double leaderTime,
				out bool leaderPlaying))
		{
			lines.Add(
				$"Virtual   {leaderTime,7:0.000}s  " +
				$"{(leaderPlaying ? "PLAY" : "PAUSE")}");
		}
		else if (hubActive && _timelineHasCanonicalState)
		{
			lines.Add(
				$"Virtual   {_timelineCanonicalTime,7:0.000}s  " +
				$"{(_timelineCanonicalPlaying ? "PLAY" : "PAUSE")}");
		}
		else
		{
			lines.Add("Virtual       --");
		}

		double minTime = double.PositiveInfinity;
		double maxTime = double.NegativeInfinity;
		int readableCount = 0;

		foreach (TimelineBinding binding in _timelineBindings)
		{
			if (!binding.Agent.TryReadState(
				out double timeSeconds,
				out bool isPlaying))
			{
				lines.Add($"{binding.Slot.Label,-8}      --  NO ANIMATION");
				continue;
			}

			minTime = Math.Min(minTime, timeSeconds);
			maxTime = Math.Max(maxTime, timeSeconds);
			readableCount++;

			lines.Add(
				$"{binding.Slot.Label,-8} {timeSeconds,7:0.000}s  " +
				$"{(isPlaying ? "PLAY" : "PAUSE")}");
		}

		if (readableCount >= 2)
		{
			lines.Add($"Spread    {Math.Max(0.0, maxTime - minTime),7:0.000}s");
		}

		return string.Join("\n", lines);
	}

	private static double GetClockSeconds()
	{
		return Time.GetTicksMsec() / 1000.0;
	}

	private void DrainControlEvents()
	{
		GHEG_GHubClient? client = _client;
		if (client is null)
			return;

		while (client.TryDequeue(
			out GHEG_ControlEvent? controlEvent))
		{
			if (controlEvent is null)
				continue;

			switch (controlEvent.Type)
			{
				case GHEG_ControlEventType.Connected:
					GD.Print(
						"[GHEG][" + ContextLabel + "] TCP CONNECTED / HELLO sent / " +
						controlEvent.Payload);
					break;

				case GHEG_ControlEventType.Message:
					HandleControlMessage(
						controlEvent.Payload);
					break;

				case GHEG_ControlEventType.Error:
					GD.PushError(
						"[GHEG] " +
						controlEvent.Payload);
					break;

				case GHEG_ControlEventType.Disconnected:
					bool requested =
						ShouldEndpointRun();

					AbortPendingFbxBridge("G-HUB connection closed.");
					ClearSessionRuntime();

					GD.Print(
						requested
							? "[GHEG][" + ContextLabel + "] DISCONNECTED / reconnect pending."
							: "[GHEG][" + ContextLabel + "] DISCONNECTED.");

					if (requested)
					{
						_reconnectRemaining =
							ReconnectDelaySeconds;
					}
					break;
			}
		}
	}

	private void HandleControlMessage(string raw)
	{
		try
		{
			using JsonDocument document =
				JsonDocument.Parse(raw);

			JsonElement root =
				document.RootElement;

			string type =
				ReadString(root, "type");

			switch (type)
			{
				case "ASSIGN":
					HandleAssign(root);
					break;

				case "CHANNEL_REGISTERED":
					HandleChannelRegistered(root);
					break;

				case "PORT_ASSIGN":
					HandlePortAssign(root);
					break;

				case "ROUTE":
					HandleRoute(root);
					break;

				case "ROUTE_REMOVE":
					HandleRouteRemove(root);
					break;

				case "RELAY":
					HandleRelay(root);
					break;

				case "TIMELINE_STATE":
					HandleTimelineState(root);
					break;

				case "REJECT":
					GD.PushError(
						"[GHEG] REJECT / " +
						ReadString(root, "reason"));
					break;
			}
		}
		catch (Exception ex)
		{
			GD.PushError(
				"[GHEG] Invalid G-HUB control JSON: " +
				ex.Message);
		}
	}

	private void ProcessDynamicSceneRegistrations(double delta)
	{
		GHEG_GHubClient? client = _client;
		if (client is null ||
			!client.IsRunning ||
			_endpointId <= 0 ||
			_sessionId <= 0)
		{
			_sceneRegistrationScanRemaining = 0.0;
			return;
		}

		_sceneRegistrationScanRemaining -= delta;
		if (_sceneRegistrationScanRemaining > 0.0)
			return;

		_sceneRegistrationScanRemaining =
			SceneRegistrationScanIntervalSeconds;

		// Never auto-register an ambiguous scene. Existing active channels are
		// left untouched; the scan only fills slots that are still unregistered.
		if (!TryValidateCharacterSlotConfiguration(out _) ||
			!TryValidateShapeKeySlotConfiguration(out _))
		{
			return;
		}

		double now = GetClockSeconds();

		foreach (CharacterSlotRuntime state in _characterSlots)
		{
			if (state.ChannelId > 0)
				continue;

			GHEG_Avatar? avatar = FindCharacterAvatar(state);
			state.Avatar = avatar;

			if (avatar is null)
			{
				state.ChannelRegistrationPending = false;
				state.ChannelRegistrationRequestedAt = 0.0;
				continue;
			}

			if (state.ChannelRegistrationPending &&
				now - state.ChannelRegistrationRequestedAt <
					ChannelRegistrationRetrySeconds)
			{
				continue;
			}

			if (client.Send(
				GHEG_Protocol.CharacterChannelAddMessage(state.SlotIndex)))
			{
				state.ChannelRegistrationPending = true;
				state.ChannelRegistrationRequestedAt = now;
				LogVerbose(
					$"[GHEG] CHANNEL_ADD / {state.Label} / " +
					$"scene change detected");
			}
		}

		foreach (ShapeKeySlotRuntime state in _shapeKeySlots)
		{
			if (state.ChannelId > 0)
				continue;

			GHEG_ShapeKeys? receiver = FindShapeKeyReceiver(state);
			state.Receiver = receiver;

			if (receiver is null)
			{
				state.ChannelRegistrationPending = false;
				state.ChannelRegistrationRequestedAt = 0.0;
				continue;
			}

			if (state.ChannelRegistrationPending &&
				now - state.ChannelRegistrationRequestedAt <
					ChannelRegistrationRetrySeconds)
			{
				continue;
			}

			if (!receiver.PrepareForSession(out _))
				continue;

			if (client.Send(
				GHEG_Protocol.ShapeKeyChannelAddMessage(state.SlotIndex)))
			{
				state.ChannelRegistrationPending = true;
				state.ChannelRegistrationRequestedAt = now;
				LogVerbose(
					$"[GHEG] FACE CHANNEL_ADD / {state.Label} / " +
					$"scene change detected");
			}
		}
	}

	private void HandleAssign(JsonElement root)
	{
		_endpointId =
			ReadInt(root, "endpoint_id");
		_sessionId =
			ReadLong(root, "session_id");

		LogVerbose(
			$"[GHEG] ASSIGN / " +
			$"Endpoint {_endpointId} / " +
			$"Session {_sessionId}");

		if (_endpointId <= 0 ||
			_sessionId <= 0)
		{
			GD.PushError(
				"[GHEG] Invalid ASSIGN message.");
			return;
		}

		if (!TryValidateCharacterSlotConfiguration(out string slotError))
		{
			GD.PushError(
				"[GHEG] Character Slot configuration rejected / " +
				slotError);
			return;
		}

		int registeredSlots = 0;

		foreach (CharacterSlotRuntime state in _characterSlots)
		{
			state.Avatar = FindCharacterAvatar(state);
			if (state.Avatar is null)
				continue;

			if (_client?.Send(
				GHEG_Protocol.CharacterChannelAddMessage(
					state.SlotIndex)) == true)
			{
				state.ChannelRegistrationPending = true;
				state.ChannelRegistrationRequestedAt = GetClockSeconds();
				registeredSlots++;
				LogVerbose(
					$"[GHEG] CHANNEL_ADD / {state.Label} / " +
					$"{state.MatchId} / local {state.LocalId}");
			}
			else
			{
				GD.PushError(
					$"[GHEG] Failed to send {state.Label} CHANNEL_ADD.");
			}
		}

		LogVerbose(
			$"[GHEG] Character Slot registration / {registeredSlots} active slot(s)");

		int registeredFaceSlots = 0;
		if (!TryValidateShapeKeySlotConfiguration(out string faceSlotError))
		{
			GD.PushError(
				"[GHEG] Shape Slot configuration rejected / " +
				faceSlotError);
		}
		else
		{
			foreach (ShapeKeySlotRuntime faceState in _shapeKeySlots)
			{
				faceState.Receiver = FindShapeKeyReceiver(faceState);
				if (faceState.Receiver is null)
					continue;

				if (!faceState.Receiver.PrepareForSession(out string faceError))
				{
					GD.PushError(
						$"[GHEG] FACE {faceState.Label} skipped / {faceError}");
					faceState.Receiver = null;
					continue;
				}

				if (_client?.Send(
					GHEG_Protocol.ShapeKeyChannelAddMessage(
						faceState.SlotIndex)) == true)
				{
					faceState.ChannelRegistrationPending = true;
					faceState.ChannelRegistrationRequestedAt = GetClockSeconds();
					registeredFaceSlots++;
					LogVerbose(
						$"[GHEG] FACE CHANNEL_ADD / {faceState.Label} / " +
						$"{faceState.MatchId} / local {faceState.LocalId}");
				}
			}
		}

		LogVerbose(
			$"[GHEG] Shape Slot registration / {registeredFaceSlots} active slot(s)");

		ResetTimelineRuntime(clearObservations: true);

		if (TimelineSyncEnabled &&
			_client?.Send(GHEG_Protocol.TimelineSyncRequestMessage()) == true)
		{
			LogVerbose(
				"[GHEG] TIMELINE_SYNC_REQUEST / Canonical state requested.");
		}
	}

	private void HandleChannelRegistered(JsonElement root)
	{
		int localId =
			ReadInt(root, "local_id");
		int channelId =
			ReadInt(root, "channel_id");

		ShapeKeySlotRuntime? faceState =
			FindShapeKeyStateByLocalId(localId);

		if (faceState is not null)
		{
			if (channelId <= 0)
			{
				GD.PushError(
					$"[GHEG] Invalid FACE {faceState.Label} CHANNEL_REGISTERED.");
				return;
			}

			faceState.ChannelId = channelId;
			faceState.ChannelRegistrationPending = false;
			faceState.ChannelRegistrationRequestedAt = 0.0;
			LogVerbose(
				$"[GHEG] FACE CHANNEL_REGISTERED / {faceState.Label} / " +
				$"CH_{channelId:000}");
			return;
		}

		CharacterSlotRuntime? state =
			FindCharacterStateByLocalId(localId);

		if (state is null)
			return;

		if (channelId <= 0)
		{
			GD.PushError(
				$"[GHEG] Invalid {state.Label} CHANNEL_REGISTERED.");
			return;
		}

		state.ChannelId = channelId;
		state.ChannelRegistrationPending = false;
		state.ChannelRegistrationRequestedAt = 0.0;

		LogVerbose(
			$"[GHEG] CHANNEL_REGISTERED / " +
			$"{state.Label} / CH_{channelId:000}");
	}

	private void HandlePortAssign(JsonElement root)
	{
		int channelId =
			ReadInt(root, "channel_id");
		int port =
			ReadInt(root, "port");

		if (channelId <= 0 || port <= 0)
			return;

		GHEG_GHubClient? client = _client;
		if (client is null)
			return;

		ShapeKeySlotRuntime? faceState =
			FindShapeKeyStateByChannelId(channelId);
		if (faceState is not null)
		{
			if (client.TryBindShapeKeyUdp(
				faceState.SlotIndex,
				port,
				out string faceError))
			{
				if (client.Send(
					GHEG_Protocol.ReadyMessage(channelId, port)))
				{
					LogVerbose(
						$"[GHEG] FACE READY / {faceState.Label} / " +
						$"CH_{channelId:000} / UDP {port}");
				}
			}
			else
			{
				GD.PushError(
					$"[GHEG] FACE UDP bind failed / {faceState.Label} / " +
					$"UDP {port} / {faceError}");
				client.Send(
					GHEG_Protocol.PortFailMessage(channelId, port));
			}

			return;
		}

		CharacterSlotRuntime? state =
			FindCharacterStateByChannelId(channelId);
		if (state is null)
			return;

		if (client.TryBindCharacterUdp(
			state.SlotIndex,
			port,
			out string error))
		{
			if (client.Send(
				GHEG_Protocol.ReadyMessage(
					channelId,
					port)))
			{
				LogVerbose(
					$"[GHEG] READY / {state.Label} / " +
					$"CH_{channelId:000} / UDP {port}");
			}
			else
			{
				GD.PushError(
					$"[GHEG] READY send failed / {state.Label}.");
			}

			return;
		}

		GD.PushError(
			$"[GHEG] UDP bind failed / " +
			$"{state.Label} / UDP {port} / {error}");

		client.Send(
			GHEG_Protocol.PortFailMessage(
				channelId,
				port));
	}

	private void HandleRoute(JsonElement root)
	{
		int targetChannelId =
			ReadInt(root, "target_channel_id");

		int routeId =
			ReadInt(root, "route_id");

		ShapeKeySlotRuntime? faceState =
			FindShapeKeyStateByChannelId(targetChannelId);
		if (faceState is not null)
		{
			if (routeId <= 0)
			{
				GD.PushError(
					$"[GHEG] Invalid FACE {faceState.Label} ROUTE message.");
				return;
			}

			faceState.RouteId = routeId;
			faceState.UdpObserved = false;
			LogVerbose(
				$"[GHEG] FACE ROUTE ACTIVE / {faceState.Label} / " +
				$"{faceState.MatchId} / UDP " +
				$"{_client?.GetShapeKeyUdpPort(faceState.SlotIndex) ?? 0} / " +
				$"Route {routeId}");
			return;
		}

		CharacterSlotRuntime? state =
			FindCharacterStateByChannelId(targetChannelId);
		if (state is null)
			return;

		if (routeId <= 0)
		{
			GD.PushError(
				$"[GHEG] Invalid {state.Label} ROUTE message.");
			return;
		}

		state.RouteId = routeId;

		LogVerbose(
			$"[GHEG] ROUTE ACTIVE / {state.Label} / " +
			$"UDP {_client?.GetCharacterUdpPort(state.SlotIndex) ?? 0} / " +
			$"Route {routeId}");

		ActivateCharacterRoute(state);
	}

	private void HandleRouteRemove(JsonElement root)
	{
		int routeId =
			ReadInt(root, "route_id");

		ShapeKeySlotRuntime? faceState =
			FindShapeKeyStateByRouteId(routeId);
		if (faceState is not null)
		{
			if (_activeFacialBake?.State == faceState)
			{
				AbortFacialBake(
					"ShapeMixer route was removed during Facial Bake.",
					sendCancel: false);
			}

			faceState.RouteId = 0;
			faceState.UdpObserved = false;

			LogVerbose(
				$"[GHEG] FACE ROUTE REMOVE / {faceState.Label} / Route {routeId}");

			int faceUdpPort =
				_client?.GetShapeKeyUdpPort(faceState.SlotIndex) ?? 0;
			if (faceState.ChannelId > 0 && faceUdpPort > 0)
			{
				_client?.Send(
					GHEG_Protocol.ReadyMessage(
						faceState.ChannelId,
						faceUdpPort));
			}

			return;
		}

		CharacterSlotRuntime? state =
			FindCharacterStateByRouteId(routeId);
		if (state is null)
			return;

		if (_pendingFbxBridgeRequest?.RouteId == routeId)
			AbortPendingFbxBridge("Character route was removed during FBX Bridge export.");

		state.RouteId = 0;
		ClearCharacterStreamState(state);

		LogVerbose(
			$"[GHEG] ROUTE REMOVE / {state.Label} / Route {routeId}");

		int udpPort =
			_client?.GetCharacterUdpPort(state.SlotIndex) ?? 0;

		if (state.ChannelId > 0 &&
			udpPort > 0)
		{
			_client?.Send(
				GHEG_Protocol.ReadyMessage(
					state.ChannelId,
					udpPort));

			LogVerbose(
				$"[GHEG] READY restored / " +
				$"{state.Label} / UDP {udpPort}");
		}
	}

	private void HandleRelay(JsonElement root)
	{
		int routeId =
			ReadInt(root, "route_id");

		if (!root.TryGetProperty(
			"payload",
			out JsonElement payload) ||
			payload.ValueKind != JsonValueKind.Object)
		{
			CharacterSlotRuntime? fallbackState =
				FindCharacterStateByRouteId(routeId);
			if (fallbackState is not null)
				HandleCharacterRelay(fallbackState, root);
			return;
		}

		ShapeKeySlotRuntime? faceState =
			FindShapeKeyStateByRouteId(routeId);
		if (faceState is not null)
		{
			HandleFacialBakeRelay(faceState, routeId, payload);
			return;
		}

		CharacterSlotRuntime? state =
			FindCharacterStateByRouteId(routeId);
		if (state is null)
			return;

		string command = ReadString(payload, "command");
		if (command == "FBX_EXPORT_COMPLETE" ||
			command == "FBX_EXPORT_ERROR")
		{
			HandleFbxBridgeRelay(state, routeId, payload);
			return;
		}

		HandleCharacterRelay(state, root);
	}

	private void ClearSessionRuntime()
	{
		_endpointId = 0;
		_sessionId = 0;
		ResetTimelineRuntime(clearObservations: true);

		foreach (CharacterSlotRuntime state in _characterSlots)
		{
			state.ChannelId = 0;
			state.RouteId = 0;
			state.ChannelRegistrationPending = false;
			state.ChannelRegistrationRequestedAt = 0.0;
			ClearCharacterStreamState(state);
			state.Avatar = null;
		}

		foreach (ShapeKeySlotRuntime state in _shapeKeySlots)
		{
			state.ChannelId = 0;
			state.RouteId = 0;
			state.UdpObserved = false;
			state.ChannelRegistrationPending = false;
			state.ChannelRegistrationRequestedAt = 0.0;
			state.Receiver = null;
		}
	}

	private bool HasAnySessionState()
	{
		foreach (CharacterSlotRuntime state in _characterSlots)
		{
			if (state.ChannelId != 0 || state.RouteId != 0)
				return true;
		}

		foreach (ShapeKeySlotRuntime state in _shapeKeySlots)
		{
			if (state.ChannelId != 0 || state.RouteId != 0)
				return true;
		}

		return false;
	}

	private bool TryValidateCharacterSlotConfiguration(out string error)
	{
		error = "";

		Node? root =
			Owner ??
			GetTree().CurrentScene ??
			GetParent();

		if (root is null)
		{
			error = "Scene root is unavailable.";
			return false;
		}

		var slotOwners =
			new string?[GHEG_Protocol.CharacterSlotCount];

		return TryValidateCharacterSlotConfigurationRecursive(
			root,
			slotOwners,
			out error);
	}

	private static bool TryValidateCharacterSlotConfigurationRecursive(
		Node node,
		string?[] slotOwners,
		out string error)
	{
		error = "";

		if (node is GHEG_Avatar avatar && avatar.Active)
		{
			int slotIndex = (int)avatar.Slot;

			if (slotIndex < 0 ||
				slotIndex >= GHEG_Protocol.CharacterSlotCount)
			{
				error =
					$"{avatar.Name}: invalid Character Slot {slotIndex + 1}.";
				return false;
			}

			string? existingOwner = slotOwners[slotIndex];
			if (!string.IsNullOrEmpty(existingOwner))
			{
				error =
					$"{GHEG_Protocol.CharacterSlotLabel(slotIndex)} is assigned to both " +
					$"'{existingOwner}' and '{avatar.Name}'.";
				return false;
			}

			slotOwners[slotIndex] = avatar.Name.ToString();
		}

		foreach (Node child in node.GetChildren())
		{
			if (!TryValidateCharacterSlotConfigurationRecursive(
				child,
				slotOwners,
				out error))
			{
				return false;
			}
		}

		return true;
	}

	private bool TryValidateShapeKeySlotConfiguration(out string error)
	{
		error = "";

		Node? root =
			Owner ??
			GetTree().CurrentScene ??
			GetParent();

		if (root is null)
		{
			error = "Scene root is unavailable.";
			return false;
		}

		var slotOwners =
			new string?[GHEG_Protocol.CharacterSlotCount];

		return TryValidateShapeKeySlotConfigurationRecursive(
			root,
			slotOwners,
			out error);
	}

	private static bool TryValidateShapeKeySlotConfigurationRecursive(
		Node node,
		string?[] slotOwners,
		out string error)
	{
		error = "";

		if (node is GHEG_ShapeKeys receiver && receiver.Active)
		{
			// An active ShapeKeys node with no Avatar assignment is a valid
			// pre-configuration state. Treat it as WAIT rather than rejecting
			// the entire face-slot configuration. AUTO ASSIGN can populate the
			// reference later, after which dynamic registration will pick it up.
			if (receiver.ResolveAvatar() is not null)
			{
				if (!receiver.TryResolveSlotIndex(out int slotIndex, out error))
				{
					error = $"{receiver.Name}: {error}";
					return false;
				}

				string? existingOwner = slotOwners[slotIndex];
				if (!string.IsNullOrEmpty(existingOwner))
				{
					error =
						$"Face {GHEG_Protocol.CharacterSlotLabel(slotIndex)} is assigned to both " +
						$"'{existingOwner}' and '{receiver.Name}'.";
					return false;
				}

				slotOwners[slotIndex] = receiver.Name.ToString();
			}
		}

		foreach (Node child in node.GetChildren())
		{
			if (!TryValidateShapeKeySlotConfigurationRecursive(
				child,
				slotOwners,
				out error))
			{
				return false;
			}
		}

		return true;
	}

	private ShapeKeySlotRuntime? FindShapeKeyStateByLocalId(int localId)
	{
		int index = localId - GHEG_Protocol.ShapeKeyLocalIdBase;
		if (index < 0 || index >= _shapeKeySlots.Length)
			return null;
		return _shapeKeySlots[index];
	}

	private ShapeKeySlotRuntime? FindShapeKeyStateByChannelId(int channelId)
	{
		if (channelId <= 0)
			return null;
		foreach (ShapeKeySlotRuntime state in _shapeKeySlots)
		{
			if (state.ChannelId == channelId)
				return state;
		}
		return null;
	}

	private ShapeKeySlotRuntime? FindShapeKeyStateByRouteId(int routeId)
	{
		if (routeId <= 0)
			return null;
		foreach (ShapeKeySlotRuntime state in _shapeKeySlots)
		{
			if (state.RouteId == routeId)
				return state;
		}
		return null;
	}

	private GHEG_ShapeKeys? FindShapeKeyReceiver(ShapeKeySlotRuntime state)
	{
		Node? root =
			Owner ??
			GetTree().CurrentScene ??
			GetParent();

		return root is null
			? null
			: FindShapeKeyReceiverRecursive(root, state.SlotIndex);
	}

	private static GHEG_ShapeKeys? FindShapeKeyReceiverRecursive(
		Node node,
		int slotIndex)
	{
		if (node is GHEG_ShapeKeys receiver &&
			receiver.Active &&
			receiver.TryResolveSlotIndex(out int receiverSlot, out _) &&
			receiverSlot == slotIndex)
		{
			return receiver;
		}

		foreach (Node child in node.GetChildren())
		{
			GHEG_ShapeKeys? found =
				FindShapeKeyReceiverRecursive(child, slotIndex);
			if (found is not null)
				return found;
		}

		return null;
	}

	private CharacterSlotRuntime? FindCharacterStateByLocalId(int localId)
	{
		if (localId < 1 || localId > _characterSlots.Length)
			return null;

		return _characterSlots[localId - 1];
	}

	private CharacterSlotRuntime? FindCharacterStateByChannelId(int channelId)
	{
		if (channelId <= 0)
			return null;

		foreach (CharacterSlotRuntime state in _characterSlots)
		{
			if (state.ChannelId == channelId)
				return state;
		}

		return null;
	}

	private CharacterSlotRuntime? FindCharacterStateByRouteId(int routeId)
	{
		if (routeId <= 0)
			return null;

		foreach (CharacterSlotRuntime state in _characterSlots)
		{
			if (state.RouteId == routeId)
				return state;
		}

		return null;
	}

	private CharacterSlotRuntime? FindCharacterStateForAvatar(GHEG_Avatar avatar)
	{
		foreach (CharacterSlotRuntime state in _characterSlots)
		{
			if (ReferenceEquals(state.Avatar, avatar))
				return state;
		}

		return null;
	}

	private static CharacterSlotRuntime[] CreateCharacterSlotRuntimes()
	{
		var states =
			new CharacterSlotRuntime[GHEG_Protocol.CharacterSlotCount];

		for (int slotIndex = 0; slotIndex < states.Length; slotIndex++)
			states[slotIndex] = new CharacterSlotRuntime(slotIndex);

		return states;
	}

	private static ShapeKeySlotRuntime[] CreateShapeKeySlotRuntimes()
	{
		var states =
			new ShapeKeySlotRuntime[GHEG_Protocol.CharacterSlotCount];

		for (int slotIndex = 0; slotIndex < states.Length; slotIndex++)
			states[slotIndex] = new ShapeKeySlotRuntime(slotIndex);

		return states;
	}
	private void ClearCharacterStreamState(CharacterSlotRuntime state)
	{
		// Keep the last received pose when a route/session ends.
		// Returning to the imported rest pose is an explicit user action
		// through GHEG_Avatar -> Reset Pose.
		if (state.OriginalPoseRotations.Count > 0 ||
			state.OriginalPosePositions.Count > 0)
		{
			LogVerbose(
				$"[GHEG] Body pose held / {state.Label} / " +
				$"{state.OriginalPoseRotations.Count} rotation(s) / " +
				$"{state.OriginalPosePositions.Count} position(s)");
		}

		state.RequestBones.Clear();
		state.AliasCandidates.Clear();
		state.AliasOriginalNames.Clear();
		state.SourceRestRotations.Clear();
		state.SourceRestPositions.Clear();
		state.PendingSourceRestRotations.Clear();
		state.PendingSourceRestPositions.Clear();
		state.OriginalPoseRotations.Clear();
		state.OriginalPosePositions.Clear();
		state.LastLiveRotations.Clear();
		state.LastLivePositions.Clear();
		state.LastTargetRotations.Clear();
		state.LastTargetPositions.Clear();
		state.LastAppliedRotations.Clear();
		state.LastAppliedPositions.Clear();
		state.FullRotationBoneIds.Clear();
		state.PositionBoneIds.Clear();

		state.AliasProbePending = false;
		state.FinalValidationPending = false;
		state.PoseContractReady = false;
		state.FullRotationLogPrinted = false;
		state.PositionLogPrinted = false;
		state.UdpObserved = false;
		state.SmartSwizzleObserved = false;
	}

	private void ActivateCharacterRoute(CharacterSlotRuntime state)
	{
		if (state.RouteId <= 0)
			return;

		GHEG_Avatar? avatar =
			FindCharacterAvatar(state);

		if (avatar is null)
		{
			GD.PushError(
				$"[GHEG] {state.Label} START skipped / " +
				$"no active GHEG_Avatar with Slot={state.Label} was found.");
			return;
		}

		if (!avatar.TryBuildRequestBones(
			out Dictionary<string, string> requestBones,
			out string error))
		{
			GD.PushError(
				$"[GHEG] {state.Label} START skipped / " + error);
			return;
		}

		Skeleton3D? skeleton =
			avatar.ResolveSkeleton();

		state.Avatar = avatar;
		state.RequestBones = requestBones;
		state.UdpObserved = false;
		state.SmartSwizzleObserved = false;

		PrepareCharacterFullRotationSet(
			state,
			avatar,
			skeleton);

		PrepareCharacterPositionSet(
			state,
			avatar,
			skeleton);

		bool cacheRestored =
			avatar.TryRestoreSmartSwizzleCache(
				out Dictionary<string, string> cachedRequestBones,
				out Dictionary<int, Quaternion> cachedRestRotations,
				out Dictionary<int, Vector3> cachedRestPositions,
				out int cachedBoneCount,
				out string cacheError);

		if (cacheRestored)
		{
			state.RequestBones =
				cachedRequestBones;

			state.SourceRestRotations.Clear();
			foreach (KeyValuePair<int, Quaternion> pair
				in cachedRestRotations)
			{
				state.SourceRestRotations[pair.Key] =
					pair.Value;
			}

			state.SourceRestPositions.Clear();
			foreach (KeyValuePair<int, Vector3> pair
				in cachedRestPositions)
			{
				state.SourceRestPositions[pair.Key] =
					pair.Value;
			}

			LogVerbose(
				$"[GHEG] Smart Swizzle cache restored / {state.Label} / " +
				$"Bones {cachedBoneCount}");
		}
		else if (
			avatar.CurrentSmartSwizzleCacheState ==
			GHEG_Avatar.SmartSwizzleCacheState.Stale)
		{
			LogVerbose(
				$"[GHEG] Smart Swizzle cache stale / {state.Label} / " +
				cacheError);
		}

		LogVerbose(
			$"[GHEG] {state.Label} Avatar resolved / " +
			$"{avatar.Name} / " +
			$"Skeleton {skeleton?.Name ?? "<null>"} / " +
			$"Bones {state.RequestBones.Count}");

		if (!SendCharacterStart(
			state,
			state.RequestBones))
		{
			GD.PushError(
				$"[GHEG] Failed to send {state.Label} START.");
			return;
		}

		LogVerbose(
			$"[GHEG] START / {state.Label} / " +
			$"requested bones: {state.RequestBones.Count}");

		if (cacheRestored)
		{
			FinalizeCharacterPoseContract(state);

			if (state.PoseContractReady)
			{
				LogVerbose(
					$"[GHEG] Smart Swizzle request skipped / {state.Label} / " +
					"serialized cache is Ready.");
				return;
			}

			LogVerbose(
				"[GHEG] Cached reference did not arm the Body contract. " +
				"Smart Swizzle recapture requested.");

			state.SourceRestRotations.Clear();
			state.SourceRestPositions.Clear();
		}

		BeginCharacterSmartSwizzleCapture(state);

		if (SendCharacterSmartSwizzleRequest(
			state,
			state.RequestBones))
		{
			LogVerbose(
				$"[GHEG] SMART_SWIZZLE_REQUEST / {state.Label} / " +
				$"requested bones: {state.RequestBones.Count}");
		}
		else
		{
			GD.PushError(
				$"[GHEG] Failed to send {state.Label} SMART_SWIZZLE_REQUEST.");
		}
	}

	private GHEG_Avatar? FindCharacterAvatar(CharacterSlotRuntime state)
	{
		Node? root =
			Owner ??
			GetTree().CurrentScene ??
			GetParent();

		if (root is null)
			return null;

		return FindCharacterAvatarRecursive(
			root,
			(GHEG_Avatar.CharacterSlot)state.SlotIndex);
	}

	private static GHEG_Avatar? FindCharacterAvatarRecursive(
		Node node,
		GHEG_Avatar.CharacterSlot slot)
	{
		if (node is GHEG_Avatar avatar &&
			avatar.Active &&
			avatar.Slot == slot)
		{
			return avatar;
		}

		foreach (Node child in node.GetChildren())
		{
			GHEG_Avatar? found =
				FindCharacterAvatarRecursive(child, slot);

			if (found is not null)
				return found;
		}

		return null;
	}

	private void HandleCharacterRelay(CharacterSlotRuntime state, JsonElement root)
	{
		int routeId =
			ReadInt(root, "route_id");

		if (routeId <= 0 ||
			routeId != state.RouteId ||
			!root.TryGetProperty(
				"payload",
				out JsonElement payload) ||
			payload.ValueKind != JsonValueKind.Object)
		{
			return;
		}

		string command =
			ReadString(payload, "command");

		if (command != "SMART_SWIZZLE_DATA")
			return;

		int receivedBones = 0;
		var resolvedBoneIds = new HashSet<string>();

		if (payload.TryGetProperty(
			"bones",
			out JsonElement bones) &&
			bones.ValueKind == JsonValueKind.Object)
		{
			foreach (JsonProperty bone in bones.EnumerateObject())
			{
				receivedBones++;
				resolvedBoneIds.Add(bone.Name);
			}
		}

		state.SmartSwizzleObserved = true;

		if (payload.TryGetProperty(
			"bones",
			out JsonElement restBones) &&
			restBones.ValueKind == JsonValueKind.Object)
		{
			CapturePendingSourceRestRotations(
				state,
				restBones);

			CapturePendingSourceRestPositions(
				state,
				restBones);
		}

		LogVerbose(
			$"[GHEG] SMART_SWIZZLE_DATA / {state.Label} / " +
			$"Bones {receivedBones} / " +
			$"Frame {ReadInt(payload, "rest_frame")}");

		if (state.AliasProbePending)
		{
			HandleCharacterAliasProbeResult(
				state,
				resolvedBoneIds);
			return;
		}

		int missingCount =
			PrintCharacterBoneContract(
				state,
				resolvedBoneIds);

		if (state.FinalValidationPending)
		{
			state.FinalValidationPending = false;

			if (missingCount == 0)
			{
				LogVerbose(
					"[GHEG] Bone Contract complete after " +
					"Godot import alias resolution.");

				CommitCharacterSmartSwizzleReference(state);
			}
			else
			{
				LogVerbose(
					"[GHEG] Bone Contract still incomplete after " +
					"alias validation. No further automatic rename " +
					"fallback will be attempted.");
			}

			return;
		}

		if (missingCount == 0)
		{
			LogVerbose(
				"[GHEG] Bone Contract complete.");

			CommitCharacterSmartSwizzleReference(state);

			return;
		}

		if (TryStartCharacterAliasProbe(
			state,
			resolvedBoneIds))
		{
			return;
		}

		LogVerbose(
			"[GHEG] Bone Contract incomplete: " +
			"no safe Godot import suffix fallback was available.");

	}

	private int PrintCharacterBoneContract(
		CharacterSlotRuntime state,
		HashSet<string> resolvedBoneIds)
	{
		int missingCount = 0;

		foreach (KeyValuePair<string, string> requested
			in state.RequestBones)
		{
			if (resolvedBoneIds.Contains(requested.Key))
				continue;

			missingCount++;

			LogVerbose(
				$"[GHEG] MISSING BONE / {state.Label} / " +
				$"ID {requested.Key} / {requested.Value}");
		}

		LogVerbose(
			$"[GHEG] BONE CONTRACT / {state.Label} / " +
			$"Requested {state.RequestBones.Count} / " +
			$"Resolved {resolvedBoneIds.Count} / " +
			$"Missing {missingCount}");

		return missingCount;
	}

	private bool TryStartCharacterAliasProbe(
		CharacterSlotRuntime state,
		HashSet<string> resolvedBoneIds)
	{
		state.AliasCandidates.Clear();
		state.AliasOriginalNames.Clear();

		var existingRequestedNames =
			new HashSet<string>(
				state.RequestBones.Values,
				StringComparer.Ordinal);

		var probeCandidateNames =
			new HashSet<string>(
				StringComparer.Ordinal);

		foreach (KeyValuePair<string, string> requested
			in state.RequestBones)
		{
			if (resolvedBoneIds.Contains(requested.Key))
				continue;

			if (!TryCreateGodotImportSuffixFallback(
				requested.Value,
				out string candidate))
			{
				continue;
			}

			// Never collapse two destination Bones onto one Source Bone.
			// A fallback is only eligible when the candidate name is not
			// already requested exactly by another Godot Skeleton Bone.
			if (existingRequestedNames.Contains(candidate) ||
				!probeCandidateNames.Add(candidate))
			{
				LogVerbose(
					$"[GHEG] BONE ALIAS SKIPPED / {state.Label} / " +
					$"ID {requested.Key} / {requested.Value} -> " +
					$"{candidate} / ambiguous candidate");
				continue;
			}

			state.AliasCandidates[requested.Key] =
				candidate;
			state.AliasOriginalNames[requested.Key] =
				requested.Value;

			LogVerbose(
				$"[GHEG] BONE ALIAS PROBE / {state.Label} / " +
				$"ID {requested.Key} / " +
				$"{requested.Value} -> {candidate}");
		}

		if (state.AliasCandidates.Count == 0)
			return false;

		var payload =
			new Dictionary<string, object>
			{
				["command"] = "SMART_SWIZZLE_REQUEST",
				["rest_frame"] = 0,
				["position_space"] = "local",
				["request_bones"] =
					new Dictionary<string, string>(
						state.AliasCandidates),
			};

		if (_client?.Send(
			GHEG_Protocol.RelayMessage(
				state.RouteId,
				payload)) != true)
		{
			GD.PushError(
				$"[GHEG] Failed to send {state.Label} Bone alias probe.");

			state.AliasCandidates.Clear();
			state.AliasOriginalNames.Clear();
			return false;
		}

		state.AliasProbePending = true;

		LogVerbose(
			$"[GHEG] BONE ALIAS PROBE sent / {state.Label} / " +
			$"{state.AliasCandidates.Count} candidate(s)");

		return true;
	}

	private void HandleCharacterAliasProbeResult(
		CharacterSlotRuntime state,
		HashSet<string> resolvedBoneIds)
	{
		state.AliasProbePending = false;

		int resolvedAliases = 0;
		int unresolvedAliases = 0;

		foreach (KeyValuePair<string, string> candidate
			in state.AliasCandidates)
		{
			string id = candidate.Key;
			string sourceName = candidate.Value;

			state.AliasOriginalNames.TryGetValue(
				id,
				out string? originalName);

			if (!resolvedBoneIds.Contains(id))
			{
				unresolvedAliases++;

				LogVerbose(
					$"[GHEG] BONE ALIAS UNRESOLVED / {state.Label} / " +
					$"ID {id} / {originalName ?? "<unknown>"} -> " +
					$"{sourceName}");
				continue;
			}

			state.RequestBones[id] =
				sourceName;
			resolvedAliases++;

			LogVerbose(
				$"[GHEG] BONE ALIAS RESOLVED / {state.Label} / " +
				$"ID {id} / {originalName ?? "<unknown>"} -> " +
				$"{sourceName}");
		}

		state.AliasCandidates.Clear();
		state.AliasOriginalNames.Clear();

		if (resolvedAliases <= 0)
		{
			LogVerbose(
				$"[GHEG] Bone alias probe resolved 0 Bone(s) / " +
				$"unresolved {unresolvedAliases}. " +
				"No automatic mapping change was applied.");
			return;
		}

		LogVerbose(
			$"[GHEG] Bone alias probe accepted / {state.Label} / " +
			$"Resolved {resolvedAliases} / " +
			$"Unresolved {unresolvedAliases}");

		// GHEC rebuilds its authoritative Bone cache whenever START is
		// received. Re-send the complete corrected map so the live CEU stream
		// also uses the verified alias, not only Smart Swizzle diagnostics.
		if (!SendCharacterStart(
			state,
			state.RequestBones))
		{
			GD.PushError(
				$"[GHEG] Failed to restart {state.Label} stream after " +
				"Bone alias resolution.");
			return;
		}

		state.UdpObserved = false;

		LogVerbose(
			$"[GHEG] START refreshed / {state.Label} / " +
			$"requested bones: {state.RequestBones.Count}");

		// Validate the full corrected contract once more. Only a Source-confirmed
		// alias is kept. We intentionally do not recurse into more rename guesses.
		if (!SendCharacterSmartSwizzleRequest(
			state,
			state.RequestBones))
		{
			GD.PushError(
				$"[GHEG] Failed to validate corrected {state.Label} Bone contract.");
			return;
		}

		state.FinalValidationPending = true;

		LogVerbose(
			$"[GHEG] BONE CONTRACT revalidation requested / {state.Label} / " +
			$"{state.RequestBones.Count} bones");
	}

	private bool SendCharacterStart(
		CharacterSlotRuntime state,
		IReadOnlyDictionary<string, string> requestBones)
	{
		var payload =
			new Dictionary<string, object>
			{
				["command"] = "START",
				["position_space"] = "local",
				["request_bones"] = requestBones,
			};

		return _client?.Send(
			GHEG_Protocol.RelayMessage(
				state.RouteId,
				payload)) == true;
	}

	private bool SendCharacterSmartSwizzleRequest(
		CharacterSlotRuntime state,
		IReadOnlyDictionary<string, string> requestBones)
	{
		var payload =
			new Dictionary<string, object>
			{
				["command"] = "SMART_SWIZZLE_REQUEST",
				["rest_frame"] = 0,
				["position_space"] = "local",
				["request_bones"] = requestBones,
			};

		return _client?.Send(
			GHEG_Protocol.RelayMessage(
				state.RouteId,
				payload)) == true;
	}


	public static ControlUiState GetControlUiState()
	{
		GHEG_System? instance = _instance;
		if (instance is null || !GodotObject.IsInstanceValid(instance))
			return new ControlUiState(false, false, false, 0, 0);

		bool running = instance._client?.IsRunning == true;
		bool sessionActive = running && instance._endpointId > 0;
		return new ControlUiState(
			instance.ConnectToGHub,
			running,
			sessionActive,
			instance._endpointId,
			instance._sessionId);
	}

	public static SlotUiState GetSlotUiState(int slotIndex)
	{
		GHEG_System? instance = _instance;
		if (instance is null || !GodotObject.IsInstanceValid(instance) ||
			slotIndex < 0 || slotIndex >= GHEG_Protocol.CharacterSlotCount)
		{
			return new SlotUiState(false, false, false, false, false, false);
		}

		CharacterSlotRuntime body = instance._characterSlots[slotIndex];
		ShapeKeySlotRuntime face = instance._shapeKeySlots[slotIndex];

		bool bodyConfigured = body.Avatar is not null &&
			GodotObject.IsInstanceValid(body.Avatar) && body.Avatar.Active;
		bool faceConfigured = face.Receiver is not null &&
			GodotObject.IsInstanceValid(face.Receiver) && face.Receiver.Active;

		return new SlotUiState(
			bodyConfigured,
			body.RouteId > 0,
			body.UdpObserved,
			faceConfigured,
			face.RouteId > 0,
			face.UdpObserved);
	}

	internal static bool TryGetSsDiagnosticSnapshot(
		int slotIndex,
		out SsDiagnosticSnapshot snapshot)
	{
		snapshot = new SsDiagnosticSnapshot
		{
			SlotIndex = slotIndex,
			SlotLabel = slotIndex >= 0 && slotIndex < GHEG_Protocol.CharacterSlotCount
				? GHEG_Protocol.CharacterSlotLabel(slotIndex)
				: "--",
		};

		GHEG_System? instance = _instance;
		if (instance is null || !GodotObject.IsInstanceValid(instance) ||
			slotIndex < 0 || slotIndex >= GHEG_Protocol.CharacterSlotCount)
		{
			return false;
		}

		CharacterSlotRuntime state = instance._characterSlots[slotIndex];
		GHEG_Avatar? avatar = state.Avatar;
		bool avatarReady = avatar is not null && GodotObject.IsInstanceValid(avatar) && avatar.Active;
		Skeleton3D? skeleton = avatarReady ? avatar!.ResolveSkeleton() : null;

		var result = new SsDiagnosticSnapshot
		{
			SlotIndex = slotIndex,
			SlotLabel = state.Label,
			AvatarConfigured = avatarReady,
			SkeletonReady = skeleton is not null && GodotObject.IsInstanceValid(skeleton),
			RouteReady = state.RouteId > 0,
			UdpObserved = state.UdpObserved,
			PoseContractReady = state.PoseContractReady,
			CacheStatus = avatarReady ? avatar!.SmartSwizzleCacheStatus : "Missing",
			PositionScale = avatarReady ? avatar!.LocalPositionScale : 0.0f,
			BoneCount = skeleton?.GetBoneCount() ?? 0,
			MappedBoneCount = state.RequestBones.Count,
			TranslationBoneCount = state.PositionBoneIds.Count,
		};

		if (skeleton is not null)
		{
			int boneCount = skeleton.GetBoneCount();
			for (int boneId = 0; boneId < boneCount; boneId++)
			{
				int parentId = skeleton.GetBoneParent(boneId);
				string parentName = parentId >= 0 && parentId < boneCount
					? skeleton.GetBoneName(parentId).ToString()
					: "--";

				result.Bones.Add(new SsBoneDiagnostic
				{
					BoneId = boneId,
					BoneName = skeleton.GetBoneName(boneId).ToString(),
					ParentName = parentName,
					Mapped = state.RequestBones.ContainsKey(boneId.ToString(CultureInfo.InvariantCulture)),
					TranslationEnabled = state.PositionBoneIds.Contains(boneId),
					GodotRest = skeleton.GetBoneRest(boneId),
					HasSourceRestRotation = state.SourceRestRotations.TryGetValue(boneId, out Quaternion sourceRestRotation),
					SourceRestRotation = sourceRestRotation,
					HasSourceRestPosition = state.SourceRestPositions.TryGetValue(boneId, out Vector3 sourceRestPosition),
					SourceRestPosition = sourceRestPosition,
					HasLiveRotation = state.LastLiveRotations.TryGetValue(boneId, out Quaternion liveRotation),
					LiveRotation = liveRotation,
					HasLivePosition = state.LastLivePositions.TryGetValue(boneId, out Vector3 livePosition),
					LivePosition = livePosition,
					HasTargetRotation = state.LastTargetRotations.TryGetValue(boneId, out Quaternion targetRotation),
					TargetRotation = targetRotation,
					HasTargetPosition = state.LastTargetPositions.TryGetValue(boneId, out Vector3 targetPosition),
					TargetPosition = targetPosition,
					AppliedRotation = state.LastAppliedRotations.TryGetValue(boneId, out Quaternion appliedRotation)
						? appliedRotation
						: skeleton.GetBonePoseRotation(boneId),
					AppliedPosition = state.LastAppliedPositions.TryGetValue(boneId, out Vector3 appliedPosition)
						? appliedPosition
						: skeleton.GetBonePosePosition(boneId),
				});
			}
		}

		snapshot = result;
		return true;
	}

	internal static bool TryGetSsScenePose(
		int slotIndex,
		int boneId,
		SsScenePoseKind poseKind,
		out Skeleton3D? skeleton,
		out Transform3D bonePose,
		out bool hasParent,
		out Transform3D parentPose)
	{
		skeleton = null;
		bonePose = Transform3D.Identity;
		hasParent = false;
		parentPose = Transform3D.Identity;

		GHEG_System? instance = _instance;
		if (instance is null || !GodotObject.IsInstanceValid(instance) ||
			slotIndex < 0 || slotIndex >= GHEG_Protocol.CharacterSlotCount)
		{
			return false;
		}

		CharacterSlotRuntime state = instance._characterSlots[slotIndex];
		GHEG_Avatar? avatar = state.Avatar;
		if (avatar is null || !GodotObject.IsInstanceValid(avatar) || !avatar.Active)
			return false;

		Skeleton3D? resolved = avatar.ResolveSkeleton();
		if (resolved is null || !GodotObject.IsInstanceValid(resolved) ||
			boneId < 0 || boneId >= resolved.GetBoneCount())
		{
			return false;
		}

		skeleton = resolved;
		bonePose = BuildSsSceneBoneGlobalPose(resolved, state, boneId, poseKind);

		int parentId = resolved.GetBoneParent(boneId);
		if (parentId >= 0 && parentId < resolved.GetBoneCount())
		{
			hasParent = true;
			parentPose = BuildSsSceneBoneGlobalPose(resolved, state, parentId, poseKind);
		}

		return true;
	}

	private static Transform3D BuildSsSceneBoneGlobalPose(
		Skeleton3D skeleton,
		CharacterSlotRuntime state,
		int boneId,
		SsScenePoseKind poseKind)
	{
		if (poseKind == SsScenePoseKind.Applied)
			return skeleton.GetBoneGlobalPose(boneId);

		var chain = new List<int>();
		int current = boneId;
		while (current >= 0 && current < skeleton.GetBoneCount())
		{
			chain.Add(current);
			current = skeleton.GetBoneParent(current);
		}

		Transform3D result = Transform3D.Identity;
		for (int i = chain.Count - 1; i >= 0; i--)
		{
			int id = chain[i];
			Transform3D local;

			if (poseKind == SsScenePoseKind.GodotRest)
			{
				local = skeleton.GetBoneRest(id);
			}
			else
			{
				Quaternion rotation = state.LastTargetRotations.TryGetValue(id, out Quaternion targetRotation)
					? targetRotation
					: skeleton.GetBonePoseRotation(id);
				Vector3 position = state.LastTargetPositions.TryGetValue(id, out Vector3 targetPosition)
					? targetPosition
					: skeleton.GetBonePosePosition(id);
				local = new Transform3D(new Basis(rotation), position);
			}

			result *= local;
		}

		return result;
	}

	internal static void ReleaseStaticReferencesForAssemblyReload()
	{
		GHEG_System? instance = _instance;
		_instance = null;

		if (instance is null)
			return;

		// The socket workers are stopped by GHEG_AssemblyReloadGuard first.
		// Drop the remaining managed references without touching Godot objects;
		// the editor may already be detaching scripts at this point.
		instance._client = null;

		foreach (CharacterSlotRuntime state in instance._characterSlots)
		{
			state.Avatar = null;
			state.RequestBones.Clear();
			state.AliasCandidates.Clear();
			state.AliasOriginalNames.Clear();
			state.SourceRestRotations.Clear();
			state.SourceRestPositions.Clear();
			state.PendingSourceRestRotations.Clear();
			state.PendingSourceRestPositions.Clear();
			state.OriginalPoseRotations.Clear();
			state.OriginalPosePositions.Clear();
			state.LastLiveRotations.Clear();
			state.LastLivePositions.Clear();
			state.LastTargetRotations.Clear();
			state.LastTargetPositions.Clear();
			state.LastAppliedRotations.Clear();
			state.LastAppliedPositions.Clear();
			state.FullRotationBoneIds.Clear();
			state.PositionBoneIds.Clear();
		}

		foreach (ShapeKeySlotRuntime state in instance._shapeKeySlots)
		{
			state.Receiver = null;
			state.ChannelId = 0;
			state.RouteId = 0;
			state.UdpObserved = false;
		}

		instance._timelineBindings.Clear();
		instance._timelineObservations.Clear();
		instance._timelineActiveIds.Clear();
		instance._timelineStaleIds.Clear();
		instance._timelineLeaderAgentId = 0;
		instance._timelineEditorSelectedAgentId = 0;
		instance._pendingFbxBridgeRequest = null;
	}

	public static FacialBakeUiState GetFacialBakeUiState(
		GHEG_FacePlayer player)
	{
		GHEG_System? instance = _instance;
		if (instance is null ||
			player is null ||
			!GodotObject.IsInstanceValid(player))
		{
			return new FacialBakeUiState(
				false, false, false, "Unavailable", 0, 0, 0, "");
		}

		GHEG_Avatar? avatar = player.ResolveAvatar();
		int slotIndex = avatar is null ? -1 : (int)avatar.Slot;
		ShapeKeySlotRuntime? state =
			slotIndex >= 0 && slotIndex < instance._shapeKeySlots.Length
				? instance._shapeKeySlots[slotIndex]
				: null;

		bool routeReady =
			instance._client?.IsRunning == true &&
			state is not null &&
			state.RouteId > 0 &&
			state.Receiver is not null;

		FacialBakeSession? session = instance._activeFacialBake;
		bool busy = session is not null;
		bool busyForThis =
			session is not null &&
			GodotObject.IsInstanceValid(session.Player) &&
			session.Player.GetInstanceId() == player.GetInstanceId();

		return new FacialBakeUiState(
			routeReady,
			busy,
			busyForThis,
			player.BakeStatus,
			busyForThis ? session!.CurrentFrame : player.StartFrame,
			busyForThis ? session!.StartFrame : player.StartFrame,
			busyForThis ? session!.EndFrame : player.EndFrame,
			player.LastBakeResourcePath);
	}

	public static bool TryStartFacialBake(
		GHEG_FacePlayer player,
		out string reason)
	{
		reason = "";

		GHEG_System? instance = _instance;
		if (instance is null ||
			player is null ||
			!GodotObject.IsInstanceValid(player))
		{
			reason = "GHEG is not available.";
			return false;
		}

		if (!Engine.IsEditorHint())
		{
			reason = "Facial Offline Bake is Editor Mode only.";
			return false;
		}

		if (instance._activeFacialBake is not null)
		{
			reason = "Another Facial Bake is already active.";
			return false;
		}

		if (!player.Active)
		{
			reason = "GHEG_FacePlayer is disabled.";
			return false;
		}

		if (player.Fps <= 0 || player.EndFrame < player.StartFrame)
		{
			reason = "Invalid Facial Bake range or FPS.";
			return false;
		}

		GHEG_Avatar? avatar = player.ResolveAvatar();
		GHEG_ShapeKeys? receiver = player.ResolveShapeKeys();
		if (avatar is null || receiver is null)
		{
			reason =
				"GHEG_FacePlayer requires one GHEG_Avatar and one GHEG_ShapeKeys under the same wrapper.";
			return false;
		}

		int slotIndex = (int)avatar.Slot;
		if (slotIndex < 0 || slotIndex >= instance._shapeKeySlots.Length)
		{
			reason = "Character Slot is invalid.";
			return false;
		}

		if (!receiver.TryResolveSlotIndex(out int receiverSlot, out string receiverError) ||
			receiverSlot != slotIndex)
		{
			reason = string.IsNullOrWhiteSpace(receiverError)
				? "GHEG_ShapeKeys Slot does not match GHEG_FacePlayer."
				: receiverError;
			return false;
		}

		ShapeKeySlotRuntime state = instance._shapeKeySlots[slotIndex];
		if (instance._client?.IsRunning != true ||
			state.RouteId <= 0 ||
			state.ChannelId <= 0)
		{
			reason =
				"Connect G-HUB and wait for this Character Face route to become active.";
			return false;
		}

		state.Receiver = receiver;
		if (!receiver.PrepareForSession(out string prepareError))
		{
			reason = prepareError;
			return false;
		}

		if (!player.BeginBakeCapture(
			receiver,
			player.StartFrame,
			player.EndFrame,
			player.Fps,
			out reason))
		{
			return false;
		}

		instance._facialBakeSerial++;
		if (instance._facialBakeSerial <= 0)
			instance._facialBakeSerial = 1001;

		var session = new FacialBakeSession
		{
			Player = player,
			Receiver = receiver,
			State = state,
			BakeId = instance._facialBakeSerial,
			StartFrame = player.StartFrame,
			EndFrame = player.EndFrame,
			OutputFps = player.Fps,
			CurrentFrame = player.StartFrame,
			ExpectedSourceFrame = player.StartFrame,
			SourceFps = player.Fps,
			StartedAt = GetClockSeconds(),
		};

		instance._activeFacialBake = session;
		instance.PauseTimelineForFacialBake();

		var payload = new Dictionary<string, object>
		{
			["command"] = "BAKE_BEGIN",
			["bake_id"] = session.BakeId,
			["start"] = session.StartFrame,
			["end"] = session.EndFrame,
			["fps"] = session.OutputFps,
		};

		if (instance._client.Send(
			GHEG_Protocol.RelayMessage(state.RouteId, payload)) != true)
		{
			instance._activeFacialBake = null;
			player.AbortBakeCapture("Failed");
			instance.ResumeTimelineAfterFacialBake();
			reason = "Failed to send BAKE_BEGIN to ShapeMixer.";
			return false;
		}

		instance.LogVerbose(
			$"[GHEG Facial Bake] START / {state.Label} / " +
			$"Frame {session.StartFrame} -> {session.EndFrame} @ {session.OutputFps} fps");
		return true;
	}

	public static bool TryCancelFacialBake(
		GHEG_FacePlayer player,
		out string reason)
	{
		reason = "";
		GHEG_System? instance = _instance;
		FacialBakeSession? session = instance?._activeFacialBake;

		if (instance is null || session is null)
		{
			reason = "No Facial Bake is active.";
			return false;
		}

		if (player is null ||
			!GodotObject.IsInstanceValid(player) ||
			session.Player.GetInstanceId() != player.GetInstanceId())
		{
			reason = "Another GHEG_FacePlayer owns the active Facial Bake.";
			return false;
		}

		instance.AbortFacialBake(
			"Cancelled by user.",
			sendCancel: true,
			pushError: false);
		return true;
	}

	private void PauseTimelineForFacialBake()
	{
		CollectTimelineBindings();
		foreach (TimelineBinding binding in _timelineBindings)
		{
			if (binding.Agent.TryReadState(out double time, out _))
				binding.Agent.ApplyState(time, isPlaying: false);
		}

		ResetTimelineRuntime(clearObservations: true);
		if (TimelineSyncEnabled && _endpointId > 0)
			_client?.Send(GHEG_Protocol.TimelineReleaseMessage());
	}

	private void ResumeTimelineAfterFacialBake()
	{
		ResetTimelineRuntime(clearObservations: true);
		if (TimelineSyncEnabled && _endpointId > 0)
			_client?.Send(GHEG_Protocol.TimelineSyncRequestMessage());
	}

	private void UpdateFacialBake()
	{
		FacialBakeSession? session = _activeFacialBake;
		if (session is null)
			return;

		if (!GodotObject.IsInstanceValid(session.Player) ||
			!GodotObject.IsInstanceValid(session.Receiver))
		{
			AbortFacialBake(
				"Facial Bake target was removed from the scene.",
				sendCancel: true);
			return;
		}

		if (_client?.IsRunning != true || session.State.RouteId <= 0)
		{
			AbortFacialBake(
				"ShapeMixer route was lost during Facial Bake.",
				sendCancel: false);
			return;
		}

		double now = GetClockSeconds();
		if (!session.Ready)
		{
			if (now - session.StartedAt > FacialBakeReadyTimeoutSeconds)
			{
				AbortFacialBake(
					"ShapeMixer did not acknowledge BAKE_BEGIN.",
					sendCancel: true);
			}
			return;
		}

		if (session.WaitingForFrame)
		{
			if (now - session.FrameRequestedAt <= FacialBakeFrameTimeoutSeconds)
				return;

			if (session.FrameRetryCount >= FacialBakeMaxFrameRetries)
			{
				AbortFacialBake(
					$"Frame {session.CurrentFrame} timed out after {FacialBakeMaxFrameRetries} retries.",
					sendCancel: true);
				return;
			}

			session.FrameRetryCount++;
			SendFacialBakeFrameRequest(session);
			return;
		}

		SendFacialBakeFrameRequest(session);
	}

	private void SendFacialBakeFrameRequest(FacialBakeSession session)
	{
		double timeSeconds =
			session.CurrentFrame / (double)session.OutputFps;

		session.ExpectedSourceFrame =
			(int)Math.Round(
				timeSeconds * session.SourceFps,
				MidpointRounding.ToEven);

		var payload = new Dictionary<string, object>
		{
			["command"] = "BAKE_FRAME_REQUEST",
			["bake_id"] = session.BakeId,
			["frame"] = session.CurrentFrame,
			["time_seconds"] = timeSeconds,
		};

		if (_client?.Send(
			GHEG_Protocol.RelayMessage(
				session.State.RouteId,
				payload)) != true)
		{
			AbortFacialBake(
				"Failed to request a Facial Bake frame.",
				sendCancel: false);
			return;
		}

		session.WaitingForFrame = true;
		session.FrameRequestedAt = GetClockSeconds();
	}

	private void HandleFacialBakeRelay(
		ShapeKeySlotRuntime state,
		int routeId,
		JsonElement payload)
	{
		FacialBakeSession? session = _activeFacialBake;
		if (session is null ||
			!ReferenceEquals(session.State, state) ||
			session.State.RouteId != routeId)
		{
			return;
		}

		string command = ReadString(payload, "command");
		int bakeId = ReadInt(payload, "bake_id");
		if (bakeId != session.BakeId)
			return;

		switch (command)
		{
			case "BAKE_READY":
			{
				double sourceFps = ReadDouble(payload, "source_fps");
				session.SourceFps = sourceFps > 0.0
					? sourceFps
					: session.OutputFps;
				session.Ready = true;
				session.WaitingForFrame = false;
				session.FrameRetryCount = 0;
				session.Player.SetBakeStatus(
					$"Baking C{state.SlotIndex + 1} / ShapeMixer {session.SourceFps:0.###} fps");

				LogVerbose(
					$"[GHEG Facial Bake] READY / {state.Label} / " +
					$"Output {session.OutputFps} fps / ShapeMixer {session.SourceFps:0.###} fps");
				break;
			}

			case "BAKE_ERROR":
			{
				string message = ReadString(payload, "reason");
				AbortFacialBake(
					string.IsNullOrWhiteSpace(message)
						? "ShapeMixer returned BAKE_ERROR."
						: message,
					sendCancel: false);
				break;
			}
		}
	}

	private void HandleFacialBakePacket(
		ShapeKeySlotRuntime state,
		byte[] packet)
	{
		FacialBakeSession? session = _activeFacialBake;
		if (session is null ||
			!session.Ready ||
			!session.WaitingForFrame ||
			!ReferenceEquals(session.State, state))
		{
			return;
		}

		if (!TryParseShapeBakePacket(
			packet,
			out int bakeId,
			out int sourceFrame,
			out Dictionary<string, float> weights,
			out string parseError))
		{
			AbortFacialBake(
				"Invalid ShapeMixer bake packet: " + parseError,
				sendCancel: true);
			return;
		}

		if (bakeId != session.BakeId ||
			sourceFrame != session.ExpectedSourceFrame)
		{
			return;
		}

		if (!session.Player.CaptureBakeSample(
			session.CurrentFrame,
			weights,
			out string captureError))
		{
			AbortFacialBake(captureError, sendCancel: true);
			return;
		}

		session.WaitingForFrame = false;
		session.FrameRetryCount = 0;

		int completed = session.CurrentFrame - session.StartFrame + 1;
		int total = session.EndFrame - session.StartFrame + 1;
		session.Player.SetBakeStatus(
			$"Baking {completed}/{total} frame(s)");

		if (session.CurrentFrame >= session.EndFrame)
		{
			CompleteFacialBake();
			return;
		}

		session.CurrentFrame++;
	}

	private void CompleteFacialBake()
	{
		FacialBakeSession? session = _activeFacialBake;
		if (session is null)
			return;

		var payload = new Dictionary<string, object>
		{
			["command"] = "BAKE_END",
			["bake_id"] = session.BakeId,
		};
		_client?.Send(
			GHEG_Protocol.RelayMessage(
				session.State.RouteId,
				payload));

		_activeFacialBake = null;

		if (!session.Player.CompleteBake(
			out string resourcePath,
			out string reason))
		{
			GD.PushError(
				$"[GHEG Facial Bake] WRITE ERROR / {session.State.Label} / {reason}");
			ResumeTimelineAfterFacialBake();
			return;
		}

		GD.Print(
			$"[GHEG Facial Bake] COMPLETE / {session.State.Label} / " +
			$"{session.EndFrame - session.StartFrame + 1} frame(s) / {resourcePath}");

		ResumeTimelineAfterFacialBake();
	}

	private void AbortFacialBake(
		string reason,
		bool sendCancel,
		bool pushError = true)
	{
		FacialBakeSession? session = _activeFacialBake;
		if (session is null)
			return;

		if (sendCancel &&
			_client?.IsRunning == true &&
			session.State.RouteId > 0)
		{
			var payload = new Dictionary<string, object>
			{
				["command"] = "BAKE_CANCEL",
				["bake_id"] = session.BakeId,
			};
			_client.Send(
				GHEG_Protocol.RelayMessage(
					session.State.RouteId,
					payload));
		}

		_activeFacialBake = null;
		if (GodotObject.IsInstanceValid(session.Player))
			session.Player.AbortBakeCapture(pushError ? "Failed" : "Cancelled");

		if (pushError)
			GD.PushError($"[GHEG Facial Bake] {reason}");
		else
			LogVerbose($"[GHEG Facial Bake] {reason}");

		ResumeTimelineAfterFacialBake();
	}

	private static bool TryParseShapeBakePacket(
		byte[] packet,
		out int bakeId,
		out int sourceFrame,
		out Dictionary<string, float> weights,
		out string error)
	{
		bakeId = 0;
		sourceFrame = 0;
		weights = new Dictionary<string, float>(StringComparer.Ordinal);
		error = "";

		if (packet.Length < 13 ||
			packet[0] != (byte)'G' ||
			packet[1] != (byte)'H' ||
			packet[2] != (byte)'S')
		{
			error = "Invalid GHS header.";
			return false;
		}

		try
		{
			using var stream = new MemoryStream(packet, writable: false);
			using var reader = new BinaryReader(stream, Encoding.UTF8, leaveOpen: false);

			reader.ReadByte();
			reader.ReadByte();
			reader.ReadByte();
			bakeId = reader.ReadInt32();
			sourceFrame = reader.ReadInt32();
			ushort shapeCount = reader.ReadUInt16();

			for (int i = 0; i < shapeCount; i++)
			{
				if (stream.Position + sizeof(ushort) > stream.Length)
					throw new EndOfStreamException("Missing Shape Key name length.");

				ushort nameLength = reader.ReadUInt16();
				if (nameLength == 0 || stream.Position + nameLength + sizeof(float) > stream.Length)
					throw new EndOfStreamException("Truncated Shape Key bake record.");

				string name = Encoding.UTF8.GetString(reader.ReadBytes(nameLength));
				float value = reader.ReadSingle();
				if (!string.IsNullOrWhiteSpace(name))
					weights[name] = value;
			}

			return true;
		}
		catch (Exception ex)
		{
			error = ex.Message;
			weights.Clear();
			return false;
		}
	}

	public static bool HasActiveCharacterRouteFor(
		GHEG_Avatar avatar)
	{
		GHEG_System? instance = _instance;
		if (instance is null ||
			avatar is null ||
			instance._client?.IsRunning != true)
		{
			return false;
		}

		CharacterSlotRuntime? state =
			instance.FindCharacterStateForAvatar(avatar);

		return state is not null && state.RouteId > 0;
	}

	public static FbxBridgeUiState GetFbxBridgeUiState(
		GHEG_Avatar avatar)
	{
		GHEG_System? instance = _instance;
		if (instance is null ||
			avatar is null ||
			!GodotObject.IsInstanceValid(avatar))
		{
			return new FbxBridgeUiState(
				false,
				false,
				false,
				false,
				"Unavailable",
				false,
				false,
				false,
				"",
				"");
		}

		CharacterSlotRuntime? state =
			instance.FindCharacterStateForAvatar(avatar);
		int slotIndex = state?.SlotIndex ?? (int)avatar.Slot;

		FbxBridgePendingRequest? pending =
			instance._pendingFbxBridgeRequest;
		bool busy = pending is not null;
		bool busyForThisAvatar =
			pending is not null &&
			pending.SlotIndex == slotIndex;
		bool importing = instance._fbxImportInProgress;
		bool importingForThisAvatar =
			importing && instance._fbxImportSlotIndex == slotIndex;

		FbxBridgeLastResult? last =
			slotIndex >= 0 && slotIndex < instance._fbxBridgeLastResults.Length
				? instance._fbxBridgeLastResults[slotIndex]
				: null;

		string phaseLabel = importingForThisAvatar
			? "Importing..."
			: importing
				? "Another Character is importing..."
				: busyForThisAvatar
					? GetFbxBridgePhaseLabel(pending!.Phase)
					: busy
						? "Another Character is exporting..."
						: "Ready";

		return new FbxBridgeUiState(
			busy,
			busyForThisAvatar,
			importing,
			importingForThisAvatar,
			phaseLabel,
			last?.HasResult == true,
			last?.Succeeded == true,
			last?.Imported == true,
			last?.ResourcePath ?? "",
			last?.Summary ?? "");
	}

	public static bool TryImportLastFbxFor(
		GHEG_Avatar avatar,
		out string reason)
	{
		reason = "";

		GHEG_System? instance = _instance;
		if (instance is null ||
			avatar is null ||
			!GodotObject.IsInstanceValid(avatar))
		{
			reason = "GHEG is not available.";
			return false;
		}

		if (!Engine.IsEditorHint())
		{
			reason = "FBX import is Editor Mode only.";
			return false;
		}

		if (instance._pendingFbxBridgeRequest is not null)
		{
			reason = "Wait for the active FBX Bridge export to finish.";
			return false;
		}

		if (instance._fbxImportInProgress)
		{
			reason = "Another FBX import is already active.";
			return false;
		}

		CharacterSlotRuntime? state =
			instance.FindCharacterStateForAvatar(avatar);
		int slotIndex = state?.SlotIndex ?? (int)avatar.Slot;
		if (slotIndex < 0 || slotIndex >= instance._fbxBridgeLastResults.Length)
		{
			reason = "Character Slot is invalid.";
			return false;
		}

		FbxBridgeLastResult last = instance._fbxBridgeLastResults[slotIndex];
		if (!last.HasResult ||
			!last.Succeeded ||
			string.IsNullOrWhiteSpace(last.ResourcePath))
		{
			reason = "Run FBX Bridge successfully before importing.";
			return false;
		}

		string absolutePath = ProjectSettings.GlobalizePath(last.ResourcePath);
		if (!File.Exists(absolutePath))
		{
			reason = "The exported FBX file no longer exists.";
			return false;
		}

#if TOOLS
		EditorFileSystem fileSystem =
			EditorInterface.Singleton.GetResourceFilesystem();
		if (fileSystem.IsImporting() || fileSystem.IsScanning())
		{
			reason = "Godot is already scanning or importing resources.";
			return false;
		}

		instance._fbxImportInProgress = true;
		instance._fbxImportSlotIndex = slotIndex;
		instance._fbxImportResourcePath = last.ResourcePath;
		instance._fbxImportStartedAt = GetClockSeconds();
		last.Imported = false;
		last.Summary = "Importing...";

		try
		{
			instance.LogVerbose(
				$"[GHEG FBX Bridge] IMPORT / " +
				$"{GHEG_Protocol.CharacterSlotLabel(slotIndex)} / {last.ResourcePath}");

			// The FBX and, on a fresh project, its destination directory can both
			// be new to EditorFileSystem. UpdateFile()+ReimportFiles() only works
			// reliably when the parent directory is already registered. Scan()
			// discovers new directories/files and performs the required import.
			// Completion is observed asynchronously from _Process().
			fileSystem.Scan();
			return true;
		}
		catch (Exception ex)
		{
			last.Imported = false;
			last.Summary = "Import error";
			reason = ex.Message;
			instance.ClearFbxImportState();
			GD.PushError(
				$"[GHEG FBX Bridge] IMPORT ERROR / " +
				$"{GHEG_Protocol.CharacterSlotLabel(slotIndex)} / {reason}");
			return false;
		}
#else
		reason = "Godot editor services are unavailable.";
		return false;
#endif
	}

	private void UpdateFbxImport()
	{
#if TOOLS
		if (!_fbxImportInProgress)
			return;

		int slotIndex = _fbxImportSlotIndex;
		if (slotIndex < 0 || slotIndex >= _fbxBridgeLastResults.Length)
		{
			ClearFbxImportState();
			return;
		}

		EditorFileSystem fileSystem =
			EditorInterface.Singleton.GetResourceFilesystem();

		// Scan/import runs through the editor main loop. Do not inspect the
		// resource table until Godot has finished both stages.
		if (fileSystem.IsScanning() || fileSystem.IsImporting())
			return;

		double elapsed = GetClockSeconds() - _fbxImportStartedAt;
		if (elapsed < 0.10)
			return;

		FbxBridgeLastResult last = _fbxBridgeLastResults[slotIndex];
		string resourcePath = _fbxImportResourcePath;
		string resourceType = string.IsNullOrWhiteSpace(resourcePath)
			? ""
			: fileSystem.GetFileType(resourcePath);

		if (!string.IsNullOrWhiteSpace(resourceType))
		{
			last.Imported = true;
			last.Summary = "Imported";
			GD.Print(
				$"[GHEG FBX Bridge] IMPORT COMPLETE / " +
				$"{GHEG_Protocol.CharacterSlotLabel(slotIndex)} / " +
				$"{resourceType} / {resourcePath}");
			ClearFbxImportState();
			return;
		}

		if (elapsed < FbxImportTimeoutSeconds)
			return;

		last.Imported = false;
		last.Summary = "Import error";
		GD.PushError(
			$"[GHEG FBX Bridge] IMPORT ERROR / " +
			$"{GHEG_Protocol.CharacterSlotLabel(slotIndex)} / " +
			$"Godot did not register an imported resource type for {resourcePath}.");
		ClearFbxImportState();
#endif
	}

	private void ClearFbxImportState()
	{
		_fbxImportInProgress = false;
		_fbxImportSlotIndex = -1;
		_fbxImportResourcePath = "";
		_fbxImportStartedAt = 0.0;
	}

	public static bool TryStartFbxBridge(
		GHEG_Avatar avatar,
		out string reason)
	{
		reason = "";

		GHEG_System? instance = _instance;
		if (instance is null ||
			avatar is null ||
			!GodotObject.IsInstanceValid(avatar))
		{
			reason = "GHEG is not available.";
			return false;
		}

		if (!Engine.IsEditorHint())
		{
			reason = "FBX Bridge is Editor Mode only.";
			return false;
		}

		if (instance._pendingFbxBridgeRequest is not null)
		{
			reason = "Another FBX Bridge request is already active.";
			return false;
		}

		if (instance._fbxImportInProgress)
		{
			reason = "Wait for the active FBX import to finish.";
			return false;
		}

		CharacterSlotRuntime? state =
			instance.FindCharacterStateForAvatar(avatar);

		if (instance._client?.IsRunning != true ||
			state is null ||
			state.RouteId <= 0)
		{
			reason =
				"Connect G-HUB and wait for this Character route to become active.";
			return false;
		}

		if (!TryResolveFbxBridgeDestination(
			avatar,
			state.SlotIndex,
			out string resourcePath,
			out string destinationPath,
			out reason))
		{
			return false;
		}

		string requestId = Guid.NewGuid().ToString("N");
		string tempDirectory = Path.Combine(
			Path.GetTempPath(),
			FbxBridgeWireTempRootName,
			requestId);
		string tempFilePath = Path.GetFullPath(
			Path.Combine(
				tempDirectory,
				$"Character{state.SlotIndex + 1}.fbx"));

		try
		{
			Directory.CreateDirectory(tempDirectory);
		}
		catch (Exception ex)
		{
			reason = "Could not create FBX Bridge temp directory: " + ex.Message;
			return false;
		}

		instance._pendingFbxBridgeRequest =
			new FbxBridgePendingRequest
			{
				RequestId = requestId,
				RouteId = state.RouteId,
				SlotIndex = state.SlotIndex,
				TempDirectory = tempDirectory,
				TempFilePath = tempFilePath,
				ResourcePath = resourcePath,
				DestinationPath = destinationPath,
				StartedAt = GetClockSeconds(),
				Phase = FbxBridgePhase.Exporting,
			};

		var payload =
			new Dictionary<string, object>
			{
				["command"] = "FBX_EXPORT_REQUEST",
				["request_id"] = requestId,
				["file_path"] = tempFilePath,
				["export_scope"] = FbxBridgeExportScope,
				["transaction_version"] = FbxBridgeTransactionVersion,
			};

		if (instance._client.Send(
			GHEG_Protocol.RelayMessage(
				state.RouteId,
				payload)) != true)
		{
			instance._pendingFbxBridgeRequest = null;
			TryDeleteDirectory(tempDirectory);
			reason = "Failed to send FBX_EXPORT_REQUEST.";
			return false;
		}

		instance.LogVerbose(
			$"[GHEG FBX Bridge] REQUEST / {state.Label} / " +
			$"{resourcePath}");
		return true;
	}

	private static string GetFbxBridgePhaseLabel(FbxBridgePhase phase)
	{
		return phase switch
		{
			FbxBridgePhase.Exporting => "Exporting from Cascadeur...",
			FbxBridgePhase.Copying => "Copying FBX into project...",
			FbxBridgePhase.Registering => "Registering FBX in FileSystem...",
			FbxBridgePhase.Complete => "Complete",
			_ => "Working...",
		};
	}

	private static FbxBridgeLastResult[] CreateFbxBridgeLastResults()
	{
		var results =
			new FbxBridgeLastResult[GHEG_Protocol.CharacterSlotCount];

		for (int i = 0; i < results.Length; i++)
			results[i] = new FbxBridgeLastResult();

		return results;
	}

	private static bool TryResolveFbxBridgeDestination(
		GHEG_Avatar avatar,
		int slotIndex,
		out string resourcePath,
		out string destinationPath,
		out string reason)
	{
		resourcePath = "";
		destinationPath = "";
		reason = "";

		string folder = avatar.EffectiveFbxBridgeOutputFolder.Trim();
		if (!folder.StartsWith("res://", StringComparison.OrdinalIgnoreCase))
		{
			reason = "FBX Bridge Output Folder must be inside res://.";
			return false;
		}

		folder = folder.Replace('\\', '/');
		if (!string.Equals(folder, "res://", StringComparison.OrdinalIgnoreCase))
			folder = folder.TrimEnd('/');
		if (folder.Contains("/../", StringComparison.Ordinal) ||
			folder.EndsWith("/..", StringComparison.Ordinal))
		{
			reason = "FBX Bridge Output Folder cannot contain '..'.";
			return false;
		}

		string baseName = SanitizeFbxAssetBaseName(
			avatar.EffectiveFbxBridgeAssetName,
			slotIndex);
		string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
		string folderPrefix = folder.EndsWith("/", StringComparison.Ordinal)
			? folder
			: folder + "/";
		string candidate = $"{folderPrefix}{baseName}_{timestamp}.fbx";
		string absolute = ProjectSettings.GlobalizePath(candidate);

		int suffix = 2;
		while (File.Exists(absolute))
		{
			candidate = $"{folderPrefix}{baseName}_{timestamp}_{suffix}.fbx";
			absolute = ProjectSettings.GlobalizePath(candidate);
			suffix++;
		}

		try
		{
			string? directory = Path.GetDirectoryName(absolute);
			if (string.IsNullOrWhiteSpace(directory))
			{
				reason = "FBX Bridge destination directory is invalid.";
				return false;
			}

			Directory.CreateDirectory(directory);
		}
		catch (Exception ex)
		{
			reason = "Could not create FBX Bridge output folder: " + ex.Message;
			return false;
		}

		resourcePath = candidate;
		destinationPath = absolute;
		return true;
	}

	private static string SanitizeFbxAssetBaseName(
		string value,
		int slotIndex)
	{
		string source = string.IsNullOrWhiteSpace(value)
			? $"Character{slotIndex + 1}"
			: value.Trim();

		var invalid = new HashSet<char>(Path.GetInvalidFileNameChars())
		{
			'/',
			'\\',
		};

		var builder = new System.Text.StringBuilder(source.Length);
		foreach (char c in source)
			builder.Append(invalid.Contains(c) ? '_' : c);

		string result = builder.ToString().Trim().Trim('.');
		return string.IsNullOrWhiteSpace(result)
			? $"Character{slotIndex + 1}"
			: result;
	}

	public static bool RequestSmartSwizzleFor(
		GHEG_Avatar avatar,
		out string reason)
	{
		reason = "";

		GHEG_System? instance = _instance;
		if (instance is null ||
			avatar is null ||
			!GodotObject.IsInstanceValid(avatar))
		{
			reason = "GHEG is not available.";
			return false;
		}

		CharacterSlotRuntime? state =
			instance.FindCharacterStateForAvatar(avatar);

		if (instance._client?.IsRunning != true ||
			state is null ||
			state.RouteId <= 0)
		{
			reason =
				"Connect G-HUB and wait for this Character route to become active.";
			return false;
		}

		return instance.RequestCharacterSmartSwizzle(
			state,
			avatar,
			out reason);
	}

	private bool RequestCharacterSmartSwizzle(
		CharacterSlotRuntime state,
		GHEG_Avatar avatar,
		out string reason)
	{
		reason = "";

		if (!avatar.TryBuildRequestBones(
			out Dictionary<string, string> requestBones,
			out string error))
		{
			reason = error;
			return false;
		}

		// A valid cache may contain Source-confirmed Godot import aliases.
		// Reuse those request names for a manual refresh so the same proven
		// Bone contract is requested again.
		if (avatar.TryRestoreSmartSwizzleCache(
			out Dictionary<string, string> cachedRequestBones,
			out _,
			out _,
			out _,
			out _))
		{
			requestBones = cachedRequestBones;
		}

		state.Avatar = avatar;
		state.RequestBones = requestBones;

		Skeleton3D? skeleton = avatar.ResolveSkeleton();
		PrepareCharacterFullRotationSet(
			state,
			avatar,
			skeleton,
			preserveOriginalPose: true);
		PrepareCharacterPositionSet(
			state,
			avatar,
			skeleton,
			preserveOriginalPose: true);

		BeginCharacterSmartSwizzleCapture(state);

		if (!SendCharacterStart(
			state,
			state.RequestBones))
		{
			reason = "Failed to refresh the Character START contract.";
			return false;
		}

		state.UdpObserved = false;

		if (!SendCharacterSmartSwizzleRequest(
			state,
			state.RequestBones))
		{
			reason = "Failed to send SMART_SWIZZLE_REQUEST.";
			return false;
		}

		LogVerbose(
			$"[GHEG] SMART_SWIZZLE_REQUEST / {state.Label} / manual / " +
			$"requested bones: {state.RequestBones.Count}");

		return true;
	}

	private void HandleFbxBridgeRelay(
		CharacterSlotRuntime state,
		int routeId,
		JsonElement payload)
	{
		FbxBridgePendingRequest? pending = _pendingFbxBridgeRequest;
		if (pending is null)
			return;

		string requestId = ReadString(payload, "request_id");
		if (routeId != pending.RouteId ||
			state.SlotIndex != pending.SlotIndex ||
			!string.Equals(
				requestId,
				pending.RequestId,
				StringComparison.OrdinalIgnoreCase))
		{
			GD.PushWarning(
				"[GHEG FBX Bridge] Ignored stale or mismatched reply.");
			return;
		}

		int transactionVersion =
			ReadInt(payload, "transaction_version");
		if (transactionVersion != FbxBridgeTransactionVersion)
		{
			FailFbxBridgeTransaction(
				pending,
				$"Protocol mismatch: expected {FbxBridgeTransactionVersion}, " +
				$"got {transactionVersion}.");
			return;
		}

		string command = ReadString(payload, "command");
		if (command == "FBX_EXPORT_ERROR")
		{
			string error = ReadString(payload, "reason");
			FailFbxBridgeTransaction(
				pending,
				string.IsNullOrWhiteSpace(error)
					? "Cascadeur FBX export failed."
					: error);
			return;
		}

		if (command != "FBX_EXPORT_COMPLETE")
			return;

		try
		{
			string returnedPath =
				Path.GetFullPath(ReadString(payload, "file_path"));
			string expectedPath =
				Path.GetFullPath(pending.TempFilePath);

			if (!string.Equals(
				returnedPath,
				expectedPath,
				StringComparison.OrdinalIgnoreCase))
			{
				throw new InvalidOperationException(
					"Cascadeur returned an unexpected FBX temp path.");
			}

			long reportedSize = ReadLong(payload, "file_size");
			int selectedJointCount = ReadInt(payload, "selected_joint_count");
			string exportScope = ReadString(payload, "export_scope");

			if (!string.Equals(
				exportScope,
				FbxBridgeExportScope,
				StringComparison.Ordinal))
			{
				throw new InvalidOperationException(
					$"Unsupported FBX export scope '{exportScope}'.");
			}

			if (selectedJointCount <= 0)
				throw new InvalidOperationException("FBX export contained no Character joints.");

			if (!File.Exists(expectedPath))
				throw new FileNotFoundException("Cascadeur FBX output was not created.", expectedPath);

			long actualSize = new FileInfo(expectedPath).Length;
			if (actualSize <= 0 ||
				(reportedSize > 0 && actualSize != reportedSize))
			{
				throw new InvalidOperationException(
					"FBX export size validation failed.");
			}

			pending.Phase = FbxBridgePhase.Copying;
			File.Copy(
				expectedPath,
				pending.DestinationPath,
				overwrite: false);

			long committedSize = new FileInfo(pending.DestinationPath).Length;
			if (committedSize != actualSize)
				throw new InvalidOperationException("Committed FBX size validation failed.");

			pending.Phase = FbxBridgePhase.Registering;
			RegisterGodotFilesystemFile(pending.ResourcePath);

			pending.Phase = FbxBridgePhase.Complete;
			SetFbxBridgeLastResult(
				pending.SlotIndex,
				true,
				$"{pending.ResourcePath} / {selectedJointCount} joints",
				pending.ResourcePath);

			_pendingFbxBridgeRequest = null;
			TryDeleteDirectory(pending.TempDirectory);

			GD.Print(
				$"[GHEG FBX Bridge] COMPLETE / " +
				$"{GHEG_Protocol.CharacterSlotLabel(pending.SlotIndex)} / " +
				$"{selectedJointCount} joints / {actualSize} bytes / " +
				$"{pending.ResourcePath}");
		}
		catch (Exception ex)
		{
			FailFbxBridgeTransaction(pending, ex.Message);
		}
	}

	private void CheckFbxBridgeTimeout()
	{
		FbxBridgePendingRequest? pending = _pendingFbxBridgeRequest;
		if (pending is null)
			return;

		if (GetClockSeconds() - pending.StartedAt < FbxBridgeTimeoutSeconds)
			return;

		FailFbxBridgeTransaction(
			pending,
			$"Request timed out after {FbxBridgeTimeoutSeconds:0} seconds.");
	}

	private void AbortPendingFbxBridge(string reason)
	{
		FbxBridgePendingRequest? pending = _pendingFbxBridgeRequest;
		if (pending is null)
			return;

		_pendingFbxBridgeRequest = null;
		TryDeleteDirectory(pending.TempDirectory);
		SetFbxBridgeLastResult(
			pending.SlotIndex,
			false,
			reason);

		GD.PushWarning(
			$"[GHEG FBX Bridge] ABORT / " +
			$"{GHEG_Protocol.CharacterSlotLabel(pending.SlotIndex)} / {reason}");
	}

	private void FailFbxBridgeTransaction(
		FbxBridgePendingRequest pending,
		string reason)
	{
		if (ReferenceEquals(_pendingFbxBridgeRequest, pending))
			_pendingFbxBridgeRequest = null;

		try
		{
			if (File.Exists(pending.DestinationPath))
				File.Delete(pending.DestinationPath);
		}
		catch (Exception cleanupError)
		{
			GD.PushWarning(
				"[GHEG FBX Bridge] Destination cleanup warning: " +
				cleanupError.Message);
		}

		TryDeleteDirectory(pending.TempDirectory);
		SetFbxBridgeLastResult(
			pending.SlotIndex,
			false,
			reason);

		GD.PushError(
			$"[GHEG FBX Bridge] ERROR / " +
			$"{GHEG_Protocol.CharacterSlotLabel(pending.SlotIndex)} / {reason}");
	}

	private void SetFbxBridgeLastResult(
		int slotIndex,
		bool succeeded,
		string summary,
		string resourcePath = "")
	{
		if (slotIndex < 0 || slotIndex >= _fbxBridgeLastResults.Length)
			return;

		FbxBridgeLastResult result = _fbxBridgeLastResults[slotIndex];
		result.HasResult = true;
		result.Succeeded = succeeded;
		result.Imported = false;
		result.ResourcePath = succeeded ? resourcePath : "";
		result.Summary = summary;
	}

	private static void TryDeleteDirectory(string directory)
	{
		if (string.IsNullOrWhiteSpace(directory))
			return;

		try
		{
			if (Directory.Exists(directory))
				Directory.Delete(directory, recursive: true);
		}
		catch (Exception ex)
		{
			GD.PushWarning(
				"[GHEG FBX Bridge] Temp cleanup warning: " + ex.Message);
		}
	}

	private static void RegisterGodotFilesystemFile(string resourcePath)
	{
#if TOOLS
		try
		{
			EditorFileSystem fileSystem =
				EditorInterface.Singleton.GetResourceFilesystem();

			// Register only the newly-created FBX. Do not force a project-wide
			// Scan()/import here: FBX Bridge creates the canonical artifact first,
			// while Godot import/application remains an explicit later step.
			fileSystem.UpdateFile(resourcePath);
		}
		catch (Exception ex)
		{
			GD.PushWarning(
				"[GHEG FBX Bridge] Godot filesystem registration warning: " +
				ex.Message);
		}
#endif
	}

	private void BeginCharacterSmartSwizzleCapture(CharacterSlotRuntime state)
	{
		state.PendingSourceRestRotations.Clear();
		state.PendingSourceRestPositions.Clear();
		state.AliasCandidates.Clear();
		state.AliasOriginalNames.Clear();

		state.AliasProbePending = false;
		state.FinalValidationPending = false;
		state.SmartSwizzleObserved = false;
	}

	private bool CommitCharacterSmartSwizzleReference(CharacterSlotRuntime state)
	{
		GHEG_Avatar? avatar =
			state.Avatar;

		Skeleton3D? skeleton =
			avatar?.ResolveSkeleton();

		if (avatar is null ||
			skeleton is null)
		{
			return false;
		}

		int missingReferenceCount = 0;

		foreach (int boneId in
			state.FullRotationBoneIds)
		{
			if (!state.PendingSourceRestRotations.ContainsKey(
				boneId))
			{
				missingReferenceCount++;

				LogVerbose(
					$"[GHEG] Smart Swizzle missing Rest rotation / {state.Label} / " +
					$"ID {boneId} / {skeleton.GetBoneName(boneId)}");
			}
		}

		foreach (int boneId in
			state.PositionBoneIds)
		{
			if (!state.PendingSourceRestPositions.ContainsKey(
				boneId))
			{
				missingReferenceCount++;

				LogVerbose(
					$"[GHEG] Smart Swizzle missing Rest position / {state.Label} / " +
					$"ID {boneId} / {skeleton.GetBoneName(boneId)}");
			}
		}

		if (missingReferenceCount > 0)
		{
			LogVerbose(
				"[GHEG] Smart Swizzle reference was not committed / " +
				"incomplete Rest data.");
			return false;
		}

		state.SourceRestRotations.Clear();
		foreach (KeyValuePair<int, Quaternion> pair
			in state.PendingSourceRestRotations)
		{
			state.SourceRestRotations[pair.Key] =
				pair.Value;
		}

		state.SourceRestPositions.Clear();
		foreach (KeyValuePair<int, Vector3> pair
			in state.PendingSourceRestPositions)
		{
			state.SourceRestPositions[pair.Key] =
				pair.Value;
		}

		FinalizeCharacterPoseContract(state);

		if (!state.PoseContractReady)
			return false;

		if (!avatar.StoreSmartSwizzleCache(
			state.RequestBones,
			state.SourceRestRotations,
			state.SourceRestPositions,
			out string cacheError))
		{
			GD.PushWarning(
				"[GHEG] Smart Swizzle reference is active but " +
				"could not be serialized: " + cacheError);
		}

		state.PendingSourceRestRotations.Clear();
		state.PendingSourceRestPositions.Clear();

		return true;
	}

	private static bool TryCreateGodotImportSuffixFallback(
		string importedBoneName,
		out string candidate)
	{
		candidate = "";

		if (string.IsNullOrWhiteSpace(importedBoneName))
			return false;

		int underscore =
			importedBoneName.LastIndexOf('_');

		if (underscore <= 0 ||
			underscore >= importedBoneName.Length - 1)
		{
			return false;
		}

		string suffix =
			importedBoneName[(underscore + 1)..];

		if (!int.TryParse(
			suffix,
			out int suffixNumber))
		{
			return false;
		}

		// Godot import collision suffixes begin at _2. Do not reinterpret a
		// natural "_0" or "_1" Bone name as an importer alias.
		if (suffixNumber < 2)
			return false;

		candidate =
			importedBoneName[..underscore];

		return !string.IsNullOrWhiteSpace(candidate);
	}

	private void DrainCharacterUdp(CharacterSlotRuntime state)
	{
		GHEG_GHubClient? client = _client;
		if (client is null)
			return;

		if (!client.TryTakeLatestCharacterPacket(
			state.SlotIndex,
			out byte[]? packet,
			out long receivedCount) ||
			packet is null)
		{
			return;
		}

		if (!state.UdpObserved)
		{
			state.UdpObserved = true;

			if (packet.Length < 5 ||
				packet[0] != (byte)'C' ||
				packet[1] != (byte)'E' ||
				packet[2] != (byte)'U')
			{
				GD.PushError(
					$"[GHEG] {state.Label} UDP packet is not CEU / " +
					$"Bytes {packet.Length} / Packets {receivedCount}");
				return;
			}

			int observedBoneCount =
				packet[3] |
				(packet[4] << 8);

			LogVerbose(
				$"[GHEG] CEU UDP observed / {state.Label} / " +
				$"Bones {observedBoneCount} / " +
				$"Bytes {packet.Length} / " +
				$"Packets {receivedCount}");
		}

		if (!state.PoseContractReady)
			return;

		ApplyCharacterPacket(
			state,
			packet);
	}

	private void DrainShapeKeyUdp(ShapeKeySlotRuntime state)
	{
		GHEG_GHubClient? client = _client;
		GHEG_ShapeKeys? receiver = state.Receiver;
		if (client is null || receiver is null)
			return;

		var updates = new Dictionary<string, float>(StringComparer.Ordinal);
		long receivedCount = 0;

		while (client.TryDequeueShapeKeyPacket(
			state.SlotIndex,
			out byte[]? packet,
			out receivedCount) &&
			packet is not null)
		{
			// Tagged GHS packets belong exclusively to SE Offline Facial Bake.
			// They are never mixed into the normal live name:value stream.
			if (packet.Length >= 3 &&
				packet[0] == (byte)'G' &&
				packet[1] == (byte)'H' &&
				packet[2] == (byte)'S')
			{
				HandleFacialBakePacket(state, packet);
				continue;
			}

			string message;
			try
			{
				message = Encoding.UTF8.GetString(packet);
			}
			catch
			{
				continue;
			}

			int separator = message.LastIndexOf(':');
			if (separator <= 0 || separator >= message.Length - 1)
				continue;

			string shapeName = message[..separator];
			string valueText = message[(separator + 1)..];

			if (!float.TryParse(
				valueText,
				NumberStyles.Float,
				CultureInfo.InvariantCulture,
				out float value))
			{
				continue;
			}

			updates[shapeName] = value;
		}

		if (updates.Count == 0)
			return;

		int applied = 0;
		foreach (KeyValuePair<string, float> update in updates)
			applied += receiver.ApplyShapeKey(update.Key, update.Value);

		if (!state.UdpObserved)
		{
			state.UdpObserved = true;
			LogVerbose(
				$"[GHEG] SE UDP observed / {state.Label} / " +
				$"Updates {updates.Count} / Applied {applied} / " +
				$"Packets {receivedCount}");
		}
	}

	private void PrepareCharacterFullRotationSet(
		CharacterSlotRuntime state,
		GHEG_Avatar avatar,
		Skeleton3D? skeleton,
		bool preserveOriginalPose = false)
	{
		state.FullRotationBoneIds.Clear();
		if (!preserveOriginalPose)
			state.OriginalPoseRotations.Clear();
		state.FullRotationLogPrinted = false;

		if (skeleton is null)
			return;

		int boneCount =
			Mathf.Min(skeleton.GetBoneCount(), 65535);

		for (int boneId = 0;
			 boneId < boneCount;
			 boneId++)
		{
			state.FullRotationBoneIds.Add(
				boneId);
		}

		LogVerbose(
			$"[GHEG] Full rotation set / {state.Label} / " +
			$"{state.FullRotationBoneIds.Count} Bone(s)");

		LogVerbose(
			"[GHEG] All Skeleton rotations are enabled. " +
			"Translation is restricted to the configured Root/Pelvis Bones.");
	}

	private void PrepareCharacterPositionSet(
		CharacterSlotRuntime state,
		GHEG_Avatar avatar,
		Skeleton3D? skeleton,
		bool preserveOriginalPose = false)
	{
		state.PositionBoneIds.Clear();
		if (!preserveOriginalPose)
			state.OriginalPosePositions.Clear();
		state.PositionLogPrinted = false;

		if (skeleton is null)
			return;

		AddCharacterPositionBone(state, skeleton, avatar.RootBone);
		AddCharacterPositionBone(state, skeleton, avatar.PelvisBone);
		AddCharacterPositionBone(state, skeleton, avatar.PelvisBone2);
		AddCharacterPositionBone(state, skeleton, avatar.PelvisBone3);

		LogVerbose(
			$"[GHEG] Translation Bone set / {state.Label} / " +
			$"{state.PositionBoneIds.Count} Bone(s)");

		foreach (int boneId in state.PositionBoneIds)
		{
			LogVerbose(
				$"[GHEG] TRANSLATION BONE / {state.Label} / " +
				$"ID {boneId} / {skeleton.GetBoneName(boneId)}");
		}

		LogVerbose(
			$"[GHEG] Position scale / {state.Label} / " +
			$"{avatar.LocalPositionScale:0.####}");
	}

	private void AddCharacterPositionBone(
		CharacterSlotRuntime state,
		Skeleton3D skeleton,
		string boneName)
	{
		if (string.IsNullOrWhiteSpace(boneName))
			return;

		int boneId = skeleton.FindBone(boneName);

		if (boneId < 0)
		{
			LogVerbose(
				$"[GHEG] TRANSLATION BONE not found / {state.Label} / " +
				$"{boneName}");
			return;
		}

		state.PositionBoneIds.Add(boneId);
	}

	private void CapturePendingSourceRestPositions(
		CharacterSlotRuntime state,
		JsonElement bones)
	{
		foreach (JsonProperty bone in bones.EnumerateObject())
		{
			if (!int.TryParse(bone.Name, out int boneId))
				continue;

			if (bone.Value.ValueKind != JsonValueKind.Object)
				continue;

			if (!bone.Value.TryGetProperty(
				"rest_pos",
				out JsonElement restPosition))
			{
				continue;
			}

			if (!TryReadVector3(restPosition, out Vector3 position))
				continue;

			state.PendingSourceRestPositions[boneId] = position;
		}
	}

	private void CapturePendingSourceRestRotations(
		CharacterSlotRuntime state,
		JsonElement bones)
	{
		foreach (JsonProperty bone in
			bones.EnumerateObject())
		{
			if (!int.TryParse(
				bone.Name,
				out int boneId))
			{
				continue;
			}

			if (bone.Value.ValueKind !=
				JsonValueKind.Object)
			{
				continue;
			}

			if (!bone.Value.TryGetProperty(
				"rest_rot",
				out JsonElement restRotation))
			{
				continue;
			}

			if (!TryReadQuaternion(
				restRotation,
				out Quaternion rotation))
			{
				continue;
			}

			state.PendingSourceRestRotations[boneId] =
				rotation;
		}
	}

	private void FinalizeCharacterPoseContract(CharacterSlotRuntime state)
	{
		state.PoseContractReady = false;

		GHEG_Avatar? avatar =
			state.Avatar;

		Skeleton3D? skeleton =
			avatar?.ResolveSkeleton();

		if (avatar is null ||
			skeleton is null)
		{
			return;
		}

		int missingReferenceCount = 0;

		foreach (int boneId in
			state.FullRotationBoneIds)
		{
			if (!state.SourceRestRotations.ContainsKey(
				boneId))
			{
				missingReferenceCount++;

				LogVerbose(
					$"[GHEG] ROTATION TEST missing Rest sample / {state.Label} / " +
					$"ID {boneId} / {skeleton.GetBoneName(boneId)}");
			}
		}

		foreach (int boneId in state.PositionBoneIds)
		{
			if (!state.SourceRestPositions.ContainsKey(boneId))
			{
				missingReferenceCount++;

				LogVerbose(
					$"[GHEG] TRANSLATION BONE missing Rest sample / {state.Label} / " +
					$"ID {boneId} / {skeleton.GetBoneName(boneId)}");
			}
		}

		if (state.FullRotationBoneIds.Count == 0 ||
			missingReferenceCount > 0)
		{
			LogVerbose(
				"[GHEG] Body pose contract not armed / " +
				"rotation or translation reference data is incomplete.");
			return;
		}

		state.PoseContractReady = true;

		LogVerbose(
			$"[GHEG] BODY CONTRACT READY / {state.Label} / " +
			$"{state.FullRotationBoneIds.Count} rotation Bone(s) / " +
			$"{state.PositionBoneIds.Count} position Bone(s)");
	}

	private void ApplyCharacterPacket(
		CharacterSlotRuntime state,
		byte[] packet)
	{
		if (packet.Length < 5 ||
			packet[0] != (byte)'C' ||
			packet[1] != (byte)'E' ||
			packet[2] != (byte)'U')
		{
			return;
		}

		GHEG_Avatar? avatar = state.Avatar;
		Skeleton3D? skeleton = avatar?.ResolveSkeleton();

		if (avatar is null ||
			skeleton is null)
		{
			return;
		}

		int boneCount = packet[3] | (packet[4] << 8);
		int offset = 5;
		int rotationApplied = 0;
		int positionApplied = 0;

		bool interpolate = avatar.BodyInterpolationEnabled;
		float interpolationWeight = interpolate
			? Mathf.Clamp(avatar.LerpSpeed / 60.0f, 0.0f, 1.0f)
			: 1.0f;

		for (int i = 0; i < boneCount; i++)
		{
			if (offset + 3 > packet.Length)
				break;

			int boneId = packet[offset] | (packet[offset + 1] << 8);
			byte flags = packet[offset + 2];
			offset += 3;

			bool hasRotation = (flags & 1) != 0;
			bool hasPosition = (flags & 2) != 0;

			Vector3 livePosition = Vector3.Zero;
			if (hasPosition)
			{
				if (offset + 12 > packet.Length)
					break;

				livePosition = new Vector3(
					ReadSingleLittleEndian(packet, offset + 0),
					ReadSingleLittleEndian(packet, offset + 4),
					ReadSingleLittleEndian(packet, offset + 8));
				offset += 12;
			}

			Quaternion liveRotation = Quaternion.Identity;
			if (hasRotation)
			{
				if (offset + 16 > packet.Length)
					break;

				liveRotation = NormalizeQuaternion(new Quaternion(
					ReadSingleLittleEndian(packet, offset + 0),
					ReadSingleLittleEndian(packet, offset + 4),
					ReadSingleLittleEndian(packet, offset + 8),
					ReadSingleLittleEndian(packet, offset + 12)));
				offset += 16;
			}

			if (boneId < 0 || boneId >= skeleton.GetBoneCount())
				continue;

			if (hasPosition)
				state.LastLivePositions[boneId] = livePosition;
			if (hasRotation)
				state.LastLiveRotations[boneId] = liveRotation;

			if (hasPosition &&
				state.PositionBoneIds.Contains(boneId) &&
				state.SourceRestPositions.TryGetValue(
					boneId, out Vector3 sourceRestPosition) &&
				state.SourceRestRotations.TryGetValue(
					boneId, out Quaternion sourceRestRotation))
			{
				if (!state.OriginalPosePositions.ContainsKey(boneId))
				{
					state.OriginalPosePositions[boneId] =
						skeleton.GetBonePosePosition(boneId);
				}

				Vector3 sourceDelta = livePosition - sourceRestPosition;

				Basis sourceRestInverse =
					new Basis(sourceRestRotation.Inverse());

				Vector3 localMotion =
					sourceRestInverse * sourceDelta;

				// Cascadeur/Godot local-position axis contract.
				// Empirical test established that the Y/Z axes reach Godot
				// swapped, with Godot forward using -Z.
				Vector3 godotMotion =
					new Vector3(
						localMotion.X,
						-localMotion.Z,
						localMotion.Y);

				Transform3D godotRest = skeleton.GetBoneRest(boneId);

				Vector3 targetPosition =
					godotRest.Origin +
					godotMotion * avatar.LocalPositionScale;

				Vector3 appliedPosition = interpolate
					? skeleton.GetBonePosePosition(boneId).Lerp(
						targetPosition,
						interpolationWeight)
					: targetPosition;

				state.LastTargetPositions[boneId] = targetPosition;
				state.LastAppliedPositions[boneId] = appliedPosition;
				skeleton.SetBonePosePosition(boneId, appliedPosition);
				positionApplied++;
			}

			if (hasRotation &&
				state.FullRotationBoneIds.Contains(boneId) &&
				state.SourceRestRotations.TryGetValue(
					boneId, out Quaternion sourceRestRotationForRotation))
			{
				if (!state.OriginalPoseRotations.ContainsKey(boneId))
				{
					state.OriginalPoseRotations[boneId] =
						skeleton.GetBonePoseRotation(boneId);
				}

				Transform3D godotRest = skeleton.GetBoneRest(boneId);
				Quaternion godotRestRotation = NormalizeQuaternion(
					new Quaternion(godotRest.Basis.Orthonormalized()));

				Quaternion motionDelta =
					sourceRestRotationForRotation.Inverse() * liveRotation;

				Quaternion targetRotation = NormalizeQuaternion(
					godotRestRotation * motionDelta);

				Quaternion appliedRotation = interpolate
					? NormalizeQuaternion(
						skeleton.GetBonePoseRotation(boneId).Slerp(
							targetRotation,
							interpolationWeight))
					: targetRotation;

				state.LastTargetRotations[boneId] = targetRotation;
				state.LastAppliedRotations[boneId] = appliedRotation;
				skeleton.SetBonePoseRotation(boneId, appliedRotation);
				rotationApplied++;
			}
		}

		if (rotationApplied > 0 && !state.FullRotationLogPrinted)
		{
			state.FullRotationLogPrinted = true;
			LogVerbose(
				$"[GHEG] ROTATION LIVE / {state.Label} / " +
				$"Applied {rotationApplied} Bone rotation(s)");
		}

		if (positionApplied > 0 && !state.PositionLogPrinted)
		{
			state.PositionLogPrinted = true;
			LogVerbose(
				$"[GHEG] TRANSLATION LIVE / {state.Label} / " +
				$"Applied {positionApplied} configured Bone position(s)");
			LogVerbose(
				"[GHEG] Position contract: GodotRest.Origin + " +
				"AxisMap(X, Z, -Y) * CascadeurRestRotation^-1 * " +
				"(CascadeurLivePos - CascadeurRestPos) * scale");
		}
	}

	private void RestoreCharacterPose(CharacterSlotRuntime state)
	{
		GHEG_Avatar? avatar = state.Avatar;
		Skeleton3D? skeleton = avatar?.ResolveSkeleton();

		if (skeleton is null)
			return;

		foreach (KeyValuePair<int, Quaternion> original
			in state.OriginalPoseRotations)
		{
			if (original.Key < 0 || original.Key >= skeleton.GetBoneCount())
				continue;
			skeleton.SetBonePoseRotation(original.Key, original.Value);
		}

		foreach (KeyValuePair<int, Vector3> original
			in state.OriginalPosePositions)
		{
			if (original.Key < 0 || original.Key >= skeleton.GetBoneCount())
				continue;
			skeleton.SetBonePosePosition(original.Key, original.Value);
		}

		if (state.OriginalPoseRotations.Count > 0 ||
			state.OriginalPosePositions.Count > 0)
		{
			LogVerbose(
				$"[GHEG] Body pose restored / {state.Label} / " +
				$"{state.OriginalPoseRotations.Count} rotation(s) / " +
				$"{state.OriginalPosePositions.Count} position(s)");
		}
	}
	private static bool TryReadVector3(
		JsonElement array,
		out Vector3 vector)
	{
		vector = Vector3.Zero;

		if (array.ValueKind != JsonValueKind.Array ||
			array.GetArrayLength() != 3)
		{
			return false;
		}

		float[] values = new float[3];
		int index = 0;

		foreach (JsonElement value in array.EnumerateArray())
		{
			if (value.ValueKind != JsonValueKind.Number)
				return false;

			values[index++] = (float)value.GetDouble();
		}

		vector = new Vector3(values[0], values[1], values[2]);
		return true;
	}

	private static bool TryReadQuaternion(
		JsonElement array,
		out Quaternion quaternion)
	{
		quaternion = Quaternion.Identity;

		if (array.ValueKind !=
			JsonValueKind.Array ||
			array.GetArrayLength() != 4)
		{
			return false;
		}

		float[] values =
			new float[4];

		int index = 0;

		foreach (JsonElement value in
			array.EnumerateArray())
		{
			if (value.ValueKind !=
				JsonValueKind.Number)
			{
				return false;
			}

			values[index++] =
				(float)value.GetDouble();
		}

		quaternion =
			NormalizeQuaternion(
				new Quaternion(
					values[0],
					values[1],
					values[2],
					values[3]));

		return true;
	}

	private static Quaternion NormalizeQuaternion(
		Quaternion quaternion)
	{
		float lengthSquared =
			quaternion.X * quaternion.X +
			quaternion.Y * quaternion.Y +
			quaternion.Z * quaternion.Z +
			quaternion.W * quaternion.W;

		if (lengthSquared <= 1e-12f)
			return Quaternion.Identity;

		return quaternion.Normalized();
	}

	private static float ReadSingleLittleEndian(
		byte[] data,
		int offset)
	{
		int bits =
			data[offset] |
			(data[offset + 1] << 8) |
			(data[offset + 2] << 16) |
			(data[offset + 3] << 24);

		return BitConverter.Int32BitsToSingle(
			bits);
	}

	private static double ReadDouble(
		JsonElement root,
		string propertyName)
	{
		if (!root.TryGetProperty(
			propertyName,
			out JsonElement value))
		{
			return 0.0;
		}

		if (value.ValueKind == JsonValueKind.Number &&
			value.TryGetDouble(out double result))
		{
			return result;
		}

		if (value.ValueKind == JsonValueKind.String &&
			double.TryParse(
				value.GetString(),
				out result))
		{
			return result;
		}

		return 0.0;
	}

	private static bool ReadBool(
		JsonElement root,
		string propertyName)
	{
		if (!root.TryGetProperty(
			propertyName,
			out JsonElement value))
		{
			return false;
		}

		if (value.ValueKind == JsonValueKind.True)
			return true;

		if (value.ValueKind == JsonValueKind.False)
			return false;

		if (value.ValueKind == JsonValueKind.String &&
			bool.TryParse(
				value.GetString(),
				out bool result))
		{
			return result;
		}

		return false;
	}

	private static int ReadInt(
		JsonElement root,
		string propertyName)
	{
		if (!root.TryGetProperty(
			propertyName,
			out JsonElement value))
		{
			return 0;
		}

		if (value.ValueKind ==
			JsonValueKind.Number &&
			value.TryGetInt32(out int result))
		{
			return result;
		}

		if (value.ValueKind ==
			JsonValueKind.String &&
			int.TryParse(
				value.GetString(),
				out result))
		{
			return result;
		}

		return 0;
	}

	private static long ReadLong(
		JsonElement root,
		string propertyName)
	{
		if (!root.TryGetProperty(
			propertyName,
			out JsonElement value))
		{
			return 0L;
		}

		if (value.ValueKind ==
			JsonValueKind.Number &&
			value.TryGetInt64(out long result))
		{
			return result;
		}

		if (value.ValueKind ==
			JsonValueKind.String &&
			long.TryParse(
				value.GetString(),
				out result))
		{
			return result;
		}

		return 0L;
	}

	private static string ReadString(
		JsonElement root,
		string propertyName)
	{
		if (!root.TryGetProperty(
			propertyName,
			out JsonElement value))
		{
			return "";
		}

		return value.ValueKind ==
			JsonValueKind.String
			? value.GetString() ?? ""
			: value.ToString();
	}
}
