import json
import queue
import socket
import threading

from . import GHEB_Protocol as protocol


class GHubClient:
    """Socket-only G-HUB client. Never touches bpy from worker threads."""

    def __init__(self, host=protocol.HUB_HOST, port=protocol.HUB_PORT):
        self.host = host
        self.port = int(port)

        self.endpoint_id = 0
        self.session_id = 0

        self._tcp_socket = None
        self._tcp_thread = None

        # Each receiver channel owns an independent non-blocking UDP socket.
        self._udp_sockets = {}
        self._udp_ports = {}

        self._stop_event = threading.Event()
        self._send_lock = threading.Lock()
        self._udp_lock = threading.Lock()
        self._events = queue.Queue()

    @property
    def udp_port(self):
        # Character C1 receiver accessor.
        return self.get_udp_port("character")

    def get_udp_port(self, key):
        with self._udp_lock:
            return int(self._udp_ports.get(str(key), 0))

    @property
    def tcp_alive(self):
        thread = self._tcp_thread
        return thread is not None and thread.is_alive()

    def configure(self, host=None, port=None):
        """Update the G-HUB control endpoint before connecting."""
        if self.tcp_alive:
            raise RuntimeError(
                "Cannot change the G-HUB endpoint while connected."
            )

        if host is not None:
            self.host = str(host)
        if port is not None:
            value = int(port)
            if value < 1 or value > 65535:
                raise ValueError("Control Port must be between 1 and 65535.")
            self.port = value

    def connect(self):
        if self.tcp_alive:
            return

        self._stop_event.clear()
        self._tcp_thread = threading.Thread(
            target=self._tcp_worker,
            name="GHEB-GHub-Control",
            daemon=True,
        )
        self._tcp_thread.start()

    def disconnect(self):
        self._stop_event.set()

        sock = self._tcp_socket
        self._tcp_socket = None
        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass
            try:
                sock.close()
            except Exception:
                pass

        self.close_udp()
        self.endpoint_id = 0
        self.session_id = 0

    def send(self, message):
        sock = self._tcp_socket
        if sock is None:
            return False

        try:
            raw = (
                json.dumps(message, separators=(",", ":"), ensure_ascii=False)
                + "\n"
            ).encode("utf-8")
            with self._send_lock:
                sock.sendall(raw)
            return True
        except Exception as exc:
            self._events.put(("error", f"Control send failed: {exc}"))
            return False

    def bind_udp(self, port, key="character"):
        key = str(key)
        self.close_udp(key)

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.bind(("127.0.0.1", int(port)))
            sock.setblocking(False)
        except Exception:
            try:
                sock.close()
            except Exception:
                pass
            raise

        with self._udp_lock:
            self._udp_sockets[key] = sock
            self._udp_ports[key] = int(port)

    def close_udp(self, key=None):
        if key is None:
            with self._udp_lock:
                items = list(self._udp_sockets.items())
                self._udp_sockets.clear()
                self._udp_ports.clear()
            for _, sock in items:
                try:
                    sock.close()
                except Exception:
                    pass
            return

        key = str(key)
        with self._udp_lock:
            sock = self._udp_sockets.pop(key, None)
            self._udp_ports.pop(key, None)
        if sock is not None:
            try:
                sock.close()
            except Exception:
                pass

    def drain_udp_packets(self, key="character", max_packets=128):
        key = str(key)
        with self._udp_lock:
            sock = self._udp_sockets.get(key)

        if sock is None:
            return []

        packets = []
        while len(packets) < max_packets:
            try:
                data, _ = sock.recvfrom(65535)
                packets.append(data)
            except BlockingIOError:
                break
            except OSError:
                break
            except Exception as exc:
                self._events.put(("error", f"UDP receive failed ({key}): {exc}"))
                break

        return packets

    def drain_udp(self, max_packets=128, key="character"):
        packets = self.drain_udp_packets(key=key, max_packets=max_packets)
        return len(packets), (packets[-1] if packets else None)

    def poll_events(self, max_events=128):
        result = []
        for _ in range(max_events):
            try:
                result.append(self._events.get_nowait())
            except queue.Empty:
                break
        return result

    def _tcp_worker(self):
        sock = None
        try:
            self._events.put(("status", "CONNECTING"))
            sock = socket.create_connection((self.host, self.port), timeout=2.0)
            sock.settimeout(0.25)
            self._tcp_socket = sock

            self._events.put(("status", "WAITING FOR ASSIGN"))
            if not self.send(protocol.hello_message()):
                raise RuntimeError("HELLO send failed")

            buffer = bytearray()
            while not self._stop_event.is_set():
                try:
                    chunk = sock.recv(8192)
                    if not chunk:
                        break
                    buffer.extend(chunk)
                except socket.timeout:
                    continue

                while b"\n" in buffer:
                    line, _, remainder = buffer.partition(b"\n")
                    buffer = bytearray(remainder)
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        message = json.loads(line.decode("utf-8"))
                        self._events.put(("message", message))
                    except Exception as exc:
                        self._events.put(("error", f"Invalid G-HUB JSON: {exc}"))

        except Exception as exc:
            if not self._stop_event.is_set():
                self._events.put(("error", f"G-HUB connection failed: {exc}"))
        finally:
            if self._tcp_socket is sock:
                self._tcp_socket = None
            if sock is not None:
                try:
                    sock.close()
                except Exception:
                    pass
            self._events.put(("disconnected", None))
