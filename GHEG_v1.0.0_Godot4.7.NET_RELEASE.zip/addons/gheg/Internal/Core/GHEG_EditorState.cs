#nullable enable annotations
using System;

namespace GHEG.Internal.Core;

internal static class GHEG_EditorState
{
    private static bool _pluginEnabled;
    private static bool _runtimeHandoffActive;

    internal static bool PluginEnabled => _pluginEnabled;
    internal static bool RuntimeHandoffActive => _runtimeHandoffActive;

    internal static event Action<bool>? PluginEnabledChanged;
    internal static event Action<bool>? RuntimeHandoffChanged;

    internal static void SetPluginEnabled(bool enabled)
    {
        if (_pluginEnabled == enabled)
            return;

        _pluginEnabled = enabled;
        PluginEnabledChanged?.Invoke(enabled);
    }

    internal static void SetRuntimeHandoff(bool active)
    {
        if (_runtimeHandoffActive == active)
            return;

        _runtimeHandoffActive = active;
        RuntimeHandoffChanged?.Invoke(active);
    }

    internal static void ResetForAssemblyReload()
    {
        _pluginEnabled = false;
        _runtimeHandoffActive = false;
        PluginEnabledChanged = null;
        RuntimeHandoffChanged = null;
    }
}

