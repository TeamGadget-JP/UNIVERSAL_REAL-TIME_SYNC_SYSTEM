#nullable enable annotations
using System;
using System.Collections.Generic;
using Godot;

/// <summary>
/// Per-character ShapeMixer / BlendShape adapter for GHEG.
///
/// Add one GHEG_ShapeKeys node below the same character wrapper that owns the
/// GHEG_Avatar. Use GHEG Control > AUTO ASSIGN to populate Avatar and TargetRoot
/// after the character node structure is complete.
///
/// ShapeMixer sends weights as 0..100 percentages. Godot MeshInstance3D blend
/// shape values are driven as normalized 0..1 values.
/// </summary>
[Tool]
[GlobalClass]
public partial class GHEG_ShapeKeys : Node
{
    [ExportGroup("Shape Sync")]
    [Export]
    public bool Active { get; set; } = true;

    [Export]
    public GHEG_Avatar? Avatar { get; set; }

    [Export]
    public Node? TargetRoot { get; set; }

    private sealed class ShapeBinding
    {
        internal MeshInstance3D Mesh = null!;
        internal int BlendShapeIndex;
        internal string BlendShapeName = "";
    }

    internal sealed class BakeBinding
    {
        internal string PacketShapeName = "";
        internal MeshInstance3D Mesh = null!;
        internal int BlendShapeIndex;
        internal string BlendShapeName = "";
        internal NodePath TrackPath;
    }

    private readonly Dictionary<string, List<ShapeBinding>> _bindings =
        new(StringComparer.Ordinal);
    private readonly List<ShapeBinding> _concreteBindings = new();

    private ulong _cachedRootId;
    private int _cachedMeshCount;
    private int _cachedConcreteCount;

    internal int CachedAliasCount => _bindings.Count;
    internal int CachedMeshCount => _cachedMeshCount;
    internal int CachedConcreteCount => _cachedConcreteCount;

    internal GHEG_Avatar? ResolveAvatar()
    {
        return Avatar is not null && GodotObject.IsInstanceValid(Avatar)
            ? Avatar
            : null;
    }

    internal Node? ResolveTargetRoot()
    {
        return TargetRoot is not null && GodotObject.IsInstanceValid(TargetRoot)
            ? TargetRoot
            : null;
    }

    internal bool TryResolveSlotIndex(out int slotIndex, out string error)
    {
        slotIndex = -1;
        error = "";

        if (!Active)
        {
            error = "Shape Sync is disabled.";
            return false;
        }

        GHEG_Avatar? avatar = ResolveAvatar();
        if (avatar is null)
        {
            error =
                "GHEG_Avatar is not assigned. Run AUTO ASSIGN for this Character Slot.";
            return false;
        }

        slotIndex = (int)avatar.Slot;
        if (slotIndex < 0 || slotIndex >= 5)
        {
            error = $"Invalid Character Slot {slotIndex + 1}.";
            slotIndex = -1;
            return false;
        }

        return true;
    }

    internal bool PrepareForSession(out string error)
    {
        error = "";

        if (!TryResolveSlotIndex(out int slotIndex, out error))
            return false;

        Node? root = ResolveTargetRoot();
        if (root is null)
        {
            error = "Shape Sync Target Root could not be resolved.";
            return false;
        }

        int aliases = RebuildCache();
        if (_cachedConcreteCount <= 0 || aliases <= 0)
        {
            error =
                $"C{slotIndex + 1}: no BlendShapes were found below '{root.Name}'.";
            return false;
        }

        ; // verbose cache summary suppressed in release logging

        return true;
    }

    internal int RebuildCache()
    {
        _bindings.Clear();
        _concreteBindings.Clear();
        _cachedMeshCount = 0;
        _cachedConcreteCount = 0;

        Node? root = ResolveTargetRoot();
        if (root is null)
        {
            _cachedRootId = 0;
            return 0;
        }

        _cachedRootId = root.GetInstanceId();
        ScanNodeRecursive(root);
        return _bindings.Count;
    }

    internal int ApplyShapeKey(string shapeName, float percentWeight)
    {
        if (!Active || string.IsNullOrWhiteSpace(shapeName))
            return 0;

        EnsureCache();

        if (!_bindings.TryGetValue(shapeName, out List<ShapeBinding>? list))
            return 0;

        float value = Mathf.Clamp(percentWeight / 100.0f, 0.0f, 1.0f);
        int applied = 0;

        foreach (ShapeBinding binding in list)
        {
            if (!GodotObject.IsInstanceValid(binding.Mesh))
                continue;

            int count = binding.Mesh.GetBlendShapeCount();
            if (binding.BlendShapeIndex < 0 || binding.BlendShapeIndex >= count)
                continue;

            float current = binding.Mesh.GetBlendShapeValue(binding.BlendShapeIndex);
            if (Mathf.Abs(current - value) <= 0.0001f)
                continue;

            binding.Mesh.SetBlendShapeValue(binding.BlendShapeIndex, value);
            applied++;
        }

        return applied;
    }


    internal List<BakeBinding> GetBakeBindingsForPacketNames(
        IEnumerable<string> packetShapeNames,
        Node animationRoot)
    {
        var result = new List<BakeBinding>();
        if (animationRoot is null || !GodotObject.IsInstanceValid(animationRoot))
            return result;

        EnsureCache();

        var used = new HashSet<string>(StringComparer.Ordinal);

        foreach (string packetName in packetShapeNames)
        {
            if (string.IsNullOrWhiteSpace(packetName))
                continue;

            List<ShapeBinding>? list = null;
            if (!_bindings.TryGetValue(packetName, out list))
            {
                foreach (char separator in new[] { '.', ':', '/' })
                {
                    int suffixIndex = packetName.LastIndexOf(separator);
                    if (suffixIndex < 0 || suffixIndex >= packetName.Length - 1)
                        continue;

                    string suffix = packetName[(suffixIndex + 1)..];
                    if (_bindings.TryGetValue(suffix, out list))
                        break;
                }
            }

            if (list is null)
                continue;

            foreach (ShapeBinding binding in list)
            {
                if (!GodotObject.IsInstanceValid(binding.Mesh))
                    continue;

                string uniqueKey =
                    $"{binding.Mesh.GetInstanceId()}:{binding.BlendShapeIndex}";
                if (!used.Add(uniqueKey))
                    continue;

                NodePath meshPath = animationRoot.GetPathTo(binding.Mesh);
                string meshPathText = meshPath.ToString();
                string trackPathText =
                    string.IsNullOrWhiteSpace(meshPathText) ||
                    string.Equals(meshPathText, ".", StringComparison.Ordinal)
                        ? $".:{binding.BlendShapeName}"
                        : $"{meshPathText}:{binding.BlendShapeName}";

                result.Add(new BakeBinding
                {
                    PacketShapeName = packetName,
                    Mesh = binding.Mesh,
                    BlendShapeIndex = binding.BlendShapeIndex,
                    BlendShapeName = binding.BlendShapeName,
                    TrackPath = new NodePath(trackPathText),
                });
            }
        }

        return result;
    }

    public void ResetAllBlendShapes()
    {
        EnsureCache();

        foreach (ShapeBinding binding in _concreteBindings)
        {
            if (!GodotObject.IsInstanceValid(binding.Mesh))
                continue;

            int count = binding.Mesh.GetBlendShapeCount();
            if (binding.BlendShapeIndex < 0 || binding.BlendShapeIndex >= count)
                continue;

            binding.Mesh.SetBlendShapeValue(binding.BlendShapeIndex, 0.0f);
        }
    }

    private void EnsureCache()
    {
        Node? root = ResolveTargetRoot();
        ulong rootId = root?.GetInstanceId() ?? 0;

        if (_bindings.Count == 0 || rootId == 0 || rootId != _cachedRootId)
            RebuildCache();
    }

    private void ScanNodeRecursive(Node node)
    {
        if (node is MeshInstance3D meshNode &&
            meshNode.Mesh is ArrayMesh arrayMesh)
        {
            int blendShapeCount = meshNode.GetBlendShapeCount();
            if (blendShapeCount > 0)
            {
                _cachedMeshCount++;

                for (int index = 0; index < blendShapeCount; index++)
                {
                    string rawName = arrayMesh.GetBlendShapeName(index).ToString();
                    if (string.IsNullOrWhiteSpace(rawName))
                        continue;

                    var binding = new ShapeBinding
                    {
                        Mesh = meshNode,
                        BlendShapeIndex = index,
                        BlendShapeName = rawName,
                    };

                    _concreteBindings.Add(binding);
                    _cachedConcreteCount++;

                    AddAlias(rawName, binding);
                    AddSuffixAlias(rawName, '.', binding);
                    AddSuffixAlias(rawName, ':', binding);
                    AddSuffixAlias(rawName, '/', binding);
                }
            }
        }

        foreach (Node child in node.GetChildren())
            ScanNodeRecursive(child);
    }

    private void AddAlias(string alias, ShapeBinding binding)
    {
        if (string.IsNullOrWhiteSpace(alias))
            return;

        if (!_bindings.TryGetValue(alias, out List<ShapeBinding>? list))
        {
            list = new List<ShapeBinding>();
            _bindings.Add(alias, list);
        }

        foreach (ShapeBinding existing in list)
        {
            if (ReferenceEquals(existing.Mesh, binding.Mesh) &&
                existing.BlendShapeIndex == binding.BlendShapeIndex)
            {
                return;
            }
        }

        list.Add(binding);
    }

    private void AddSuffixAlias(
        string rawName,
        char separator,
        ShapeBinding binding)
    {
        int index = rawName.LastIndexOf(separator);
        if (index < 0 || index >= rawName.Length - 1)
            return;

        AddAlias(rawName[(index + 1)..], binding);
    }

}
