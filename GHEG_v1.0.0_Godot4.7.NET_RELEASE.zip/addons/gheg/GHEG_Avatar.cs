#nullable enable annotations
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Godot;

/// <summary>
/// Public per-character configuration component for GHEG.
/// Bone mapping is resolved from the assigned Skeleton3D and remains
/// rig-agnostic; runtime synchronization is owned by GHEG_System.
/// </summary>
[Tool]
[GlobalClass]
public partial class GHEG_Avatar : Node3D
{
	public enum CharacterSlot
	{
		C1 = 0,
		C2 = 1,
		C3 = 2,
		C4 = 3,
		C5 = 4,
	}

	public enum SmartSwizzleCacheState
	{
		Missing = 0,
		Ready = 1,
		Stale = 2,
	}

	private sealed class SmartSwizzleCacheDocument
	{
		public int Schema { get; set; }
		public string Signature { get; set; } = "";
		public List<SmartSwizzleCacheBone> Bones { get; set; } = new();
	}

	private sealed class SmartSwizzleCacheBone
	{
		public int BoneId { get; set; }
		public string RequestName { get; set; } = "";

		public bool HasRestPosition { get; set; }
		public float RestPositionX { get; set; }
		public float RestPositionY { get; set; }
		public float RestPositionZ { get; set; }

		public bool HasRestRotation { get; set; }
		public float RestRotationX { get; set; }
		public float RestRotationY { get; set; }
		public float RestRotationZ { get; set; }
		public float RestRotationW { get; set; }
	}

	private const int SmartSwizzleCacheSchema = 1;

	[ExportGroup("Character")]
	[Export]
	public bool Active { get; set; } = true;

	[Export]
	public CharacterSlot Slot { get; set; } = CharacterSlot.C1;

	private Skeleton3D? _skeleton;

	[Export]
	public Skeleton3D? Skeleton
	{
		get => _skeleton;
		set
		{
			if (_skeleton == value)
				return;

			_skeleton = value;

			if (Engine.IsEditorHint())
				NotifyPropertyListChanged();
		}
	}

	[ExportGroup("Body")]
	[Export]
	public string RootBone { get; set; } = "CC_Base_BoneRoot";

	// PelvisBone keeps its original serialized property name for backward
	// compatibility with existing scenes. The custom Inspector presents it
	// as "Pelvis 1".
	[Export]
	public string PelvisBone { get; set; } = "CC_Base_Hip";

	[Export]
	public string PelvisBone2 { get; set; } = "";

	[Export]
	public string PelvisBone3 { get; set; } = "";

	[ExportSubgroup("Interpolation")]
	[Export]
	public bool BodyInterpolationEnabled { get; set; } = false;

	// Numeric input only. Runtime value remains hard-clamped to 1..60.
	private float _lerpSpeed = 60.0f;

	[Export]
	public float LerpSpeed
	{
		get => _lerpSpeed;
		set => _lerpSpeed = Mathf.Clamp(value, 1.0f, 60.0f);
	}

	// Serialized setup-time Smart Swizzle reference cache. The custom Inspector
	// hides this raw payload and exposes only status/apply/delete controls.
	[Export]
	public string SmartSwizzleCacheData { get; set; } = "";

	[ExportGroup("FBX Bridge")]
	[Export]
	public string FbxBridgeOutputFolder { get; set; } = "";

	[Export]
	public string FbxBridgeAssetName { get; set; } = "";

	[ExportGroup("Timeline")]
	[Export]
	public AnimationPlayer? TimelinePlayer { get; set; }

	[Export]
	public bool TimelineSyncEnabled { get; set; } = true;

	[ExportGroup("Advanced")]
	private float _localPositionScale = 0.01f;

	[Export]
	public float LocalPositionScale
	{
		get => _localPositionScale;
		set => _localPositionScale = Mathf.Clamp(value, 0.0001f, 1.0f);
	}

	public SmartSwizzleCacheState CurrentSmartSwizzleCacheState
	{
		get => GetSmartSwizzleCacheState(out _);
	}
	public string EffectiveFbxBridgeOutputFolder
	{
		get
		{
			string configured = (FbxBridgeOutputFolder ?? "").Trim();
			if (string.IsNullOrWhiteSpace(configured))
			{
				return "res://";
			}

			configured = configured.Replace('\\', '/');
			if (string.Equals(configured, "res://", StringComparison.OrdinalIgnoreCase))
				return "res://";
			return configured.TrimEnd('/');
		}
	}

	public string EffectiveFbxBridgeAssetName
	{
		get
		{
			string configured = (FbxBridgeAssetName ?? "").Trim();
			return string.IsNullOrWhiteSpace(configured)
				? $"Character{(int)Slot + 1}"
				: configured;
		}
	}

	internal void SetFbxBridgeOutputFolderFromEditor(string value)
	{
		FbxBridgeOutputFolder = value?.Trim() ?? "";
		MarkEditorConfigurationChanged();
	}

	internal void SetFbxBridgeAssetNameFromEditor(string value)
	{
		FbxBridgeAssetName = value?.Trim() ?? "";
		MarkEditorConfigurationChanged();
	}


	public string SmartSwizzleCacheStatus
	{
		get
		{
			SmartSwizzleCacheState state =
				GetSmartSwizzleCacheState(out int boneCount);

			return state switch
			{
				SmartSwizzleCacheState.Ready =>
					$"Ready ({boneCount} bones)",
				SmartSwizzleCacheState.Stale => "Stale",
				_ => "Missing",
			};
		}
	}

	internal bool TryBuildRequestBones(
		out Dictionary<string, string> requestBones,
		out string error)
	{
		requestBones = new Dictionary<string, string>();
		error = "";

		if (!Active)
		{
			error = "Avatar is disabled.";
			return false;
		}


		Skeleton3D? skeleton = ResolveSkeleton();
		if (skeleton is null)
		{
			error =
				"No Skeleton3D was assigned or found below this GHEG_Avatar.";
			return false;
		}

		int boneCount = skeleton.GetBoneCount();
		if (boneCount <= 0)
		{
			error = "Skeleton3D contains no bones.";
			return false;
		}

		int limitedCount = Mathf.Min(boneCount, 65535);
		for (int boneIndex = 0; boneIndex < limitedCount; boneIndex++)
		{
			string boneName =
				skeleton.GetBoneName(boneIndex).ToString();

			if (string.IsNullOrWhiteSpace(boneName))
				continue;

			requestBones[boneIndex.ToString()] = boneName;
		}

		if (requestBones.Count == 0)
		{
			error = "No valid Bone names were found.";
			return false;
		}

		return true;
	}

	/// <summary>
	/// Restores the assigned Skeleton3D to its imported rest pose.
	/// Live Body synchronization may overwrite the pose again on the next packet.
	/// </summary>
	public bool ResetPoseToSkeletonRest(out string error)
	{
		error = "";

		Skeleton3D? skeleton = ResolveSkeleton();
		if (skeleton is null)
		{
			error =
				"No Skeleton3D was assigned or found below this GHEG_Avatar.";
			return false;
		}

		if (skeleton.GetBoneCount() <= 0)
		{
			error = "Skeleton3D contains no bones.";
			return false;
		}

		skeleton.ResetBonePoses();

		GD.Print(
			$"[GHEG] Reset Pose / {Name} / " +
			$"Skeleton {skeleton.Name} / " +
			$"Bones {skeleton.GetBoneCount()}");

		return true;
	}

	public bool DeleteSmartSwizzleCache()
	{
		if (string.IsNullOrWhiteSpace(SmartSwizzleCacheData))
			return false;

		SmartSwizzleCacheData = "";
		MarkSmartSwizzleCacheChanged();

		GD.Print(
			$"[GHEG] Smart Swizzle cache deleted / {Name}");

		return true;
	}

	internal SmartSwizzleCacheState GetSmartSwizzleCacheState(
		out int cachedBoneCount)
	{
		cachedBoneCount = 0;

		if (string.IsNullOrWhiteSpace(SmartSwizzleCacheData))
			return SmartSwizzleCacheState.Missing;

		if (!TryRestoreSmartSwizzleCache(
			out _,
			out _,
			out _,
			out cachedBoneCount,
			out _))
		{
			return SmartSwizzleCacheState.Stale;
		}

		return SmartSwizzleCacheState.Ready;
	}

	internal bool TryRestoreSmartSwizzleCache(
		out Dictionary<string, string> requestBones,
		out Dictionary<int, Quaternion> restRotations,
		out Dictionary<int, Vector3> restPositions,
		out int cachedBoneCount,
		out string error)
	{
		requestBones = new Dictionary<string, string>();
		restRotations = new Dictionary<int, Quaternion>();
		restPositions = new Dictionary<int, Vector3>();
		cachedBoneCount = 0;
		error = "";

		Skeleton3D? skeleton = ResolveSkeleton();
		if (skeleton is null)
		{
			error = "Skeleton3D is unavailable.";
			return false;
		}

		if (!TryReadSmartSwizzleCache(
			out SmartSwizzleCacheDocument? cache,
			out error) ||
			cache is null)
		{
			return false;
		}

		if (cache.Schema != SmartSwizzleCacheSchema)
		{
			error = "Cache schema does not match this GHEG version.";
			return false;
		}

		string currentSignature =
			BuildSmartSwizzleSignature(skeleton);

		if (!string.Equals(
			cache.Signature,
			currentSignature,
			StringComparison.Ordinal))
		{
			error = "Character contract changed since the cache was created.";
			return false;
		}

		int expectedBoneCount =
			Mathf.Min(skeleton.GetBoneCount(), 65535);

		if (cache.Bones is null ||
			cache.Bones.Count != expectedBoneCount)
		{
			error = "Cached Bone count does not match the current Skeleton3D.";
			return false;
		}

		var seenBoneIds = new HashSet<int>();

		foreach (SmartSwizzleCacheBone bone in cache.Bones)
		{
			if (bone is null ||
				bone.BoneId < 0 ||
				bone.BoneId >= expectedBoneCount ||
				!seenBoneIds.Add(bone.BoneId) ||
				string.IsNullOrWhiteSpace(bone.RequestName) ||
				!bone.HasRestRotation)
			{
				error = "Cached Smart Swizzle Bone data is incomplete.";
				return false;
			}

			requestBones[bone.BoneId.ToString()] =
				bone.RequestName;

			restRotations[bone.BoneId] =
				NormalizeQuaternion(new Quaternion(
					bone.RestRotationX,
					bone.RestRotationY,
					bone.RestRotationZ,
					bone.RestRotationW));

			if (bone.HasRestPosition)
			{
				restPositions[bone.BoneId] =
					new Vector3(
						bone.RestPositionX,
						bone.RestPositionY,
						bone.RestPositionZ);
			}
		}

		if (requestBones.Count != expectedBoneCount ||
			restRotations.Count != expectedBoneCount)
		{
			error = "Cached Smart Swizzle contract is incomplete.";
			return false;
		}

		foreach (int boneId in GetConfiguredPositionBoneIds(skeleton))
		{
			if (restPositions.ContainsKey(boneId))
				continue;

			error =
				$"Cached Smart Swizzle position reference is missing at Bone ID {boneId}.";
			return false;
		}

		cachedBoneCount = requestBones.Count;
		return true;
	}

	internal bool StoreSmartSwizzleCache(
		IReadOnlyDictionary<string, string> requestBones,
		IReadOnlyDictionary<int, Quaternion> restRotations,
		IReadOnlyDictionary<int, Vector3> restPositions,
		out string error)
	{
		error = "";

		Skeleton3D? skeleton = ResolveSkeleton();
		if (skeleton is null)
		{
			error = "Skeleton3D is unavailable.";
			return false;
		}

		int expectedBoneCount =
			Mathf.Min(skeleton.GetBoneCount(), 65535);

		if (requestBones.Count != expectedBoneCount)
		{
			error = "Request Bone count does not match the current Skeleton3D.";
			return false;
		}

		var cache = new SmartSwizzleCacheDocument
		{
			Schema = SmartSwizzleCacheSchema,
			Signature = BuildSmartSwizzleSignature(skeleton),
			Bones = new List<SmartSwizzleCacheBone>(expectedBoneCount),
		};

		for (int boneId = 0; boneId < expectedBoneCount; boneId++)
		{
			string key = boneId.ToString();

			if (!requestBones.TryGetValue(
				key,
				out string? requestName) ||
				string.IsNullOrWhiteSpace(requestName) ||
				!restRotations.TryGetValue(
					boneId,
					out Quaternion restRotation))
			{
				error =
					$"Smart Swizzle reference is incomplete at Bone ID {boneId}.";
				return false;
			}

			var cacheBone = new SmartSwizzleCacheBone
			{
				BoneId = boneId,
				RequestName = requestName,
				HasRestRotation = true,
				RestRotationX = restRotation.X,
				RestRotationY = restRotation.Y,
				RestRotationZ = restRotation.Z,
				RestRotationW = restRotation.W,
			};

			if (restPositions.TryGetValue(
				boneId,
				out Vector3 restPosition))
			{
				cacheBone.HasRestPosition = true;
				cacheBone.RestPositionX = restPosition.X;
				cacheBone.RestPositionY = restPosition.Y;
				cacheBone.RestPositionZ = restPosition.Z;
			}

			cache.Bones.Add(cacheBone);
		}

		SmartSwizzleCacheData =
			JsonSerializer.Serialize(cache);

		MarkSmartSwizzleCacheChanged();

		GD.Print(
			$"[GHEG] Smart Swizzle cache saved / {Name} / " +
			$"Bones {cache.Bones.Count}");

		return true;
	}

	internal Skeleton3D? ResolveSkeleton()
	{
		if (Skeleton is not null &&
			GodotObject.IsInstanceValid(Skeleton))
		{
			return Skeleton;
		}

		return FindSkeletonRecursive(this);
	}

	internal AnimationPlayer? ResolveTimelinePlayer()
	{
		if (!TimelineSyncEnabled)
			return null;

		if (TimelinePlayer is not null &&
			GodotObject.IsInstanceValid(TimelinePlayer))
		{
			return TimelinePlayer;
		}

		// Imported character scenes commonly place AnimationPlayer beside the
		// character root. Prefer that sibling before falling back to descendants.
		Node? parent = GetParent();
		if (parent is not null)
		{
			foreach (Node child in parent.GetChildren())
			{
				if (child is AnimationPlayer siblingPlayer)
					return siblingPlayer;
			}
		}

		return FindAnimationPlayerRecursive(this);
	}

	private bool TryReadSmartSwizzleCache(
		out SmartSwizzleCacheDocument? cache,
		out string error)
	{
		cache = null;
		error = "";

		if (string.IsNullOrWhiteSpace(SmartSwizzleCacheData))
		{
			error = "No Smart Swizzle cache is stored.";
			return false;
		}

		try
		{
			cache = JsonSerializer.Deserialize<SmartSwizzleCacheDocument>(
				SmartSwizzleCacheData);

			if (cache is null)
			{
				error = "Smart Swizzle cache could not be decoded.";
				return false;
			}

			return true;
		}
		catch (Exception ex)
		{
			error = "Smart Swizzle cache is invalid: " + ex.Message;
			return false;
		}
	}

	private HashSet<int> GetConfiguredPositionBoneIds(
		Skeleton3D skeleton)
	{
		var result = new HashSet<int>();

		AddConfiguredPositionBoneId(
			skeleton,
			RootBone,
			result);
		AddConfiguredPositionBoneId(
			skeleton,
			PelvisBone,
			result);
		AddConfiguredPositionBoneId(
			skeleton,
			PelvisBone2,
			result);
		AddConfiguredPositionBoneId(
			skeleton,
			PelvisBone3,
			result);

		return result;
	}

	private static void AddConfiguredPositionBoneId(
		Skeleton3D skeleton,
		string boneName,
		HashSet<int> result)
	{
		if (string.IsNullOrWhiteSpace(boneName))
			return;

		int boneId = skeleton.FindBone(boneName);
		if (boneId >= 0 && boneId < 65535)
			result.Add(boneId);
	}

	private string BuildSmartSwizzleSignature(
		Skeleton3D skeleton)
	{
		var builder = new StringBuilder();
		builder.Append("GHEG_SS_")
			.Append(SmartSwizzleCacheSchema);
		builder.Append("|slot=").Append((int)Slot);
		builder.Append("|root=").Append(RootBone ?? "");
		builder.Append("|pelvis1=").Append(PelvisBone ?? "");
		builder.Append("|pelvis2=").Append(PelvisBone2 ?? "");
		builder.Append("|pelvis3=").Append(PelvisBone3 ?? "");

		int limitedCount =
			Mathf.Min(skeleton.GetBoneCount(), 65535);

		builder.Append("|bones=").Append(limitedCount);

		for (int boneId = 0; boneId < limitedCount; boneId++)
		{
			builder.Append('|').Append(boneId);
			builder.Append(':')
				.Append(skeleton.GetBoneName(boneId));
			builder.Append(":p")
				.Append(skeleton.GetBoneParent(boneId));
		}

		byte[] hash =
			SHA256.HashData(
				Encoding.UTF8.GetBytes(
					builder.ToString()));

		return Convert.ToHexString(hash);
	}

	private void MarkSmartSwizzleCacheChanged()
	{
		MarkEditorConfigurationChanged();
	}

	private void MarkEditorConfigurationChanged()
	{
		if (!Engine.IsEditorHint())
			return;

		NotifyPropertyListChanged();

#if TOOLS
		EditorInterface.Singleton?.MarkSceneAsUnsaved();
#endif
	}

	private static Quaternion NormalizeQuaternion(
		Quaternion value)
	{
		float lengthSquared = value.LengthSquared();
		if (lengthSquared <= 0.0000001f)
			return Quaternion.Identity;

		return value.Normalized();
	}

	private static Skeleton3D? FindSkeletonRecursive(Node node)
	{
		foreach (Node child in node.GetChildren())
		{
			if (child is Skeleton3D skeleton)
				return skeleton;

			Skeleton3D? nested =
				FindSkeletonRecursive(child);

			if (nested is not null)
				return nested;
		}

		return null;
	}

	private static AnimationPlayer? FindAnimationPlayerRecursive(Node node)
	{
		foreach (Node child in node.GetChildren())
		{
			if (child is AnimationPlayer player)
				return player;

			AnimationPlayer? nested =
				FindAnimationPlayerRecursive(child);

			if (nested is not null)
				return nested;
		}

		return null;
	}
}
