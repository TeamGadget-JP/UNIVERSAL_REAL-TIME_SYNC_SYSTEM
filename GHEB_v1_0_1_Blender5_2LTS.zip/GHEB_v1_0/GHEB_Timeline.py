import math
import struct
import time

import bpy
import mathutils
from bpy.app.handlers import persistent


_TIME_EPSILON = 1.0e-5
_TICK_INTERVAL = 0.05  # 20 Hz canonical playback publish, same as GHEU.
_SCRUB_PUBLISH_INTERVAL = 1.0 / 30.0


class _TimelineRuntime:
    def __init__(self):
        self.initialized = False
        self.remote_applying = False
        self.canonical_owner = False

        self.last_observed_time = 0.0
        self.last_observed_playing = False
        self.last_applied_revision = -1
        self.next_tick_at = 0.0
        self.next_scrub_publish_at = 0.0
        self.last_scrubbing = False

        # Coalesce remote canonical states per Blender timer tick.
        # Only the highest-revision state is applied to Scene evaluation.
        self.pending_remote_state = None
        self.remote_playback_follow = False

        self.last_sync_enable = True

        self.owner_endpoint_id = 0
        self.owner_session_id = 0
        self.owner_label = "None"

        # Shared endpoint controller used by Blender playback event handlers.
        # Transport edges must be published from the actual Blender event, not
        # inferred only from the 60 Hz polling timer.
        self.controller = None

    def reset(self, scene=None):
        self.initialized = False
        self.remote_applying = False
        self.canonical_owner = False
        self.last_applied_revision = -1
        self.next_tick_at = 0.0
        self.next_scrub_publish_at = 0.0
        self.last_scrubbing = False
        self.pending_remote_state = None
        self.remote_playback_follow = False
        self.owner_endpoint_id = 0
        self.owner_session_id = 0
        self.owner_label = "None"
        self.controller = None

        if scene is not None and hasattr(scene, "gheb_timeline"):
            props = scene.gheb_timeline
            self.last_sync_enable = bool(props.sync_enable)


_runtime = _TimelineRuntime()

# ---------------------------------------------------------------------------
# Offline Bake
# ---------------------------------------------------------------------------

_BAKE_READY_TIMEOUT = 3.0
_BAKE_FRAME_TIMEOUT = 1.5
_BAKE_MAX_FRAME_RETRIES = 3
_BAKE_ZERO_EPSILON = 1.0e-6


class _BakeRuntime:
    def __init__(self):
        self.reset()

    def reset(self):
        self.active = False
        self.controller = None
        self.bake_id = 0
        self.include_character = False
        self.include_shape = False
        self.selected_slot = -1
        self.character_route_id = 0
        self.shape_route_id = 0
        self.character_ready = False
        self.shape_ready = False
        self.character_fps = 0.0
        self.shape_fps = 0.0
        self.dest_fps = 0.0
        self.start_frame = 0
        self.end_frame = 0
        self.current_frame = 0
        self.completed_frames = 0
        self.waiting_for_frame = False
        self.character_frame_received = False
        self.shape_frame_received = False
        self.expected_character_frame = None
        self.expected_shape_frame = None
        self.begin_sent_at = 0.0
        self.frame_request_sent_at = 0.0
        self.next_request_at = 0.0
        self.retry_count = 0
        self.status = "Idle"
        self.character_samples = {}
        self.shape_samples = {}
        self.previous_quaternions = {}
        self.created_actions = []

        # Facial-only bake processes active Face Slots sequentially.
        # Body and Body + Facial remain single-Character operations.
        self.multi_face_batch = False
        self.face_batch_slots = []
        self.face_batch_index = 0
        self.batch_created_actions = []

    @property
    def total_frames(self):
        return max(0, self.end_frame - self.start_frame + 1)

    @property
    def overall_total_frames(self):
        if self.multi_face_batch and self.face_batch_slots:
            return self.total_frames * len(self.face_batch_slots)
        return self.total_frames

    @property
    def overall_completed_frames(self):
        if self.multi_face_batch and self.face_batch_slots:
            completed_before = self.face_batch_index * self.total_frames
            return completed_before + self.completed_frames
        return self.completed_frames

    @property
    def face_batch_label(self):
        if not self.multi_face_batch or not self.face_batch_slots:
            return ""
        return (
            f"{self.face_batch_index + 1}/{len(self.face_batch_slots)} "
            f"| C{self.selected_slot + 1}"
        )

    @property
    def source_label(self):
        if self.include_character and self.include_shape:
            return "Body + Facial"
        if self.include_character:
            return "Body"
        if self.include_shape:
            return "Facial"
        return "No Sources"


_bake = _BakeRuntime()


def is_baking():
    return bool(_bake.active)


def bake_uses_character():
    return bool(_bake.active and _bake.include_character)


def bake_uses_shape():
    return bool(_bake.active and _bake.include_shape)


def _new_bake_id():
    value = int(time.time_ns() & 0x7FFFFFFF)
    return value if value > 0 else 1


def _selected_bake_slot(scene):
    timeline_props = getattr(scene, "gheb_timeline", None)
    if timeline_props is None:
        return None

    try:
        index = int(timeline_props.bake_slot)
    except Exception:
        return None

    if index < 0 or index >= 5:
        return None
    return index


def _bake_mode_flags(scene):
    props = getattr(scene, "gheb_timeline", None)
    mode = str(getattr(props, "bake_mode", "BODY") or "BODY").upper()
    if mode == "FACE":
        return False, True
    if mode == "BOTH":
        return True, True
    return True, False


def _character_bake_binding_count(controller, slot_index):
    if controller is None or slot_index is None:
        return 0
    bindings = controller.get_character_bone_bindings(slot_index)
    swizzles = controller.get_character_swizzle_offsets(slot_index)
    return sum(1 for b_id in bindings if b_id in swizzles)


def _collect_active_face_bake_slots(controller, scene):
    """Validate and return all active Facial Slots in C1 -> C5 order."""
    from . import GHEB_ShapeKeys

    if not getattr(controller, "shape_enabled", False):
        return [], ["Shape sync is not active"]

    valid = []
    invalid = []

    for slot_index in range(5):
        shape_slot = GHEB_ShapeKeys.get_shape_slot(scene, slot_index)
        if shape_slot is None or not shape_slot.is_active:
            continue

        target = GHEB_ShapeKeys.get_shape_target(scene, slot_index)
        route_id = int(controller.get_shape_route_id(slot_index))
        udp_port = int(controller.get_shape_udp_port(slot_index))

        ready = (
            target is not None
            and target.type == 'MESH'
            and target.data.shape_keys is not None
            and route_id > 0
            and udp_port > 0
        )

        if ready:
            valid.append(slot_index)
        else:
            invalid.append(f"C{slot_index + 1}")

    return valid, invalid


def _begin_current_face_batch(controller, scene):
    """Start one ShapeMixer Offline Bake transaction for the current batch Slot."""
    if (
        not _bake.multi_face_batch
        or not _bake.face_batch_slots
        or _bake.face_batch_index < 0
        or _bake.face_batch_index >= len(_bake.face_batch_slots)
    ):
        return False, "Invalid Facial batch state."

    from . import GHEB_ShapeKeys

    slot_index = int(_bake.face_batch_slots[_bake.face_batch_index])
    shape_slot = GHEB_ShapeKeys.get_shape_slot(scene, slot_index)
    target = GHEB_ShapeKeys.get_shape_target(scene, slot_index)
    shape_route_id = int(controller.get_shape_route_id(slot_index))
    shape_udp_port = int(controller.get_shape_udp_port(slot_index))

    if (
        not getattr(controller, "shape_enabled", False)
        or shape_slot is None
        or not shape_slot.is_active
        or shape_route_id <= 0
        or shape_udp_port <= 0
        or target is None
        or target.type != 'MESH'
        or target.data.shape_keys is None
    ):
        return False, f"Facial C{slot_index + 1} is no longer ready for Offline Bake."

    # Reset only the per-transaction state. Preserve the overall batch queue,
    # frame range, destination FPS, and Actions already completed.
    _bake.bake_id = _new_bake_id()
    _bake.include_character = False
    _bake.include_shape = True
    _bake.selected_slot = slot_index
    _bake.character_route_id = 0
    _bake.shape_route_id = shape_route_id
    _bake.character_ready = True
    _bake.shape_ready = False
    _bake.character_fps = 0.0
    _bake.shape_fps = 0.0
    _bake.current_frame = _bake.start_frame
    _bake.completed_frames = 0
    _bake.waiting_for_frame = False
    _bake.character_frame_received = True
    _bake.shape_frame_received = False
    _bake.expected_character_frame = None
    _bake.expected_shape_frame = None
    _bake.begin_sent_at = time.monotonic()
    _bake.frame_request_sent_at = 0.0
    _bake.next_request_at = 0.0
    _bake.retry_count = 0
    _bake.character_samples = {}
    _bake.shape_samples = {}
    _bake.previous_quaternions = {}
    _bake.created_actions = []
    _bake.status = f"Waiting for ShapeMixer | {_bake.face_batch_label}"

    begin_payload = {
        "command": "BAKE_BEGIN",
        "bake_id": _bake.bake_id,
        "start": _bake.start_frame,
        "end": _bake.end_frame,
        "fps": _bake.dest_fps,
        "timebase": "seconds_v1",
    }

    if not controller.client.send(
        _relay_message(_bake.shape_route_id, begin_payload)
    ):
        return False, f"Failed to send BAKE_BEGIN to Facial C{slot_index + 1}."

    print(
        f"[GHEB Bake] FACIAL BATCH START / "
        f"{_bake.face_batch_index + 1}/{len(_bake.face_batch_slots)} / "
        f"Slot {slot_index} / ID {_bake.bake_id} / "
        f"{_bake.start_frame}->{_bake.end_frame} @ {_bake.dest_fps:g} fps"
    )
    return True, ""


def start_offline_bake(controller, scene):
    if _bake.active:
        return False, "Another Offline Bake is already running."
    if controller is None or not getattr(controller, "running", False):
        return False, "G-HUB endpoint is not connected."

    props = scene.gheb_timeline
    start_frame = int(props.bake_start)
    end_frame = int(props.bake_end)
    if end_frame < start_frame:
        return False, "Bake End must be greater than or equal to Bake Start."

    wants_character, wants_shape = _bake_mode_flags(scene)

    # --------------------------------------------------------
    # Facial-only mode bakes every active Face Slot sequentially (C1 -> C5).
    # --------------------------------------------------------
    if wants_shape and not wants_character:
        face_slots, invalid_slots = _collect_active_face_bake_slots(
            controller, scene
        )

        if invalid_slots:
            return (
                False,
                "Active Facial Slot(s) are not ready: "
                + ", ".join(invalid_slots),
            )
        if not face_slots:
            return False, "No active Facial Slot is ready for Offline Bake."

        _bake.reset()
        _bake.active = True
        _bake.controller = controller
        _bake.include_character = False
        _bake.include_shape = True
        _bake.dest_fps = _fps(scene)
        _bake.start_frame = start_frame
        _bake.end_frame = end_frame
        _bake.multi_face_batch = True
        _bake.face_batch_slots = list(face_slots)
        _bake.face_batch_index = 0
        _bake.batch_created_actions = []

        props.is_baking = True

        # Offline Bake owns neither Blender playback nor Virtual Timeline.
        _runtime.remote_applying = True
        try:
            if _is_animation_playing():
                _pause_animation_playback()
        finally:
            _runtime.remote_applying = False

        if (
            getattr(controller, "timeline_enabled", False)
            and controller.client.endpoint_id
        ):
            controller.client.send(_release_message())
        _runtime.canonical_owner = False

        ok, reason = _begin_current_face_batch(controller, scene)
        if not ok:
            _abort_bake_local(scene, reason)
            return False, reason

        print(
            f"[GHEB Bake] MULTI-FACIAL START / "
            f"{len(face_slots)} active Slot(s) / "
            f"{start_frame}->{end_frame} @ {_bake.dest_fps:g} fps"
        )
        return True, ""

    # --------------------------------------------------------
    # Existing Body / Body+Facial single-Slot path.
    # --------------------------------------------------------
    selected_slot = _selected_bake_slot(scene)
    if selected_slot is None:
        return False, "Select a valid Character Slot."

    character_route_id = 0
    shape_route_id = 0

    if wants_character:
        scene_props = getattr(scene, "gheb_props", None)
        body_slot = None
        if scene_props is not None and 0 <= selected_slot < len(scene_props.slots):
            body_slot = scene_props.slots[selected_slot]
        if body_slot is None or not body_slot.is_active or body_slot.target_armature is None:
            return False, "Body Bake requires an active Body target on the selected Character Slot."

        character_route_id = int(controller.get_character_route_id(selected_slot))
        if (
            not getattr(controller, "avatar_enabled", False)
            or character_route_id <= 0
            or int(controller.get_character_udp_port(selected_slot)) <= 0
        ):
            return False, "Selected Character Slot requires an active Body route."

        if _character_bake_binding_count(controller, selected_slot) <= 0:
            return False, "No Smart Swizzle bindings are ready for the selected Character Slot."

    if wants_shape:
        from . import GHEB_ShapeKeys

        shape_slot = GHEB_ShapeKeys.get_shape_slot(scene, selected_slot)
        target = GHEB_ShapeKeys.get_shape_target(scene, selected_slot)
        shape_route_id = int(controller.get_shape_route_id(selected_slot))
        if (
            not getattr(controller, "shape_enabled", False)
            or shape_slot is None
            or not shape_slot.is_active
            or shape_route_id <= 0
            or int(controller.get_shape_udp_port(selected_slot)) <= 0
            or target is None
            or target.type != 'MESH'
            or target.data.shape_keys is None
        ):
            return False, "Facial Bake requires an active Shape route and valid target on the selected Character Slot."

    _bake.reset()
    _bake.active = True
    _bake.controller = controller
    _bake.bake_id = _new_bake_id()
    _bake.include_character = wants_character
    _bake.include_shape = wants_shape
    _bake.selected_slot = selected_slot
    _bake.character_route_id = character_route_id
    _bake.shape_route_id = shape_route_id
    _bake.dest_fps = _fps(scene)
    _bake.start_frame = start_frame
    _bake.end_frame = end_frame
    _bake.current_frame = start_frame
    _bake.character_ready = not wants_character
    _bake.shape_ready = not wants_shape
    _bake.character_frame_received = not wants_character
    _bake.shape_frame_received = not wants_shape
    _bake.status = f"Waiting for {_bake.source_label}"
    _bake.begin_sent_at = time.monotonic()

    props.is_baking = True

    _runtime.remote_applying = True
    try:
        if _is_animation_playing():
            _pause_animation_playback()
    finally:
        _runtime.remote_applying = False

    if getattr(controller, "timeline_enabled", False) and controller.client.endpoint_id:
        controller.client.send(_release_message())
    _runtime.canonical_owner = False

    begin_payload = {
        "command": "BAKE_BEGIN",
        "bake_id": _bake.bake_id,
        "start": start_frame,
        "end": end_frame,
        "fps": _bake.dest_fps,
        "timebase": "seconds_v1",
    }

    sent_routes = []
    if wants_character:
        if not controller.client.send(
            _relay_message(_bake.character_route_id, begin_payload)
        ):
            _abort_bake_local(scene, "Failed to send BAKE_BEGIN to Cascadeur.")
            return False, "Failed to send BAKE_BEGIN to Cascadeur."
        sent_routes.append(_bake.character_route_id)

    if wants_shape:
        if not controller.client.send(
            _relay_message(_bake.shape_route_id, begin_payload)
        ):
            for route_id in sent_routes:
                controller.client.send(
                    _relay_message(
                        route_id,
                        {"command": "BAKE_CANCEL", "bake_id": _bake.bake_id},
                    )
                )
            _abort_bake_local(scene, "Failed to send BAKE_BEGIN to ShapeMixer.")
            return False, "Failed to send BAKE_BEGIN to ShapeMixer."

    print(
        f"[GHEB Bake] START / ID {_bake.bake_id} / "
        f"{start_frame}->{end_frame} @ {_bake.dest_fps:g} fps / {_bake.source_label}"
    )
    return True, ""


def cancel_offline_bake(controller=None, reason="Cancelled by user.", send_cancel=True):
    if not _bake.active:
        return False

    scene = _get_scene()
    controller = controller or _bake.controller
    bake_id = _bake.bake_id

    if send_cancel and controller is not None:
        payload = {"command": "BAKE_CANCEL", "bake_id": bake_id}
        if _bake.include_character and _bake.character_route_id > 0:
            controller.client.send(_relay_message(_bake.character_route_id, payload))
        if _bake.include_shape and int(_bake.shape_route_id) > 0:
            controller.client.send(_relay_message(_bake.shape_route_id, payload))

    print(f"[GHEB Bake] CANCEL / ID {bake_id} / {reason}")
    _abort_bake_local(scene, reason)
    return True


def _abort_bake_local(scene, reason):
    controller = _bake.controller
    if scene is not None and hasattr(scene, "gheb_timeline"):
        scene.gheb_timeline.is_baking = False

    _bake.status = f"Aborted: {reason}"
    _bake.active = False

    if (
        controller is not None
        and getattr(controller, "running", False)
        and getattr(controller, "timeline_enabled", False)
        and controller.client.endpoint_id
    ):
        controller.client.send(_sync_request_message())
        _establish_baseline(scene, keep_toggle_state=True)


def on_endpoint_lost_during_bake(reason="G-HUB endpoint disconnected."):
    if not _bake.active:
        return
    scene = _get_scene()
    print(f"[GHEB Bake] ABORT / {reason}")
    _abort_bake_local(scene, reason)


def handle_bake_route_removed(route_id, controller):
    if not _bake.active:
        return False

    route_id = int(route_id)
    lost_character = _bake.include_character and route_id == int(_bake.character_route_id)
    lost_shape = _bake.include_shape and route_id == int(_bake.shape_route_id)
    if not lost_character and not lost_shape:
        return False

    source = "Cascadeur" if lost_character else "ShapeMixer"
    cancel_offline_bake(
        controller,
        reason=f"{source} route was removed during bake.",
        send_cancel=True,
    )
    return True


def handle_bake_relay(route_id, payload, controller):
    if not _bake.active or not isinstance(payload, dict):
        return False

    command = str(payload.get("command", ""))
    if command not in ("BAKE_READY", "BAKE_ERROR"):
        return False

    try:
        incoming_id = int(payload.get("bake_id", 0))
    except Exception:
        return True
    if incoming_id != _bake.bake_id:
        return True

    route_id = int(route_id)
    from_character = _bake.include_character and route_id == int(_bake.character_route_id)
    from_shape = _bake.include_shape and route_id == int(_bake.shape_route_id)
    if not from_character and not from_shape:
        return False

    if command == "BAKE_ERROR":
        source = "Cascadeur" if from_character else "ShapeMixer"
        detail = str(payload.get("reason", "Bake adapter reported an error."))
        cancel_offline_bake(controller, f"{source}: {detail}", send_cancel=True)
        return True

    # BAKE_READY may report the source FPS. Keep a 30 fps fallback for
    # sources do this so mixed-FPS bake can request a canonical time while the
    # binary GHB/GHS packet still identifies the actual sampled source frame.
    try:
        source_fps = float(payload.get("source_fps", 0.0) or 0.0)
    except Exception:
        source_fps = 0.0
    if source_fps <= 0.0:
        source_fps = _bake.dest_fps

    if from_character:
        _bake.character_ready = True
        _bake.character_fps = source_fps
    if from_shape:
        _bake.shape_ready = True
        _bake.shape_fps = source_fps

    if _bake.character_ready and _bake.shape_ready:
        if _bake.multi_face_batch:
            _bake.status = f"Baking Facial | {_bake.face_batch_label}"
        else:
            _bake.status = f"Baking {_bake.source_label}"
        _bake.waiting_for_frame = False
        _bake.retry_count = 0
        _bake.next_request_at = time.monotonic()
        print(
            f"[GHEB Bake] READY / ID {_bake.bake_id} / "
            f"Cascadeur FPS {_bake.character_fps:g} / Shape FPS {_bake.shape_fps:g}"
        )
    else:
        _bake.status = "Waiting for Cascadeur" if not _bake.character_ready else "Waiting for ShapeMixer"

    return True


def _tick_bake(controller, scene):
    if not _bake.active:
        return

    now = time.monotonic()
    if not (_bake.character_ready and _bake.shape_ready):
        if now - _bake.begin_sent_at > _BAKE_READY_TIMEOUT:
            missing = "Cascadeur" if not _bake.character_ready else "ShapeMixer"
            cancel_offline_bake(
                controller,
                f"{missing} did not acknowledge BAKE_BEGIN.",
                send_cancel=True,
            )
        return

    if _bake.waiting_for_frame:
        if now - _bake.frame_request_sent_at <= _BAKE_FRAME_TIMEOUT:
            return

        if _bake.retry_count >= _BAKE_MAX_FRAME_RETRIES:
            cancel_offline_bake(
                controller,
                f"Frame {_bake.current_frame} timed out after {_BAKE_MAX_FRAME_RETRIES} retries.",
                send_cancel=True,
            )
            return

        _bake.retry_count += 1
        _send_current_bake_frame_request(controller)
        return

    if now >= _bake.next_request_at:
        _send_current_bake_frame_request(controller)


def _send_current_bake_frame_request(controller):
    frame = int(_bake.current_frame)
    seconds = float(frame) / _bake.dest_fps

    _bake.character_frame_received = not _bake.include_character
    _bake.shape_frame_received = not _bake.include_shape
    _bake.expected_character_frame = (
        int(round(seconds * _bake.character_fps))
        if _bake.include_character else None
    )
    _bake.expected_shape_frame = (
        int(round(seconds * _bake.shape_fps))
        if _bake.include_shape else None
    )

    payload = {
        "command": "BAKE_FRAME_REQUEST",
        "bake_id": _bake.bake_id,
        "frame": frame,
        "time_seconds": seconds,
    }

    if _bake.include_character:
        if not controller.client.send(_relay_message(_bake.character_route_id, payload)):
            cancel_offline_bake(controller, "Character route send failed during bake.")
            return

    if _bake.include_shape:
        if not controller.client.send(_relay_message(_bake.shape_route_id, payload)):
            cancel_offline_bake(controller, "Shape route send failed during bake.")
            return

    _bake.waiting_for_frame = True
    _bake.frame_request_sent_at = time.monotonic()
    if _bake.multi_face_batch:
        _bake.status = (
            f"Baking Facial | {_bake.face_batch_label} | "
            f"Frame {_bake.current_frame}/{_bake.end_frame}"
        )
    else:
        _bake.status = (
            f"Baking {_bake.current_frame} / {_bake.end_frame} "
            f"({_bake.source_label})"
        )


def handle_bake_character_packet(data, controller, slot_index):
    if not _bake.active or not _bake.include_character:
        return False
    if int(slot_index) != int(_bake.selected_slot):
        return False
    if not data or len(data) < 13 or data[:3] != b"GHB":
        return False

    try:
        packet_bake_id, source_frame, bone_count = struct.unpack_from('<iiH', data, 3)
    except Exception:
        return True

    if packet_bake_id != _bake.bake_id:
        return True
    if not _bake.waiting_for_frame:
        return True
    if _bake.expected_character_frame is not None and source_frame != _bake.expected_character_frame:
        return True

    offset = 13
    dest_frame = int(_bake.current_frame)

    try:
        for _ in range(int(bone_count)):
            if offset + 3 > len(data):
                raise ValueError("GHB bone header truncated")

            b_id, flags = struct.unpack_from('<HB', data, offset)
            offset += 3
            has_pos = bool(flags & 2)
            has_rot = bool(flags & 1)

            pos = None
            rot = None
            if has_pos:
                if offset + 12 > len(data):
                    raise ValueError("GHB position truncated")
                pos = mathutils.Vector(struct.unpack_from('<3f', data, offset))
                offset += 12
            if has_rot:
                if offset + 16 > len(data):
                    raise ValueError("GHB rotation truncated")
                x, y, z, w = struct.unpack_from('<4f', data, offset)
                rot = mathutils.Quaternion((w, x, y, z))
                offset += 16

            bindings = controller.get_character_bone_bindings(_bake.selected_slot)
            swizzles = controller.get_character_swizzle_offsets(_bake.selected_slot)
            binding = bindings.get(int(b_id))
            if binding is None:
                continue

            swizzle = swizzles.get(int(b_id))
            if swizzle is None:
                continue

            sample = _bake.character_samples.setdefault(
                int(b_id), {"rot": [], "loc": []}
            )

            if rot is not None:
                q = swizzle @ rot
                try:
                    q.normalize()
                except Exception:
                    pass

                previous = _bake.previous_quaternions.get(int(b_id))
                if previous is not None and previous.dot(q) < 0.0:
                    q = mathutils.Quaternion((-q.w, -q.x, -q.y, -q.z))
                _bake.previous_quaternions[int(b_id)] = q.copy()
                sample["rot"].append((dest_frame, (q.w, q.x, q.y, q.z)))

            if pos is not None and controller._is_location_bone(_bake.selected_slot, int(b_id)):
                rest_pos = controller.get_character_rest_positions(_bake.selected_slot).get(int(b_id))
                if rest_pos is not None:
                    loc = (
                        swizzle @ (pos - rest_pos)
                    ) * controller.get_character_translation_scale(_bake.selected_slot)
                    sample["loc"].append((dest_frame, (loc.x, loc.y, loc.z)))

    except Exception as exc:
        cancel_offline_bake(controller, f"Invalid GHB packet: {exc}")
        return True

    _bake.character_frame_received = True
    _try_complete_bake_frame(controller)
    return True


def handle_bake_shape_packet(data, controller, slot_index):
    if not _bake.active or not _bake.include_shape:
        return False
    if int(slot_index) != int(_bake.selected_slot):
        return False
    if not data or len(data) < 13 or data[:3] != b"GHS":
        return False

    try:
        packet_bake_id, source_frame, shape_count = struct.unpack_from('<iiH', data, 3)
    except Exception:
        return True

    if packet_bake_id != _bake.bake_id:
        return True
    if not _bake.waiting_for_frame:
        return True
    if _bake.expected_shape_frame is not None and source_frame != _bake.expected_shape_frame:
        return True

    scene = _get_scene()
    if scene is None:
        cancel_offline_bake(controller, "Blender Scene disappeared during Shape bake.")
        return True

    offset = 13
    dest_frame = int(_bake.current_frame)

    try:
        from . import GHEB_ShapeKeys

        for _ in range(int(shape_count)):
            if offset + 2 > len(data):
                raise ValueError("GHS name length truncated")
            name_len = struct.unpack_from('<H', data, offset)[0]
            offset += 2

            if name_len <= 0 or offset + name_len + 4 > len(data):
                raise ValueError("GHS shape payload truncated")

            shape_name = data[offset:offset + name_len].decode("utf-8")
            offset += name_len
            weight = struct.unpack_from('<f', data, offset)[0]
            offset += 4

            # Keep samples by the incoming ShapeMixer name. One incoming
            # name may resolve to matching Shape Keys on several meshes.
            if not GHEB_ShapeKeys.has_shape_binding(
                scene, shape_name, _bake.selected_slot
            ):
                continue

            value = max(0.0, min(1.0, float(weight) / 100.0))
            _bake.shape_samples.setdefault(str(shape_name), []).append(
                (dest_frame, value)
            )

    except Exception as exc:
        cancel_offline_bake(controller, f"Invalid GHS packet: {exc}")
        return True

    _bake.shape_frame_received = True
    _try_complete_bake_frame(controller)
    return True


def _try_complete_bake_frame(controller):
    if not _bake.active or not _bake.waiting_for_frame:
        return
    if not (_bake.character_frame_received and _bake.shape_frame_received):
        return

    _bake.waiting_for_frame = False
    _bake.retry_count = 0
    _bake.completed_frames += 1

    if _bake.current_frame >= _bake.end_frame:
        _finish_offline_bake(controller)
        return

    _bake.current_frame += 1
    scene = _get_scene()
    delay = 0.0
    if scene is not None and hasattr(scene, "gheb_timeline"):
        delay = max(0.0, float(scene.gheb_timeline.bake_delay))
    _bake.next_request_at = time.monotonic() + delay


def _finish_offline_bake(controller):
    scene = _get_scene()
    bake_id = _bake.bake_id
    payload = {"command": "BAKE_END", "bake_id": bake_id}

    if _bake.include_character and _bake.character_route_id > 0:
        controller.client.send(_relay_message(_bake.character_route_id, payload))
    if _bake.include_shape and int(_bake.shape_route_id) > 0:
        controller.client.send(_relay_message(_bake.shape_route_id, payload))

    _bake.status = "Writing Blender Actions"

    try:
        created = _write_bake_actions(scene, controller)
        _bake.created_actions = created

        # Preserve the completed Facial Action, then continue with the next
        # active Face Slot without leaving Offline Bake mode.
        if _bake.multi_face_batch:
            _bake.batch_created_actions.extend(created)

            print(
                f"[GHEB Bake] FACIAL SLOT COMPLETE / "
                f"{_bake.face_batch_index + 1}/{len(_bake.face_batch_slots)} / "
                f"Slot {_bake.selected_slot} / "
                f"{_bake.completed_frames} frames / "
                f"Actions: {', '.join(created) if created else 'none'}"
            )

            if _bake.face_batch_index + 1 < len(_bake.face_batch_slots):
                _bake.face_batch_index += 1
                ok, reason = _begin_current_face_batch(controller, scene)
                if not ok:
                    raise RuntimeError(reason)
                return

            _bake.created_actions = list(_bake.batch_created_actions)
            _bake.status = (
                f"Complete: {len(_bake.face_batch_slots)} Facial Slot(s) / "
                f"{_bake.overall_completed_frames} frames"
            )
            print(
                f"[GHEB Bake] MULTI-FACIAL COMPLETE / "
                f"{len(_bake.face_batch_slots)} Slot(s) / "
                f"Actions: "
                f"{', '.join(_bake.batch_created_actions) if _bake.batch_created_actions else 'none'}"
            )
        else:
            _bake.status = (
                f"Complete: {_bake.completed_frames} frames / {_bake.source_label}"
            )
            print(
                f"[GHEB Bake] COMPLETE / ID {bake_id} / "
                f"{_bake.completed_frames} frames / "
                f"Actions: {', '.join(created) if created else 'none'}"
            )

    except Exception as exc:
        _bake.status = f"Write failed: {exc}"
        print(f"[GHEB Bake] Action write failed: {exc}")

    # If another Facial batch was started above, execution returned already.
    _bake.active = False
    if scene is not None and hasattr(scene, "gheb_timeline"):
        scene.gheb_timeline.is_baking = False

    if (
        getattr(controller, "running", False)
        and getattr(controller, "timeline_enabled", False)
        and controller.client.endpoint_id
    ):
        controller.client.send(_sync_request_message())
        _establish_baseline(scene, keep_toggle_state=True)

    # One evaluation after the complete batch is enough.
    if scene is not None:
        try:
            scene.frame_set(scene.frame_current)
        except Exception:
            pass


def _write_bake_actions(scene, controller):
    if scene is None:
        raise RuntimeError("No active Blender Scene.")

    created_actions = []
    assignments = []
    by_armature = {}

    def _assign_action(datablock, action):
        anim_data = datablock.animation_data_create()
        previous = anim_data.action
        anim_data.action = action
        assignments.append((anim_data, previous, action))
        if action not in created_actions:
            created_actions.append(action)
        return anim_data

    try:
        if _bake.include_character:
            if not _bake.character_samples:
                raise RuntimeError("Body Bake received no usable bone samples.")

            body_action_count_before = len(created_actions)
            bindings = controller.get_character_bone_bindings(_bake.selected_slot)
            for b_id, channels in _bake.character_samples.items():
                binding = bindings.get(int(b_id))
                if binding is None:
                    continue
                armature_name, bone_name = binding

                armature = bpy.data.objects.get(armature_name)
                if armature is None or armature.type != 'ARMATURE':
                    continue
                pb = armature.pose.bones.get(bone_name)
                if pb is None:
                    continue

                arm_data = by_armature.get(armature_name)
                if arm_data is None:
                    action = bpy.data.actions.new(
                        name=(
                            f"GHEB_Body_{armature.name}_"
                            f"{_bake.start_frame}_{_bake.end_frame}"
                        )
                    )
                    _assign_action(armature, action)
                    arm_data = (armature, action)
                    by_armature[armature_name] = arm_data

                    try:
                        action.frame_range = (
                            float(_bake.start_frame),
                            float(_bake.end_frame),
                        )
                    except Exception:
                        pass

                _armature, action = arm_data
                pb.rotation_mode = 'QUATERNION'

                rot_samples = channels.get("rot", [])
                if rot_samples:
                    path = pb.path_from_id("rotation_quaternion")
                    for component in range(4):
                        values = [
                            (frame, value[component])
                            for frame, value in rot_samples
                        ]
                        _write_fcurve(
                            action,
                            armature,
                            path,
                            component,
                            values,
                            bone_name,
                        )

                loc_samples = channels.get("loc", [])
                if loc_samples:
                    path = pb.path_from_id("location")
                    for component in range(3):
                        values = [
                            (frame, value[component])
                            for frame, value in loc_samples
                        ]
                        _write_fcurve(
                            action,
                            armature,
                            path,
                            component,
                            values,
                            bone_name,
                        )

            if len(created_actions) <= body_action_count_before:
                raise RuntimeError("Body Bake produced no writable Armature Action.")

        if _bake.include_shape:
            if not _bake.shape_samples:
                raise RuntimeError(
                    "Facial Bake received no matching Shape Key samples."
                )

            from . import GHEB_ShapeKeys

            anchor = GHEB_ShapeKeys.get_shape_target(
                scene, _bake.selected_slot
            )
            if (
                anchor is None
                or anchor.type != 'MESH'
                or anchor.data.shape_keys is None
            ):
                raise RuntimeError(
                    "Facial target disappeared before Action write."
                )

            # Blender 5.2 layered Actions can own multiple Action Slots.
            # Create one logical Facial Action for this Character Slot, then
            # assign it to every concrete Shape Key datablock that receives at
            # least one incoming SE Shape. fcurve_ensure_for_datablock() below
            # writes each curve into the correct Action Slot.
            action = bpy.data.actions.new(
                name=(
                    f"GHEB_Face_{anchor.name}_"
                    f"{_bake.start_frame}_{_bake.end_frame}"
                )
            )

            try:
                action.frame_range = (
                    float(_bake.start_frame),
                    float(_bake.end_frame),
                )
            except Exception:
                pass

            # key_data pointer -> {
            #     "key_data": Key datablock,
            #     "object_name": representative Mesh name,
            #     "curves": { concrete_key_name: samples }
            # }
            by_key_data = {}

            for incoming_name, samples in _bake.shape_samples.items():
                if not samples:
                    continue

                bindings = GHEB_ShapeKeys.resolve_shape_bindings(
                    scene,
                    incoming_name,
                    _bake.selected_slot,
                )

                for obj, key_data, kb in bindings:
                    try:
                        data_key = int(key_data.as_pointer())
                    except Exception:
                        data_key = id(key_data)

                    entry = by_key_data.get(data_key)
                    if entry is None:
                        entry = {
                            "key_data": key_data,
                            "object_name": obj.name,
                            "curves": {},
                        }
                        by_key_data[data_key] = entry

                    # One concrete KeyBlock receives only one curve. If an SE
                    # packet ever carries both a raw name and an alias resolving
                    # to the same KeyBlock, the first resolved stream wins.
                    entry["curves"].setdefault(kb.name, samples)

            if not by_key_data:
                raise RuntimeError(
                    "Facial Bake produced no writable Shape Key bindings."
                )

            written_shape_curves = 0
            written_shape_datablocks = 0

            for entry in by_key_data.values():
                key_data = entry["key_data"]
                curves = entry["curves"]
                if not curves:
                    continue

                _assign_action(key_data, action)
                written_shape_datablocks += 1

                for key_name, samples in curves.items():
                    kb = key_data.key_blocks.get(key_name)
                    if kb is None or not samples:
                        continue

                    path = kb.path_from_id("value")
                    _write_fcurve(
                        action,
                        key_data,
                        path,
                        0,
                        samples,
                        key_name,
                    )
                    written_shape_curves += 1

            if written_shape_curves <= 0:
                raise RuntimeError(
                    "Facial Bake produced no writable Shape Key curves."
                )

            print(
                f"[GHEB Bake] Facial multi-mesh write / "
                f"{len(_bake.shape_samples)} SE Shape name(s) -> "
                f"{written_shape_curves} Blender Shape Key curve(s) / "
                f"{written_shape_datablocks} Shape Key datablock(s)"
            )

        return [action.name for action in created_actions]

    except Exception:
        # Body + Facial is one transaction even though the outputs are two
        # independent Actions. Restore prior assignments and remove every Action
        # created by this bake so a half-complete result is never left behind.
        for anim_data, previous, action in reversed(assignments):
            try:
                if anim_data.action == action:
                    anim_data.action = previous
            except Exception:
                pass

        for action in reversed(created_actions):
            try:
                if bpy.data.actions.get(action.name) is action:
                    bpy.data.actions.remove(action)
            except Exception:
                pass
        raise

def _write_fcurve(action, datablock, data_path, index, samples, group_name):
    if not samples:
        return None

    # Blender 5.2 layered Action API. fcurve_ensure_for_datablock creates the
    # appropriate Action Slot / Layer / Keyframe Strip / Channelbag for the
    # already-assigned datablock, without driving Scene evaluation per frame.
    fcurve = action.fcurve_ensure_for_datablock(
        datablock,
        data_path,
        index=int(index),
        group_name=str(group_name),
    )

    points = fcurve.keyframe_points
    points.add(len(samples))
    for point, (frame, value) in zip(points, samples):
        point.co = (float(frame), float(value))
        point.interpolation = 'LINEAR'
    fcurve.update()
    return fcurve


def _relay_message(route_id, payload):
    from . import GHEB_Protocol as protocol
    return protocol.relay_message(route_id, payload)


class GHEBTimelineProps(bpy.types.PropertyGroup):
    # Compatibility property for older .blend files. G-HUB canonical
    # timeline ownership is dynamic and does not use a fixed master selector.
    sync_master: bpy.props.EnumProperty(
        name="Legacy Master",
        items=[
            ('BLENDER', "Blender", "Legacy compatibility value"),
            ('CASCADEUR', "Cascadeur", "Legacy compatibility value"),
        ],
        default='CASCADEUR',
        options={'HIDDEN'},
    )
    sync_enable: bpy.props.BoolProperty(
        name="Sync Timeline",
        default=False,
        description="Participate in the G-HUB Virtual Timeline",
        options={'SKIP_SAVE'},
    )

    # Offline Bake uses exact frame transactions and remains independent
    # from real-time Timeline playback.
    is_baking: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'})
    bake_mode: bpy.props.EnumProperty(
        name="Mode",
        items=[
            ('BODY', "Body", "Bake Body Action only"),
            ('FACE', "Facial", "Bake Facial Shape Key Action only"),
            ('BOTH', "Body + Facial", "Bake Body and Facial as separate Actions"),
        ],
        default='BODY',
    )
    bake_slot: bpy.props.EnumProperty(
        name="Character",
        items=[
            ('0', "C1", "Bake Character C1"),
            ('1', "C2", "Bake Character C2"),
            ('2', "C3", "Bake Character C3"),
            ('3', "C4", "Bake Character C4"),
            ('4', "C5", "Bake Character C5"),
        ],
        default='0',
    )
    bake_start: bpy.props.IntProperty(name="Start", default=1, min=0)
    bake_end: bpy.props.IntProperty(name="End", default=100, min=1)
    bake_delay: bpy.props.FloatProperty(
        name="Bake Delay",
        description=(
            "Optional delay between completed Offline Bake frames. "
            "0.00 uses the normal GHEB timer cadence without an extra wait"
        ),
        default=0.02,
        min=0.00,
        max=1.0,
        precision=2,
    )


def draw_timeline_section(layout, context, endpoint_running=None):
    props = context.scene.gheb_timeline

    box = layout.box()
    box.label(text="Timeline & Bake", icon='TIME')

    # Timeline is a first-class feature, independent from Character and
    # ShapeMixer sync. All three still share one Blender endpoint / Control TCP.
    timeline_col = box.column()
    timeline_col.enabled = not props.is_baking

    row = timeline_col.row()
    row.scale_y = 1.2
    if not props.sync_enable:
        row.operator(
            "gheb.start_timeline_sync",
            text="Sync Timeline",
            icon='PLAY',
        )
    else:
        row.operator(
            "gheb.stop_timeline_sync",
            text="Timeline Sync Active (STOP)",
            icon='PAUSE',
            depress=True,
        )

        owner = _runtime.owner_label
        timeline_col.label(
            text=f"Virtual Timeline | Owner: {owner}",
            icon='LINKED',
        )

    # Offline Bake -------------------------------------------------------
    box.separator()
    bake_col = box.column()

    controls = bake_col.column()
    controls.enabled = not props.is_baking

    controls.prop(props, "bake_mode", text="Mode")

    scene_props = getattr(context.scene, "gheb_props", None)
    try:
        selected_index = int(props.bake_slot)
    except Exception:
        selected_index = -1

    wants_body, wants_face = _bake_mode_flags(context.scene)

    if wants_face and not wants_body:
        bake_col.label(text="Facial Bake Target: all active Face Slots")

        from . import GHEB_ShapeKeys

        active_face_slots = []
        valid_face_slots = []
        for slot_index in range(5):
            face_slot = GHEB_ShapeKeys.get_shape_slot(
                context.scene, slot_index
            )
            if face_slot is None or not face_slot.is_active:
                continue
            active_face_slots.append(slot_index)

            face_target = GHEB_ShapeKeys.get_shape_target(
                context.scene, slot_index
            )
            if (
                face_target is not None
                and face_target.type == 'MESH'
                and face_target.data.shape_keys is not None
            ):
                valid_face_slots.append(slot_index)

        labels = ", ".join(
            f"C{slot_index + 1}" for slot_index in valid_face_slots
        )
        controls.label(
            text=(
                f"Facial: {len(valid_face_slots)} active target(s)"
                + (f" [{labels}]" if labels else "")
            ),
            icon='SHAPEKEY_DATA' if valid_face_slots else 'ERROR',
        )

        if len(valid_face_slots) != len(active_face_slots):
            controls.label(
                text="One or more active Facial Slots have no valid target.",
                icon='ERROR',
            )
    else:
        bake_col.label(text="Bake Target (single Character):")
        controls.prop(props, "bake_slot", text="Character")

        if wants_body:
            body_valid = (
                scene_props is not None
                and 0 <= selected_index < len(scene_props.slots)
                and scene_props.slots[selected_index].is_active
                and scene_props.slots[selected_index].target_armature is not None
            )
            controls.label(
                text="Body: target configured" if body_valid else "Body: target missing",
                icon='ARMATURE_DATA' if body_valid else 'ERROR',
            )

        if wants_face:
            from . import GHEB_ShapeKeys

            face_slot = GHEB_ShapeKeys.get_shape_slot(
                context.scene, selected_index
            )
            face_target = GHEB_ShapeKeys.get_shape_target(
                context.scene, selected_index
            )
            face_valid = (
                face_slot is not None
                and face_slot.is_active
                and face_target is not None
                and face_target.type == 'MESH'
                and face_target.data.shape_keys is not None
            )
            controls.label(
                text="Facial: target configured" if face_valid else "Facial: target missing",
                icon='SHAPEKEY_DATA' if face_valid else 'ERROR',
            )

    row = controls.row(align=True)
    row.prop(props, "bake_start")
    row.prop(props, "bake_end")

    row = controls.row()
    row.prop(props, "bake_delay")

    if props.is_baking:
        bake_col.label(
            text=(
                f"{_bake.status} | "
                f"{_bake.overall_completed_frames}/{_bake.overall_total_frames}"
            ),
            icon='TIME',
        )
        row = bake_col.row()
        row.scale_y = 1.2
        row.operator(
            "gheb.cancel_bake",
            text="Cancel Offline Bake",
            icon='CANCEL',
        )
    else:
        row = bake_col.row()
        row.scale_y = 1.2
        button_text = (
            "Bake Active Facial Slots"
            if wants_face and not wants_body
            else "Bake Selected Target"
        )
        row.operator(
            "gheb.bake_animation",
            text=button_text,
            icon='REC',
        )


class GHEB_OT_StartTimelineSync(bpy.types.Operator):
    bl_idname = "gheb.start_timeline_sync"
    bl_label = "Start Timeline Sync"

    def execute(self, context):
        # Lazy import avoids a registration-time circular dependency while
        # preserving one shared Blender endpoint / one Control TCP.
        from . import GHEB_Avatar

        if not GHEB_Avatar.start_timeline_sync(context.scene):
            self.report({'ERROR'}, "Failed to start Timeline sync.")
            return {'CANCELLED'}

        self.report({'INFO'}, "Timeline sync started.")
        return {'FINISHED'}


class GHEB_OT_StopTimelineSync(bpy.types.Operator):
    bl_idname = "gheb.stop_timeline_sync"
    bl_label = "Stop Timeline Sync"

    def execute(self, context):
        from . import GHEB_Avatar
        GHEB_Avatar.stop_timeline_sync(context.scene)
        self.report({'INFO'}, "Timeline sync stopped.")
        return {'FINISHED'}


class GHEB_OT_BakeAnimation(bpy.types.Operator):
    bl_idname = "gheb.bake_animation"
    bl_label = "Bake Animation"
    bl_description = "Offline-bake Body for one selected Slot or Facial for all active Face Slots"

    def execute(self, context):
        from . import GHEB_Avatar

        controller = GHEB_Avatar.get_controller()
        ok, reason = start_offline_bake(controller, context.scene)
        if not ok:
            self.report({'ERROR'}, reason)
            return {'CANCELLED'}

        self.report({'INFO'}, "GHEB Offline Bake started.")
        return {'FINISHED'}


class GHEB_OT_CancelBake(bpy.types.Operator):
    bl_idname = "gheb.cancel_bake"
    bl_label = "Cancel Offline Bake"

    def execute(self, context):
        from . import GHEB_Avatar
        cancel_offline_bake(
            GHEB_Avatar.get_controller(),
            reason="Cancelled by user.",
            send_cancel=True,
        )
        self.report({'INFO'}, "GHEB Offline Bake cancelled.")
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Public integration points used by the shared GHEB controller.
# ---------------------------------------------------------------------------

def on_endpoint_assigned(controller):
    """Synchronize participation after HELLO / ASSIGN."""
    _runtime.controller = controller
    scene = _get_scene()
    if scene is None:
        return

    _establish_baseline(scene)

    if getattr(controller, "timeline_enabled", False):
        controller.client.send(_sync_request_message())


def before_endpoint_disconnect(controller):
    """Release ownership cleanly before the shared Blender endpoint leaves."""
    if _bake.active:
        cancel_offline_bake(
            controller,
            reason="G-HUB endpoint is disconnecting.",
            send_cancel=True,
        )

    scene = _get_scene()
    if scene is not None and getattr(controller, "timeline_enabled", False):
        try:
            controller.client.send(_release_message())
        except Exception:
            pass

    _runtime.reset(scene)


def on_endpoint_disconnected():
    scene = _get_scene()
    if _bake.active:
        on_endpoint_lost_during_bake()
    if scene is not None and hasattr(scene, "gheb_timeline"):
        scene.gheb_timeline.sync_enable = False
        scene.gheb_timeline.is_baking = False
    _runtime.reset(scene)


def start_sync(controller):
    """Enable Timeline as an independent feature on the shared endpoint."""
    _runtime.controller = controller
    scene = _get_scene()
    if scene is None:
        return False

    props = scene.gheb_timeline
    props.sync_enable = True

    _runtime.last_sync_enable = True
    _runtime.canonical_owner = False
    _runtime.last_applied_revision = -1
    _runtime.remote_playback_follow = False
    _runtime.owner_label = "None"
    _establish_baseline(scene, keep_toggle_state=True)

    if controller is not None and controller.client.endpoint_id:
        controller.client.send(_sync_request_message())

    print("[GHEB Timeline] Sync ON")
    return True


def stop_sync(controller):
    """Disable only Timeline; Character/Shape may keep the endpoint alive."""
    scene = _get_scene()
    if scene is None:
        return False

    props = scene.gheb_timeline

    if controller is not None and controller.client.endpoint_id:
        try:
            controller.client.send(_release_message())
        except Exception:
            pass

    props.sync_enable = False
    _runtime.last_sync_enable = False
    _runtime.canonical_owner = False
    _runtime.last_applied_revision = -1
    _runtime.remote_playback_follow = False
    _runtime.owner_endpoint_id = 0
    _runtime.owner_session_id = 0
    _runtime.owner_label = "None"
    _establish_baseline(scene, keep_toggle_state=True)

    print("[GHEB Timeline] Sync OFF")
    return True


def _apply_pending_remote_state(scene):
    """Apply only the newest remote canonical state queued this timer cycle."""
    pending = _runtime.pending_remote_state
    if pending is None:
        return False

    _runtime.pending_remote_state = None

    time_seconds = float(pending["time_seconds"])
    is_playing = bool(pending["is_playing"])

    _runtime.remote_applying = True
    try:
        current_time = _scene_time_seconds(scene)
        if abs(current_time - time_seconds) > _TIME_EPSILON:
            _set_scene_time_seconds(scene, time_seconds)

        currently_playing = _is_animation_playing()

        # G-HUB Timeline protocol v1 publishes canonical time + play state,
        # but it does not publish a playback-speed multiplier. If an external
        # owner (for example SE at 40%) is playing, starting Blender's native
        # playback would advance Blender at its own 1x rate. Each later
        # canonical packet would then pull Blender backward, causing visible
        # forward/backward chatter.
        #
        # Therefore external playback is followed as canonical position updates
        # instead of running Blender's independent playback clock. A remote
        # Pause also forces native playback off if it happens to be active.
        if currently_playing:
            _pause_animation_playback()

        _runtime.remote_playback_follow = is_playing
        _runtime.last_observed_time = _scene_time_seconds(scene)
        _runtime.last_observed_playing = is_playing
        _runtime.last_scrubbing = False
        _runtime.next_scrub_publish_at = 0.0
        _runtime.next_tick_at = time.monotonic() + _TICK_INTERVAL
        return True
    except Exception as exc:
        print(f"[GHEB Timeline] Remote apply error: {exc}")
        return False
    finally:
        _runtime.remote_applying = False


def tick(controller):
    """Main-thread Virtual Timeline adapter. Called by GHEB's 60 Hz timer."""
    _runtime.controller = controller
    scene = _get_scene()
    if scene is None or controller is None or not controller.running:
        return

    props = scene.gheb_timeline

    # Offline Bake is an independent transport feature. It must continue to
    # advance even when Virtual Timeline Sync is OFF, as long as the selected
    # Body/Shape route keeps the shared endpoint alive. Previously this bake
    # tick sat below the timeline_enabled guard, which accidentally made
    # Timeline Sync a hidden requirement for Offline Bake.
    if props.is_baking or _bake.active:
        _tick_bake(controller, scene)
        return

    if not getattr(controller, "timeline_enabled", False):
        return

    if not _runtime.initialized:
        _establish_baseline(scene)

    # Sync ON/OFF is reconciled here instead of mutating runtime from an RNA
    # update callback. This stays safe in Blender 5.2 and mirrors GHEU's toggle
    # reconciliation model.
    if bool(props.sync_enable) != _runtime.last_sync_enable:
        _runtime.last_sync_enable = bool(props.sync_enable)
        _runtime.canonical_owner = False
        _runtime.last_applied_revision = -1

        if props.sync_enable:
            _establish_baseline(scene, keep_toggle_state=True)
            if controller.client.endpoint_id:
                controller.client.send(_sync_request_message())
            print("[GHEB Timeline] Sync ON")
        else:
            if controller.client.endpoint_id:
                controller.client.send(_release_message())
            _runtime.owner_label = "None"
            _establish_baseline(scene, keep_toggle_state=True)
            print("[GHEB Timeline] Sync OFF")
        return

    # Apply at most one remote canonical state per Blender timer cycle.
    # poll_events() may have delivered several high-frequency scrub states before
    # this tick; handle_timeline_state() keeps only the newest revision.
    if _runtime.pending_remote_state is not None:
        _apply_pending_remote_state(scene)
        return

    # While an external canonical owner is playing, Blender deliberately keeps
    # its native playback clock stopped and follows the canonical positions.
    # Do not reinterpret that intentional local pause as a new local PAUSE.
    if _runtime.remote_playback_follow:
        return

    # G-HUB Virtual Timeline is symmetric: there is no fixed Master selector.
    # Any explicit local Blender timeline operation may claim ownership.

    if not props.sync_enable or _runtime.remote_applying:
        return

    current_playing = _is_animation_playing()
    current_scrubbing = _is_scrubbing()
    current_time = _scene_time_seconds(scene)
    now = time.monotonic()

    # Blender 5.2 can expose transient playback-ish screen state while the
    # timeline UI is being dragged. Scrubbing is an explicit paused seek in
    # G-HUB semantics, so it always wins over is_animation_playing.
    if current_scrubbing:
        changed = abs(current_time - _runtime.last_observed_time) > _TIME_EPSILON
        scrub_started = not _runtime.last_scrubbing

        _runtime.last_scrubbing = True
        _runtime.last_observed_playing = False

        if scrub_started or (changed and now >= _runtime.next_scrub_publish_at):
            _runtime.last_observed_time = current_time
            _runtime.next_scrub_publish_at = now + _SCRUB_PUBLISH_INTERVAL
            controller.client.send(
                _publish_message(current_time, False, True)
            )
        return

    if _runtime.last_scrubbing:
        # Publish one final paused position at mouse release. This closes the
        # scrub cleanly without allowing a transient Play state to escape.
        _runtime.last_scrubbing = False
        _runtime.last_observed_time = current_time
        _runtime.last_observed_playing = current_playing
        _runtime.next_scrub_publish_at = 0.0
        controller.client.send(
            _publish_message(current_time, False, True)
        )
        return

    # Primary Play/Pause edges are published immediately by Blender's
    # animation_playback_pre/post handlers below. Keep this state-difference
    # branch only as a conservative fallback for unusual contexts where a
    # Blender handler was not dispatched. Handler-driven paths update
    # last_observed_playing synchronously, so normal operation does not double
    # publish here.
    if current_playing != _runtime.last_observed_playing:
        natural_end = (
            not current_playing
            and _runtime.canonical_owner
            and _is_at_natural_end(scene)
        )

        _runtime.last_observed_playing = current_playing
        _runtime.last_observed_time = current_time
        _runtime.next_tick_at = now + _TICK_INTERVAL

        controller.client.send(
            _publish_message(
                current_time,
                current_playing,
                not natural_end,
            )
        )
        return

    if current_playing:
        _runtime.last_observed_time = current_time

        # Only the canonical Blender owner publishes continuous playback ticks.
        if not _runtime.canonical_owner:
            return

        if now < _runtime.next_tick_at:
            return

        _runtime.next_tick_at = now + _TICK_INTERVAL
        controller.client.send(
            _publish_message(current_time, True, False)
        )
        return

    # Paused local time change == scrub, frame step, or direct frame entry.
    if abs(current_time - _runtime.last_observed_time) <= _TIME_EPSILON:
        return

    _runtime.last_observed_time = current_time
    controller.client.send(
        _publish_message(current_time, False, True)
    )


def handle_timeline_state(message, controller):
    _runtime.controller = controller
    scene = _get_scene()
    if scene is None or controller is None:
        return

    if not getattr(controller, "timeline_enabled", False):
        return

    props = scene.gheb_timeline
    if props.is_baking or _bake.active:
        return
    if not props.sync_enable:
        return

    try:
        time_seconds = float(message.get("time_seconds", 0.0))
        is_playing = bool(message.get("is_playing", False))
        revision = int(message.get("revision", 0))

        owner_endpoint_id = message.get("owner_endpoint_id", None)
        owner_session_id = message.get("owner_session_id", None)

        is_owner = (
            owner_endpoint_id is not None
            and owner_session_id is not None
            and int(owner_endpoint_id) == int(controller.client.endpoint_id)
            and int(owner_session_id) == int(controller.client.session_id)
            and int(controller.client.endpoint_id) != 0
            and int(controller.client.session_id) != 0
        )
    except Exception as exc:
        print(f"[GHEB Timeline] Invalid TIMELINE_STATE: {exc}")
        return

    # G-HUB revisions are monotonic. Never let an older queued state rewind a
    # newer one.
    if revision <= _runtime.last_applied_revision:
        return

    _runtime.last_applied_revision = revision
    _runtime.canonical_owner = is_owner
    _runtime.owner_endpoint_id = int(owner_endpoint_id or 0)
    _runtime.owner_session_id = int(owner_session_id or 0)

    if is_owner:
        _runtime.owner_label = "Blender"
    elif owner_endpoint_id is None:
        _runtime.owner_label = "None"
    else:
        _runtime.owner_label = f"EP_{int(owner_endpoint_id):03d}"

    # G-HUB echoes TIMELINE_STATE to the sender as canonical ACK. Never drive
    # Blender time from its own echo; the packet is slightly old by arrival.
    if is_owner:
        _runtime.pending_remote_state = None
        _runtime.remote_playback_follow = False
        _runtime.last_observed_time = _scene_time_seconds(scene)
        _runtime.last_observed_playing = _is_animation_playing()
        return

    # Do not force Scene evaluation once for every queued network state.
    # GHEB_Avatar polls all TCP messages first, then calls Timeline.tick().
    # Store only the newest revision here; the next tick applies it once.
    pending = _runtime.pending_remote_state
    if (
        pending is None
        or revision > int(pending.get("revision", -1))
    ):
        _runtime.pending_remote_state = {
            "revision": revision,
            "time_seconds": time_seconds,
            "is_playing": is_playing,
        }


@persistent
def _on_animation_playback_pre(*args):
    """Publish a local Blender PLAY edge immediately.

    Blender can complete a very short Play -> Stop cycle entirely between two
    60 Hz GHEB timer samples. Polling alone can therefore lose the STOP edge.
    The playback handlers are the authoritative source for discrete transport
    events; the timer remains responsible for scrub positions and owner ticks.
    """
    scene = args[0] if args else _get_scene()
    controller = _runtime.controller

    if scene is None or controller is None:
        return
    if not getattr(controller, "running", False):
        return
    if not getattr(controller, "timeline_enabled", False):
        return

    props = getattr(scene, "gheb_timeline", None)
    if props is None or props.is_baking or _bake.active or not props.sync_enable:
        return

    current_time = _scene_time_seconds(scene)
    _runtime.last_observed_time = current_time
    _runtime.last_observed_playing = True
    _runtime.last_scrubbing = False
    _runtime.next_scrub_publish_at = 0.0
    _runtime.next_tick_at = time.monotonic() + _TICK_INTERVAL

    # Playback started because a remote canonical state was applied locally.
    # Never echo that transport edge back as a new Blender ownership claim.
    if _runtime.remote_applying:
        return

    controller.client.send(
        _publish_message(current_time, True, True)
    )
    print("[GHEB Timeline] Local PLAY event -> G-HUB")


@persistent
def _on_animation_playback_post(*args):
    """Publish a local Blender PAUSE edge immediately."""
    scene = args[0] if args else _get_scene()
    controller = _runtime.controller

    if scene is None or controller is None:
        return
    if not getattr(controller, "running", False):
        return
    if not getattr(controller, "timeline_enabled", False):
        return

    props = getattr(scene, "gheb_timeline", None)
    if props is None or props.is_baking or _bake.active or not props.sync_enable:
        return

    current_time = _scene_time_seconds(scene)
    _runtime.last_observed_time = current_time
    _runtime.last_observed_playing = False
    _runtime.last_scrubbing = False
    _runtime.next_scrub_publish_at = 0.0
    _runtime.next_tick_at = time.monotonic() + _TICK_INTERVAL

    # Playback stopped because a remote canonical state was applied locally.
    # The originating endpoint already owns the command; do not echo it.
    if _runtime.remote_applying:
        return

    natural_end = (
        _runtime.canonical_owner
        and _is_at_natural_end(scene)
    )

    controller.client.send(
        _publish_message(
            current_time,
            False,
            not natural_end,
        )
    )
    print("[GHEB Timeline] Local PAUSE event -> G-HUB")


def reset_runtime():
    scene = _get_scene()
    if _bake.active:
        cancel_offline_bake(_bake.controller, "Runtime reset.", send_cancel=False)
    _runtime.reset(scene)
    _bake.reset()


# ---------------------------------------------------------------------------
# Blender timeline helpers.
# ---------------------------------------------------------------------------

def _get_scene():
    try:
        return bpy.context.scene
    except Exception:
        return None


def _fps(scene):
    fps = float(scene.render.fps)
    fps_base = float(scene.render.fps_base)
    if fps <= 0.0:
        fps = 24.0
    if fps_base <= 0.0:
        fps_base = 1.0
    return fps / fps_base


def _scene_time_seconds(scene):
    frame = float(scene.frame_current) + float(scene.frame_subframe)
    return frame / _fps(scene)


def _set_scene_time_seconds(scene, seconds):
    fps = _fps(scene)
    frame_float = max(0.0, float(seconds) * fps)

    frame_int = int(math.floor(frame_float + 1.0e-9))
    subframe = frame_float - frame_int

    # Avoid a 0.999999999 -> next-frame mismatch from floating-point noise.
    if subframe >= 0.999999:
        frame_int += 1
        subframe = 0.0

    scene.frame_set(frame_int, subframe=max(0.0, min(1.0, subframe)))


def _is_animation_playing():
    try:
        wm = bpy.context.window_manager
        for window in wm.windows:
            screen = window.screen
            if screen is not None and screen.is_animation_playing:
                return True
    except Exception:
        pass
    return False


def _is_scrubbing():
    # Blender 5.2 exposes Screen.is_scrubbing. This is informational only;
    # frame-change detection remains the canonical input trigger so keyboard
    # stepping/direct frame entry work too.
    try:
        wm = bpy.context.window_manager
        for window in wm.windows:
            screen = window.screen
            if screen is not None and getattr(screen, "is_scrubbing", False):
                return True
    except Exception:
        pass
    return False


def _operator_window():
    try:
        wm = bpy.context.window_manager
        if bpy.context.window is not None:
            return bpy.context.window
        for window in wm.windows:
            return window
    except Exception:
        return None
    return None


def _start_animation_playback():
    if _is_animation_playing():
        return True

    window = _operator_window()
    if window is None:
        return False

    try:
        with bpy.context.temp_override(window=window, screen=window.screen):
            result = bpy.ops.screen.animation_play(reverse=False, sync=False)
        return 'FINISHED' in result
    except Exception as exc:
        print(f"[GHEB Timeline] animation_play failed: {exc}")
        return False


def _pause_animation_playback():
    if not _is_animation_playing():
        return True

    window = _operator_window()
    if window is None:
        return False

    try:
        with bpy.context.temp_override(window=window, screen=window.screen):
            result = bpy.ops.screen.animation_pause()
        return 'FINISHED' in result
    except Exception as exc:
        print(f"[GHEB Timeline] animation_pause failed: {exc}")
        return False


def _is_at_natural_end(scene):
    current = float(scene.frame_current) + float(scene.frame_subframe)
    return current >= (float(scene.frame_end) - 0.001)


def _establish_baseline(scene, keep_toggle_state=False):
    _runtime.initialized = True
    _runtime.remote_applying = False
    _runtime.last_observed_time = _scene_time_seconds(scene)
    _runtime.last_observed_playing = _is_animation_playing()
    _runtime.next_tick_at = time.monotonic() + _TICK_INTERVAL

    if not keep_toggle_state:
        props = scene.gheb_timeline
        _runtime.last_sync_enable = bool(props.sync_enable)


def _publish_message(time_seconds, is_playing, claim_owner):
    from . import GHEB_Protocol as protocol
    return protocol.timeline_publish_message(
        time_seconds,
        is_playing,
        claim_owner,
    )


def _sync_request_message():
    from . import GHEB_Protocol as protocol
    return protocol.timeline_sync_request_message()


def _release_message():
    from . import GHEB_Protocol as protocol
    return protocol.timeline_release_message()


_CLASSES = (
    GHEBTimelineProps,
    GHEB_OT_StartTimelineSync,
    GHEB_OT_StopTimelineSync,
    GHEB_OT_BakeAnimation,
    GHEB_OT_CancelBake,
)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)

    bpy.types.Scene.gheb_timeline = bpy.props.PointerProperty(
        type=GHEBTimelineProps
    )

    # Discrete Blender transport edges are event-driven. This prevents a very
    # fast Play -> Stop from disappearing between 60 Hz polling samples.
    if _on_animation_playback_pre not in bpy.app.handlers.animation_playback_pre:
        bpy.app.handlers.animation_playback_pre.append(
            _on_animation_playback_pre
        )
    if _on_animation_playback_post not in bpy.app.handlers.animation_playback_post:
        bpy.app.handlers.animation_playback_post.append(
            _on_animation_playback_post
        )

    _runtime.reset(_get_scene())
    _bake.reset()


def unregister():
    if _bake.active:
        cancel_offline_bake(_bake.controller, "Add-on unregister.", send_cancel=True)
    _runtime.reset(_get_scene())
    _bake.reset()

    try:
        bpy.app.handlers.animation_playback_pre.remove(
            _on_animation_playback_pre
        )
    except ValueError:
        pass

    try:
        bpy.app.handlers.animation_playback_post.remove(
            _on_animation_playback_post
        )
    except ValueError:
        pass

    if hasattr(bpy.types.Scene, "gheb_timeline"):
        del bpy.types.Scene.gheb_timeline

    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
