#if TOOLS
using Godot;

/// <summary>
/// Replaces GHEG_Avatar Bone-name strings with Skeleton-driven dropdowns and
/// inserts GHEG-specific Pose / Smart Swizzle controls before Advanced.
/// </summary>
[Tool]
public partial class GHEG_AvatarInspectorPlugin : EditorInspectorPlugin
{
    public override bool _CanHandle(GodotObject @object)
    {
        return @object is GHEG_Avatar;
    }

    public override bool _ParseProperty(
        GodotObject @object,
        Variant.Type type,
        string name,
        PropertyHint hintType,
        string hintString,
        PropertyUsageFlags usageFlags,
        bool wide)
    {
        if (@object is not GHEG_Avatar avatar)
            return false;

        // Timeline ownership is handled by GHEG_TimelineAgent. Keep the
        // compatibility properties serialized on GHEG_Avatar, but hide them
        // from the public Inspector surface.
        if (name == nameof(GHEG_Avatar.TimelinePlayer) ||
            name == nameof(GHEG_Avatar.TimelineSyncEnabled) ||
            name == nameof(GHEG_Avatar.FbxBridgeOutputFolder) ||
            name == nameof(GHEG_Avatar.FbxBridgeAssetName))
        {
            return true;
        }

        if (type != Variant.Type.String)
            return false;

        switch (name)
        {
            case nameof(GHEG_Avatar.RootBone):
                AddPropertyEditor(
                    name,
                    new GHEG_BoneDropdownProperty(false),
                    false,
                    "Root Bone");
                return true;

            case nameof(GHEG_Avatar.PelvisBone):
                AddPropertyEditor(
                    name,
                    new GHEG_BoneDropdownProperty(true),
                    false,
                    "Pelvis 1");
                return true;

            case nameof(GHEG_Avatar.PelvisBone2):
                AddPropertyEditor(
                    name,
                    new GHEG_BoneDropdownProperty(true),
                    false,
                    "Pelvis 2");
                return true;

            case nameof(GHEG_Avatar.PelvisBone3):
                AddPropertyEditor(
                    name,
                    new GHEG_BoneDropdownProperty(true),
                    false,
                    "Pelvis 3");
                return true;

            case nameof(GHEG_Avatar.SmartSwizzleCacheData):
                // Internal serialized payload. Insert the GHEG action surface
                // here so Body settings, including Interpolation, stay together
                // above Pose / Smart Swizzle.
                var actions =
                    new GHEG_AvatarInspectorActions();
                actions.BindAvatar(avatar);
                AddCustomControl(actions);
                return true;
        }

        return false;
    }
}
#endif
