#if TOOLS
#nullable enable annotations
using System;
using System.Collections.Generic;
using Godot;

/// <summary>
/// Floating Smart Swizzle diagnostic window.
/// Read-only: it exposes the live runtime contract without owning pose data.
/// </summary>
[Tool]
public partial class GHEG_SSVisualizerWindow : Window
{
    private const double RefreshIntervalSeconds = 0.20;
    private const int RegularFontSize = 14;
    private const int TitleFontSize = 16;

    private static readonly Color ActiveGreen = new(0.10f, 0.88f, 0.62f, 1.0f);
    private static readonly Color Muted = new(1.0f, 1.0f, 1.0f, 0.62f);

    private readonly OptionButton _slot = new();
    private readonly LineEdit _filter = new();
    private readonly ItemList _bones = new();
    private readonly Label _route = new();
    private readonly Label _contract = new();
    private readonly Label _cache = new();
    private readonly Label _counts = new();
    private readonly Label _scale = new();
    private readonly Label _boneTitle = new();
    private readonly Label _boneMeta = new();
    private readonly Label _godotRest = new();
    private readonly Label _sourceRest = new();
    private readonly Label _live = new();
    private readonly Label _target = new();
    private readonly Label _applied = new();
    private readonly OptionButton _scenePose = new();
    private readonly CheckButton _sceneMarker = new() { Text = "Marker", ButtonPressed = true };
    private readonly CheckButton _sceneAxes = new() { Text = "Axes", ButtonPressed = true };
    private readonly CheckButton _sceneParent = new() { Text = "Parent Link", ButtonPressed = false };

    private readonly GHEG_SSSceneGizmoPlugin _sceneGizmo;

    private readonly List<int> _visibleBoneIds = new();
    private GHEG_System.SsDiagnosticSnapshot? _snapshot;
    private int _selectedBoneId = -1;
    private double _refreshRemaining;

    public GHEG_SSVisualizerWindow(GHEG_SSSceneGizmoPlugin sceneGizmo)
    {
        _sceneGizmo = sceneGizmo;
        Title = "GHEG — SS Visualizer";
        Size = new Vector2I(1040, 720);
        MinSize = new Vector2I(760, 520);
        Visible = false;
        Unresizable = false;

        CloseRequested += () =>
        {
            _sceneGizmo.ClearTarget();
            Hide();
        };

        var root = new MarginContainer();
        root.AddThemeConstantOverride("margin_left", 12);
        root.AddThemeConstantOverride("margin_right", 12);
        root.AddThemeConstantOverride("margin_top", 10);
        root.AddThemeConstantOverride("margin_bottom", 10);
        AddChild(root);
        root.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);

        var main = new VBoxContainer { SizeFlagsHorizontal = Control.SizeFlags.ExpandFill, SizeFlagsVertical = Control.SizeFlags.ExpandFill };
        main.AddThemeConstantOverride("separation", 7);
        root.AddChild(main);

        var header = new HBoxContainer();
        header.AddThemeConstantOverride("separation", 8);
        var title = new Label { Text = "SMART SWIZZLE DIAGNOSTICS", SizeFlagsHorizontal = Control.SizeFlags.ExpandFill };
        title.AddThemeFontSizeOverride("font_size", TitleFontSize);
        header.AddChild(title);
        header.AddChild(new Label { Text = "Slot" });
        for (int i = 0; i < 5; i++)
            _slot.AddItem($"C{i + 1}", i);
        _slot.CustomMinimumSize = new Vector2(88, 0);
        header.AddChild(_slot);
        main.AddChild(header);

        main.AddChild(new HSeparator());

        var summary = new HBoxContainer();
        summary.AddThemeConstantOverride("separation", 22);
        summary.AddChild(MakeSummaryColumn("ROUTE", _route));
        summary.AddChild(MakeSummaryColumn("CONTRACT", _contract));
        summary.AddChild(MakeSummaryColumn("REST CACHE", _cache));
        summary.AddChild(MakeSummaryColumn("BONES", _counts));
        summary.AddChild(MakeSummaryColumn("POSITION SCALE", _scale));
        main.AddChild(summary);

        main.AddChild(new HSeparator());

        var split = new HSplitContainer { SizeFlagsVertical = Control.SizeFlags.ExpandFill };
        main.AddChild(split);

        var left = new VBoxContainer { CustomMinimumSize = new Vector2(280, 0), SizeFlagsVertical = Control.SizeFlags.ExpandFill };
        left.AddThemeConstantOverride("separation", 5);
        var browserTitle = new Label { Text = "BONE BROWSER" };
        browserTitle.AddThemeFontSizeOverride("font_size", TitleFontSize);
        left.AddChild(browserTitle);
        _filter.PlaceholderText = "Filter bones...";
        left.AddChild(_filter);
        _bones.SizeFlagsVertical = Control.SizeFlags.ExpandFill;
        _bones.AllowReselect = true;
        left.AddChild(_bones);
        split.AddChild(left);

        var rightScroll = new ScrollContainer { SizeFlagsHorizontal = Control.SizeFlags.ExpandFill, SizeFlagsVertical = Control.SizeFlags.ExpandFill };
        split.AddChild(rightScroll);
        var details = new VBoxContainer { SizeFlagsHorizontal = Control.SizeFlags.ExpandFill };
        details.AddThemeConstantOverride("separation", 7);
        rightScroll.AddChild(details);

        _boneTitle.Text = "Select a bone";
        _boneTitle.AddThemeFontSizeOverride("font_size", TitleFontSize);
        details.AddChild(_boneTitle);
        _boneMeta.Modulate = Muted;
        details.AddChild(_boneMeta);

        var sceneView = new HBoxContainer();
        sceneView.AddThemeConstantOverride("separation", 8);
        var sceneLabel = new Label { Text = "SCENE VIEW" };
        sceneLabel.AddThemeFontSizeOverride("font_size", TitleFontSize);
        sceneView.AddChild(sceneLabel);
        _scenePose.AddItem("Actual Applied", (int)GHEG_System.SsScenePoseKind.Applied);
        _scenePose.AddItem("Resolved Target", (int)GHEG_System.SsScenePoseKind.ResolvedTarget);
        _scenePose.AddItem("Godot Rest", (int)GHEG_System.SsScenePoseKind.GodotRest);
        _scenePose.Select(0);
        sceneView.AddChild(_scenePose);
        sceneView.AddChild(_sceneMarker);
        sceneView.AddChild(_sceneAxes);
        sceneView.AddChild(_sceneParent);
        details.AddChild(sceneView);
        AddDiagnosticBlock(details, "GODOT REST", _godotRest);
        AddDiagnosticBlock(details, "CASCADEUR REST", _sourceRest);
        AddDiagnosticBlock(details, "LIVE SAMPLE", _live);
        AddDiagnosticBlock(details, "RESOLVED TARGET", _target);
        AddDiagnosticBlock(details, "ACTUAL APPLIED POSE", _applied);

        ApplyFontSize(root);

        _slot.ItemSelected += OnSlotSelected;
        _filter.TextChanged += _ => RebuildBoneList();
        _bones.ItemSelected += OnBoneSelected;
        _scenePose.ItemSelected += _ => RefreshSceneView();
        _sceneMarker.Toggled += _ => RefreshSceneView();
        _sceneAxes.Toggled += _ => RefreshSceneView();
        _sceneParent.Toggled += _ => RefreshSceneView();

        ProcessMode = ProcessModeEnum.Always;
        SetProcess(true);
    }

    public void OpenForSlot(int slotIndex)
    {
        int clamped = Mathf.Clamp(slotIndex, 0, 4);
        _slot.Select(clamped);
        _selectedBoneId = -1;
        _sceneGizmo.ClearTarget();
        RefreshSnapshot(true);
        PopupCentered(Size);
    }

    public override void _Process(double delta)
    {
        if (!Visible)
        {
            _sceneGizmo.ClearTarget();
            return;
        }

        _refreshRemaining -= delta;
        if (_refreshRemaining > 0)
            return;

        _refreshRemaining = RefreshIntervalSeconds;
        RefreshSnapshot(false);
    }

    private void RefreshSnapshot(bool rebuildList)
    {
        int slotIndex = Mathf.Clamp(_slot.Selected, 0, 4);
        if (!GHEG_System.TryGetSsDiagnosticSnapshot(slotIndex, out GHEG_System.SsDiagnosticSnapshot snapshot))
        {
            _snapshot = null;
            _route.Text = "NO SYSTEM";
            _contract.Text = "--";
            _cache.Text = "--";
            _counts.Text = "--";
            _scale.Text = "--";
            SetActive(_route, false);
            ClearDetails();
            if (rebuildList || _bones.ItemCount > 0)
            {
                _bones.Clear();
                _visibleBoneIds.Clear();
            }
            return;
        }

        bool boneLayoutChanged = _snapshot is null || _snapshot.BoneCount != snapshot.BoneCount || _snapshot.SlotIndex != snapshot.SlotIndex;
        _snapshot = snapshot;

        _route.Text = snapshot.RouteReady
            ? (snapshot.UdpObserved ? "LIVE" : "ROUTED")
            : (snapshot.AvatarConfigured ? "READY" : "--");
        _contract.Text = snapshot.PoseContractReady ? "READY" : "WAIT";
        _cache.Text = snapshot.CacheStatus;
        _counts.Text = $"{snapshot.MappedBoneCount}/{snapshot.BoneCount} mapped  |  {snapshot.TranslationBoneCount} pos";
        _scale.Text = snapshot.PositionScale > 0 ? snapshot.PositionScale.ToString("0.####") : "--";

        SetActive(_route, snapshot.RouteReady || snapshot.UdpObserved);
        SetActive(_contract, snapshot.PoseContractReady);
        SetActive(_cache, snapshot.CacheStatus.StartsWith("Ready", StringComparison.OrdinalIgnoreCase));

        if (rebuildList || boneLayoutChanged)
            RebuildBoneList();

        RefreshSelectedBoneDetails();
        RefreshSceneView();
    }

    private void RebuildBoneList()
    {
        _bones.Clear();
        _visibleBoneIds.Clear();
        GHEG_System.SsDiagnosticSnapshot? snapshot = _snapshot;
        if (snapshot is null)
            return;

        string filter = (_filter.Text ?? "").Trim();
        foreach (GHEG_System.SsBoneDiagnostic bone in snapshot.Bones)
        {
            if (filter.Length > 0 && bone.BoneName.IndexOf(filter, StringComparison.OrdinalIgnoreCase) < 0)
                continue;

            string flags = bone.TranslationEnabled ? " [T]" : bone.Mapped ? "" : " [--]";
            int item = _bones.AddItem($"{bone.BoneId:000}  {bone.BoneName}{flags}");
            _visibleBoneIds.Add(bone.BoneId);
            if (!bone.Mapped)
                _bones.SetItemCustomFgColor(item, Muted);
            else if (bone.TranslationEnabled)
                _bones.SetItemCustomFgColor(item, ActiveGreen);
        }

        if (_selectedBoneId >= 0)
        {
            int visibleIndex = _visibleBoneIds.IndexOf(_selectedBoneId);
            if (visibleIndex >= 0)
                _bones.Select(visibleIndex);
        }
    }

    private void OnSlotSelected(long index)
    {
        _selectedBoneId = -1;
        RefreshSnapshot(true);
    }

    private void OnBoneSelected(long index)
    {
        int i = (int)index;
        if (i < 0 || i >= _visibleBoneIds.Count)
            return;
        _selectedBoneId = _visibleBoneIds[i];
        RefreshSelectedBoneDetails();
        RefreshSceneView();
    }

    private void RefreshSelectedBoneDetails()
    {
        GHEG_System.SsDiagnosticSnapshot? snapshot = _snapshot;
        if (snapshot is null || _selectedBoneId < 0 || _selectedBoneId >= snapshot.Bones.Count)
        {
            ClearDetails();
            return;
        }

        GHEG_System.SsBoneDiagnostic bone = snapshot.Bones[_selectedBoneId];
        _boneTitle.Text = $"{bone.BoneId:000}  {bone.BoneName}";
        _boneMeta.Text = $"Parent: {bone.ParentName}   |   Mapping: {(bone.Mapped ? "MAPPED" : "--")}   |   Translation: {(bone.TranslationEnabled ? "ON" : "OFF")}";
        SetActive(_boneTitle, bone.Mapped);

        Quaternion godotRestRotation = new Quaternion(bone.GodotRest.Basis.Orthonormalized());
        _godotRest.Text = $"Position  {V(bone.GodotRest.Origin)}\nRotation  {Q(godotRestRotation)}";
        _sourceRest.Text = $"Position  {(bone.HasSourceRestPosition ? V(bone.SourceRestPosition) : "--")}\nRotation  {(bone.HasSourceRestRotation ? Q(bone.SourceRestRotation) : "--")}";
        _live.Text = $"Position  {(bone.HasLivePosition ? V(bone.LivePosition) : "--")}\nRotation  {(bone.HasLiveRotation ? Q(bone.LiveRotation) : "--")}";
        _target.Text = $"Position  {(bone.HasTargetPosition ? V(bone.TargetPosition) : "--")}\nRotation  {(bone.HasTargetRotation ? Q(bone.TargetRotation) : "--")}";
        _applied.Text = $"Position  {V(bone.AppliedPosition)}\nRotation  {Q(bone.AppliedRotation)}";
    }

    private void RefreshSceneView()
    {
        if (!Visible || _snapshot is null || _selectedBoneId < 0)
        {
            _sceneGizmo.ClearTarget();
            return;
        }

        var poseKind = (GHEG_System.SsScenePoseKind)_scenePose.GetSelectedId();
        if (!GHEG_System.TryGetSsScenePose(
                _snapshot.SlotIndex,
                _selectedBoneId,
                poseKind,
                out Skeleton3D? skeleton,
                out Transform3D bonePose,
                out bool hasParent,
                out Transform3D parentPose) ||
            skeleton is null)
        {
            _sceneGizmo.ClearTarget();
            return;
        }

        _sceneGizmo.SetTarget(
            skeleton,
            bonePose,
            hasParent,
            parentPose,
            _sceneMarker.ButtonPressed,
            _sceneAxes.ButtonPressed,
            _sceneParent.ButtonPressed);
    }

    private void ClearDetails()
    {
        _boneTitle.Text = "Select a bone";
        _boneMeta.Text = "";
        _godotRest.Text = "Position  --\nRotation  --";
        _sourceRest.Text = "Position  --\nRotation  --";
        _live.Text = "Position  --\nRotation  --";
        _target.Text = "Position  --\nRotation  --";
        _applied.Text = "Position  --\nRotation  --";
        _boneTitle.RemoveThemeColorOverride("font_color");
    }

    private static VBoxContainer MakeSummaryColumn(string title, Label value)
    {
        var box = new VBoxContainer();
        box.AddThemeConstantOverride("separation", 1);
        var heading = new Label { Text = title };
        heading.Modulate = Muted;
        box.AddChild(heading);
        value.Text = "--";
        box.AddChild(value);
        return box;
    }

    private static void AddDiagnosticBlock(VBoxContainer parent, string title, Label value)
    {
        parent.AddChild(new HSeparator());
        var heading = new Label { Text = title };
        heading.AddThemeFontSizeOverride("font_size", TitleFontSize);
        parent.AddChild(heading);
        value.Text = "Position  --\nRotation  --";
        parent.AddChild(value);
    }

    private static void ApplyFontSize(Node node)
    {
        foreach (Node child in node.GetChildren())
        {
            if (child is Label label && !label.HasThemeFontSizeOverride("font_size"))
                label.AddThemeFontSizeOverride("font_size", RegularFontSize);
            else if (child is Button button)
                button.AddThemeFontSizeOverride("font_size", RegularFontSize);
            else if (child is LineEdit edit)
                edit.AddThemeFontSizeOverride("font_size", RegularFontSize);
            else if (child is OptionButton option)
                option.AddThemeFontSizeOverride("font_size", RegularFontSize);
            else if (child is ItemList list)
                list.AddThemeFontSizeOverride("font_size", RegularFontSize);
            ApplyFontSize(child);
        }
    }

    private static void SetActive(Label label, bool active)
    {
        if (active)
            label.AddThemeColorOverride("font_color", ActiveGreen);
        else
            label.RemoveThemeColorOverride("font_color");
    }

    private static string V(Vector3 v) => $"({v.X:0.####}, {v.Y:0.####}, {v.Z:0.####})";
    private static string Q(Quaternion q) => $"({q.X:0.####}, {q.Y:0.####}, {q.Z:0.####}, {q.W:0.####})";
}
#endif
