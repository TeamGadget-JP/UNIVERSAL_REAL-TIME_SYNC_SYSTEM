#if TOOLS
#nullable enable annotations
using System.Collections.Generic;
using Godot;

/// <summary>
/// Skeleton3D-backed Bone selector used by the GHEG_Avatar Inspector.
/// </summary>
[Tool]
public partial class GHEG_BoneDropdownProperty : EditorProperty
{
    private const double RefreshIntervalSeconds = 0.5;

    private readonly OptionButton _selector = new();
    private readonly List<string> _boneNames = new();
    private readonly bool _allowNone;

    private bool _updating;
    private bool _signalsConnected;
    private double _refreshRemaining;
    private ulong _lastSkeletonId;
    private int _lastBoneCount = -1;

    public GHEG_BoneDropdownProperty(bool allowNone)
    {
        _allowNone = allowNone;

        _selector.SizeFlagsHorizontal =
            Control.SizeFlags.ExpandFill;
        _selector.ClipText = true;
        AddChild(_selector);
        AddFocusable(_selector);

        SetProcess(true);
    }

    public override void _EnterTree()
    {
        if (!_signalsConnected)
        {
            _selector.ItemSelected += OnItemSelected;
            _signalsConnected = true;
        }

        SetProcess(true);
    }

    public override void _ExitTree()
    {
        if (_signalsConnected)
        {
            _selector.ItemSelected -= OnItemSelected;
            _signalsConnected = false;
        }

        SetProcess(false);
    }

    public override void _UpdateProperty()
    {
        RebuildOptions(force: true);
    }

    public override void _Process(double delta)
    {
        _refreshRemaining -= delta;
        if (_refreshRemaining > 0.0)
            return;

        _refreshRemaining = RefreshIntervalSeconds;
        RebuildOptions(force: false);
    }

    private void RebuildOptions(bool force)
    {
        if (GetEditedObject() is not GHEG_Avatar avatar)
            return;

        Skeleton3D? skeleton = avatar.ResolveSkeleton();
        ulong skeletonId =
            skeleton?.GetInstanceId() ?? 0UL;
        int boneCount =
            skeleton?.GetBoneCount() ?? 0;

        if (!force &&
            skeletonId == _lastSkeletonId &&
            boneCount == _lastBoneCount)
        {
            SyncSelection();
            return;
        }

        _lastSkeletonId = skeletonId;
        _lastBoneCount = boneCount;

        _updating = true;
        _selector.Clear();
        _boneNames.Clear();

        _selector.AddItem(
            _allowNone ? "None" : "<Select Bone>");
        _boneNames.Add("");

        if (skeleton is not null)
        {
            for (int boneId = 0;
                 boneId < boneCount;
                 boneId++)
            {
                string boneName =
                    skeleton.GetBoneName(boneId).ToString();

                if (string.IsNullOrWhiteSpace(boneName))
                    continue;

                _selector.AddItem(boneName);
                _boneNames.Add(boneName);
            }
        }

        SyncSelection(addMissingValue: true);
        _updating = false;
    }

    private void SyncSelection(bool addMissingValue = false)
    {
        if (GetEditedObject() is null)
            return;

        string current =
            (string)GetEditedObject().Get(
                GetEditedProperty());

        int selectedIndex =
            _boneNames.IndexOf(current);

        if (selectedIndex < 0 &&
            addMissingValue &&
            !string.IsNullOrWhiteSpace(current))
        {
            _selector.AddItem(
                $"Missing: {current}");
            _boneNames.Add(current);
            selectedIndex =
                _boneNames.Count - 1;
        }

        if (selectedIndex < 0)
            selectedIndex = 0;

        _updating = true;
        _selector.Selected = selectedIndex;
        _updating = false;
    }

    private void OnItemSelected(long index)
    {
        if (_updating)
            return;

        int itemIndex = (int)index;
        if (itemIndex < 0 ||
            itemIndex >= _boneNames.Count)
        {
            return;
        }

        string boneName =
            _boneNames[itemIndex];

        EmitChanged(
            GetEditedProperty(),
            boneName);
    }
}
#endif
