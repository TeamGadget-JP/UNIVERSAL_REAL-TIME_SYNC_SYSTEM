#nullable enable annotations
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace GHEG.Internal.Network;

/// <summary>
/// Socket-only G-HUB client.
/// This class never touches Godot scene objects from worker threads.
/// </summary>
internal sealed class GHEG_GHubClient : IDisposable
{
    private sealed class CharacterUdpState
    {
        internal UdpClient? Udp;
        internal Task? Task;
        internal byte[]? LatestPacket;
        internal int Port;
        internal long PacketCount;
    }

    private sealed class ShapeKeyUdpState
    {
        internal UdpClient? Udp;
        internal Task? Task;
        internal readonly ConcurrentQueue<byte[]> Queue = new();
        internal int Port;
        internal long PacketCount;
        internal int QueuedCount;
    }

    private const int MaxQueuedShapePacketsPerSlot = 2048;

    private static readonly object _activeClientsLock = new();
    private static readonly HashSet<GHEG_GHubClient> _activeClients = new();

    private readonly ConcurrentQueue<GHEG_ControlEvent> _events = new();
    private readonly object _sendLock = new();
    private readonly object _socketLock = new();
    private readonly object _udpLock = new();
    private readonly CharacterUdpState[] _characterUdpStates =
        CreateCharacterUdpStates();
    private readonly ShapeKeyUdpState[] _shapeKeyUdpStates =
        CreateShapeKeyUdpStates();

    private CancellationTokenSource? _cts;
    private Task? _workerTask;
    private TcpClient? _tcpClient;
    private StreamWriter? _writer;

    private int _running;
    private int _disposed;

    internal bool IsRunning => Volatile.Read(ref _running) != 0;

    internal GHEG_GHubClient()
    {
        lock (_activeClientsLock)
        {
            _activeClients.Add(this);
        }
    }

    internal static void ShutdownAllForAssemblyReload(bool releaseRegistry = false)
    {
        GHEG_GHubClient[] clients;

        lock (_activeClientsLock)
        {
            clients = new GHEG_GHubClient[_activeClients.Count];
            _activeClients.CopyTo(clients);

            if (releaseRegistry)
                _activeClients.Clear();
        }

        foreach (GHEG_GHubClient client in clients)
        {
            try
            {
                client.DisconnectAndWait();
            }
            catch
            {
            }
        }
    }

    internal void Connect(string host, int port)
    {
        if (Interlocked.CompareExchange(ref _running, 1, 0) != 0)
            return;

        _cts = new CancellationTokenSource();
        CancellationToken token = _cts.Token;

        _workerTask = Task.Run(
            () => TcpWorkerAsync(host, port, token),
            token);
    }

    internal void Disconnect()
    {
        DisconnectAndWait();
    }

    private void DisconnectAndWait()
    {
        CancellationTokenSource? cts = _cts;
        _cts = null;

        Task? tcpTask = _workerTask;
        _workerTask = null;

        try
        {
            cts?.Cancel();
        }
        catch
        {
        }

        TcpClient? tcpClient;

        lock (_socketLock)
        {
            tcpClient = _tcpClient;
            _tcpClient = null;
            _writer = null;
        }

        try
        {
            tcpClient?.Close();
        }
        catch
        {
        }

        StopAllCharacterUdpAndWait();
        StopAllShapeKeyUdpAndWait();
        WaitForWorker(tcpTask);

        try
        {
            cts?.Dispose();
        }
        catch
        {
        }

        Interlocked.Exchange(ref _running, 0);
    }

    internal bool Send(IReadOnlyDictionary<string, object> message)
    {
        string raw = JsonSerializer.Serialize(message);

        lock (_sendLock)
        {
            StreamWriter? writer;
            lock (_socketLock)
            {
                writer = _writer;
            }

            if (writer is null)
                return false;

            try
            {
                writer.WriteLine(raw);
                writer.Flush();
                return true;
            }
            catch (Exception ex)
            {
                _events.Enqueue(
                    new GHEG_ControlEvent(
                        GHEG_ControlEventType.Error,
                        $"Control send failed: {ex.Message}"));
                return false;
            }
        }
    }

    internal int GetCharacterUdpPort(int slotIndex)
    {
        CharacterUdpState? state = GetCharacterUdpState(slotIndex);
        return state is null ? 0 : Volatile.Read(ref state.Port);
    }

    internal long GetCharacterUdpPacketCount(int slotIndex)
    {
        CharacterUdpState? state = GetCharacterUdpState(slotIndex);
        return state is null ? 0 : Interlocked.Read(ref state.PacketCount);
    }

    internal int GetShapeKeyUdpPort(int slotIndex)
    {
        ShapeKeyUdpState? state = GetShapeKeyUdpState(slotIndex);
        return state is null ? 0 : Volatile.Read(ref state.Port);
    }

    internal long GetShapeKeyUdpPacketCount(int slotIndex)
    {
        ShapeKeyUdpState? state = GetShapeKeyUdpState(slotIndex);
        return state is null ? 0 : Interlocked.Read(ref state.PacketCount);
    }

    internal bool TryBindCharacterUdp(
        int slotIndex,
        int port,
        out string error)
    {
        error = "";

        CharacterUdpState? state = GetCharacterUdpState(slotIndex);
        if (state is null)
        {
            error = $"Character Slot out of range: {slotIndex}.";
            return false;
        }

        StopCharacterUdpAndWait(slotIndex);

        lock (_udpLock)
        {
            try
            {
                UdpClient udp = new(AddressFamily.InterNetwork);
                udp.Client.ExclusiveAddressUse = true;
                udp.Client.Bind(
                    new IPEndPoint(IPAddress.Loopback, port));

                state.Udp = udp;
                Volatile.Write(ref state.Port, port);
                Interlocked.Exchange(ref state.PacketCount, 0);
                Interlocked.Exchange(ref state.LatestPacket, null);

                CancellationToken token =
                    _cts?.Token ?? CancellationToken.None;

                state.Task = Task.Run(
                    () => CharacterUdpWorkerAsync(
                        slotIndex,
                        state,
                        udp,
                        token),
                    token);

                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                CloseCharacterUdpLocked(state);
                return false;
            }
        }
    }

    internal bool TryBindShapeKeyUdp(
        int slotIndex,
        int port,
        out string error)
    {
        error = "";

        ShapeKeyUdpState? state = GetShapeKeyUdpState(slotIndex);
        if (state is null)
        {
            error = $"Shape Slot out of range: {slotIndex}.";
            return false;
        }

        StopShapeKeyUdpAndWait(slotIndex);

        lock (_udpLock)
        {
            try
            {
                UdpClient udp = new(AddressFamily.InterNetwork);
                udp.Client.ExclusiveAddressUse = true;
                udp.Client.Bind(
                    new IPEndPoint(IPAddress.Loopback, port));

                state.Udp = udp;
                Volatile.Write(ref state.Port, port);
                Interlocked.Exchange(ref state.PacketCount, 0);
                Interlocked.Exchange(ref state.QueuedCount, 0);
                while (state.Queue.TryDequeue(out _))
                {
                }

                CancellationToken token =
                    _cts?.Token ?? CancellationToken.None;

                state.Task = Task.Run(
                    () => ShapeKeyUdpWorkerAsync(
                        slotIndex,
                        state,
                        udp,
                        token),
                    token);

                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                CloseShapeKeyUdpLocked(state);
                return false;
            }
        }
    }

    internal bool TryDequeue(out GHEG_ControlEvent? controlEvent)
    {
        return _events.TryDequeue(out controlEvent);
    }

    internal bool TryTakeLatestCharacterPacket(
        int slotIndex,
        out byte[]? packet,
        out long receivedCount)
    {
        packet = null;
        receivedCount = 0;

        CharacterUdpState? state = GetCharacterUdpState(slotIndex);
        if (state is null)
            return false;

        packet = Interlocked.Exchange(
            ref state.LatestPacket,
            null);

        receivedCount =
            Interlocked.Read(ref state.PacketCount);

        return packet is not null;
    }

    internal bool TryDequeueShapeKeyPacket(
        int slotIndex,
        out byte[]? packet,
        out long receivedCount)
    {
        packet = null;
        receivedCount = 0;

        ShapeKeyUdpState? state = GetShapeKeyUdpState(slotIndex);
        if (state is null)
            return false;

        if (!state.Queue.TryDequeue(out packet))
            return false;

        Interlocked.Decrement(ref state.QueuedCount);
        receivedCount = Interlocked.Read(ref state.PacketCount);
        return packet is not null;
    }

    private async Task CharacterUdpWorkerAsync(
        int slotIndex,
        CharacterUdpState state,
        UdpClient udp,
        CancellationToken token)
    {
        try
        {
            while (!token.IsCancellationRequested)
            {
                UdpReceiveResult result =
                    await udp.ReceiveAsync(token);

                Interlocked.Exchange(
                    ref state.LatestPacket,
                    result.Buffer);

                Interlocked.Increment(
                    ref state.PacketCount);
            }
        }
        catch (OperationCanceledException)
        {
        }
        catch (ObjectDisposedException)
        {
        }
        catch (SocketException)
        {
            // Closing/rebinding a UDP socket is a normal lifecycle event.
        }
        catch (Exception ex)
        {
            if (!token.IsCancellationRequested)
            {
                _events.Enqueue(
                    new GHEG_ControlEvent(
                        GHEG_ControlEventType.Error,
                        $"{GHEG_Protocol.CharacterSlotLabel(slotIndex)} UDP receive failed: {ex.Message}"));
            }
        }
    }

    private async Task ShapeKeyUdpWorkerAsync(
        int slotIndex,
        ShapeKeyUdpState state,
        UdpClient udp,
        CancellationToken token)
    {
        try
        {
            while (!token.IsCancellationRequested)
            {
                UdpReceiveResult result =
                    await udp.ReceiveAsync(token);

                state.Queue.Enqueue(result.Buffer);
                Interlocked.Increment(ref state.PacketCount);
                int queued = Interlocked.Increment(ref state.QueuedCount);

                while (queued > MaxQueuedShapePacketsPerSlot &&
                    state.Queue.TryDequeue(out _))
                {
                    queued = Interlocked.Decrement(ref state.QueuedCount);
                }
            }
        }
        catch (OperationCanceledException)
        {
        }
        catch (ObjectDisposedException)
        {
        }
        catch (SocketException)
        {
            // Closing/rebinding a UDP socket is a normal lifecycle event.
        }
        catch (Exception ex)
        {
            if (!token.IsCancellationRequested)
            {
                _events.Enqueue(
                    new GHEG_ControlEvent(
                        GHEG_ControlEventType.Error,
                        $"Face {GHEG_Protocol.CharacterSlotLabel(slotIndex)} UDP receive failed: {ex.Message}"));
            }
        }
    }

    private async Task TcpWorkerAsync(
        string host,
        int port,
        CancellationToken token)
    {
        TcpClient? client = null;
        StreamReader? reader = null;
        StreamWriter? writer = null;

        try
        {
            client = new TcpClient(AddressFamily.InterNetwork);

            lock (_socketLock)
            {
                _tcpClient = client;
            }

            using var connectCts =
                CancellationTokenSource.CreateLinkedTokenSource(token);
            connectCts.CancelAfter(TimeSpan.FromSeconds(2.0));

            try
            {
                await client.ConnectAsync(
                    host,
                    port,
                    connectCts.Token);
            }
            catch (OperationCanceledException)
                when (!token.IsCancellationRequested)
            {
                throw new TimeoutException(
                    $"Timed out connecting to {host}:{port}.");
            }

            NetworkStream stream = client.GetStream();
            reader = new StreamReader(
                stream,
                new UTF8Encoding(false),
                false,
                8192,
                leaveOpen: true);
            writer = new StreamWriter(
                stream,
                new UTF8Encoding(false),
                8192,
                leaveOpen: true)
            {
                AutoFlush = true,
            };

            lock (_socketLock)
            {
                _writer = writer;
            }

            _events.Enqueue(
                new GHEG_ControlEvent(
                    GHEG_ControlEventType.Connected,
                    $"{host}:{port}"));

            if (!Send(GHEG_Protocol.HelloMessage()))
                throw new IOException("HELLO send failed.");

            while (!token.IsCancellationRequested)
            {
                string? line =
                    await reader.ReadLineAsync(token);
                if (line is null)
                    break;

                line = line.Trim();
                if (line.Length == 0)
                    continue;

                _events.Enqueue(
                    new GHEG_ControlEvent(
                        GHEG_ControlEventType.Message,
                        line));
            }
        }
        catch (OperationCanceledException)
        {
        }
        catch (Exception ex)
        {
            if (!token.IsCancellationRequested)
            {
                _events.Enqueue(
                    new GHEG_ControlEvent(
                        GHEG_ControlEventType.Error,
                        ex.Message));
            }
        }
        finally
        {
            try
            {
                reader?.Dispose();
            }
            catch
            {
            }

            try
            {
                writer?.Dispose();
            }
            catch
            {
            }

            try
            {
                client?.Close();
            }
            catch
            {
            }

            lock (_socketLock)
            {
                if (ReferenceEquals(_tcpClient, client))
                {
                    _tcpClient = null;
                    _writer = null;
                }
            }

            StopAllCharacterUdpAndWait();
            StopAllShapeKeyUdpAndWait();
            Interlocked.Exchange(ref _running, 0);

            _events.Enqueue(
                new GHEG_ControlEvent(
                    GHEG_ControlEventType.Disconnected));
        }
    }

    private static CharacterUdpState[] CreateCharacterUdpStates()
    {
        var states = new CharacterUdpState[GHEG_Protocol.CharacterSlotCount];
        for (int i = 0; i < states.Length; i++)
            states[i] = new CharacterUdpState();
        return states;
    }

    private CharacterUdpState? GetCharacterUdpState(int slotIndex)
    {
        if (slotIndex < 0 || slotIndex >= _characterUdpStates.Length)
            return null;
        return _characterUdpStates[slotIndex];
    }

    private void StopAllCharacterUdpAndWait()
    {
        for (int slotIndex = 0;
             slotIndex < _characterUdpStates.Length;
             slotIndex++)
        {
            StopCharacterUdpAndWait(slotIndex);
        }
    }

    private void StopCharacterUdpAndWait(int slotIndex)
    {
        CharacterUdpState? state = GetCharacterUdpState(slotIndex);
        if (state is null)
            return;

        UdpClient? udp;
        Task? udpTask;

        lock (_udpLock)
        {
            udp = state.Udp;
            state.Udp = null;

            udpTask = state.Task;
            state.Task = null;

            Volatile.Write(ref state.Port, 0);
            Interlocked.Exchange(ref state.LatestPacket, null);
        }

        try
        {
            udp?.Close();
        }
        catch
        {
        }

        WaitForWorker(udpTask);
    }

    private static void CloseCharacterUdpLocked(CharacterUdpState state)
    {
        try
        {
            state.Udp?.Close();
        }
        catch
        {
        }

        state.Udp = null;
        state.Task = null;
        Volatile.Write(ref state.Port, 0);
        Interlocked.Exchange(ref state.LatestPacket, null);
    }

    private static ShapeKeyUdpState[] CreateShapeKeyUdpStates()
    {
        var states = new ShapeKeyUdpState[GHEG_Protocol.CharacterSlotCount];
        for (int i = 0; i < states.Length; i++)
            states[i] = new ShapeKeyUdpState();
        return states;
    }

    private ShapeKeyUdpState? GetShapeKeyUdpState(int slotIndex)
    {
        if (slotIndex < 0 || slotIndex >= _shapeKeyUdpStates.Length)
            return null;
        return _shapeKeyUdpStates[slotIndex];
    }

    private void StopAllShapeKeyUdpAndWait()
    {
        for (int slotIndex = 0;
             slotIndex < _shapeKeyUdpStates.Length;
             slotIndex++)
        {
            StopShapeKeyUdpAndWait(slotIndex);
        }
    }

    private void StopShapeKeyUdpAndWait(int slotIndex)
    {
        ShapeKeyUdpState? state = GetShapeKeyUdpState(slotIndex);
        if (state is null)
            return;

        UdpClient? udp;
        Task? udpTask;

        lock (_udpLock)
        {
            udp = state.Udp;
            state.Udp = null;

            udpTask = state.Task;
            state.Task = null;

            Volatile.Write(ref state.Port, 0);
            Interlocked.Exchange(ref state.QueuedCount, 0);
            while (state.Queue.TryDequeue(out _))
            {
            }
        }

        try
        {
            udp?.Close();
        }
        catch
        {
        }

        WaitForWorker(udpTask);
    }

    private static void CloseShapeKeyUdpLocked(ShapeKeyUdpState state)
    {
        try
        {
            state.Udp?.Close();
        }
        catch
        {
        }

        state.Udp = null;
        state.Task = null;
        Volatile.Write(ref state.Port, 0);
        Interlocked.Exchange(ref state.QueuedCount, 0);
        while (state.Queue.TryDequeue(out _))
        {
        }
    }

    private static void WaitForWorker(Task? task)
    {
        if (task is null || task.IsCompleted)
            return;

        try
        {
            task.Wait(TimeSpan.FromSeconds(2.0));
        }
        catch (AggregateException)
        {
            // Cancellation/closed sockets are expected during plugin reload.
        }
        catch
        {
        }
    }

    public void Dispose()
    {
        if (Interlocked.Exchange(ref _disposed, 1) != 0)
            return;

        DisconnectAndWait();

        lock (_activeClientsLock)
        {
            _activeClients.Remove(this);
        }
    }
}
